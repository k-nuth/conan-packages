//
// impl/thread_pool.hpp
// ~~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2026 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef ASIO_IMPL_THREAD_POOL_HPP
#define ASIO_IMPL_THREAD_POOL_HPP

#if defined(_MSC_VER) && (_MSC_VER >= 1200)
# pragma once
#endif // defined(_MSC_VER) && (_MSC_VER >= 1200)

#include "asio/config.hpp"
#include "asio/detail/blocking_executor_op.hpp"
#include "asio/detail/executor_function.hpp"
#include "asio/detail/executor_op.hpp"
#include "asio/detail/fenced_block.hpp"
#include "asio/detail/non_const_lvalue.hpp"
#include "asio/detail/type_traits.hpp"
#include "asio/execution_context.hpp"

#include "asio/detail/push_options.hpp"

namespace asio {
ASIO_INLINE_NAMESPACE_BEGIN

#if !defined(ASIO_NO_TS_EXECUTORS)

template <typename Allocator>
thread_pool::thread_pool(allocator_arg_t, const Allocator& a)
  : execution_context(std::allocator_arg, a),
    scheduler_(asio::make_service<detail::scheduler>(*this, false)),
    threads_(allocator<void>(*this)),
    num_threads_(default_thread_pool_size()),
    joinable_(true)
{
  start();
}

#endif // !defined(ASIO_NO_TS_EXECUTORS)

template <typename Allocator>
thread_pool::thread_pool(allocator_arg_t,
    const Allocator& a, std::size_t num_threads)
  : execution_context(std::allocator_arg, a,
      config_from_concurrency_hint(num_threads == 1 ? 1 : 0)),
    scheduler_(asio::make_service<detail::scheduler>(*this, false)),
    threads_(allocator<void>(*this)),
    num_threads_(clamp_thread_pool_size(num_threads)),
    joinable_(true)
{
  start();
}

template <typename Allocator>
thread_pool::thread_pool(allocator_arg_t,
    const Allocator& a, std::size_t num_threads,
    const execution_context::service_maker& initial_services)
  : execution_context(std::allocator_arg, a, initial_services),
    scheduler_(asio::make_service<detail::scheduler>(*this, false)),
    threads_(allocator<void>(*this)),
    num_threads_(clamp_thread_pool_size(num_threads)),
    joinable_(true)
{
  start();
}

inline thread_pool::executor_type
thread_pool::get_executor() noexcept
{
  return executor_type(*this);
}

inline thread_pool::executor_type
thread_pool::executor() noexcept
{
  return executor_type(*this);
}

template <typename Allocator, unsigned int Bits>
thread_pool::basic_executor_type<Allocator, Bits>&
thread_pool::basic_executor_type<Allocator, Bits>::operator=(
    const basic_executor_type& other) noexcept
{
  if (this != &other)
  {
    static_cast<Allocator&>(*this) = static_cast<const Allocator&>(other);
    thread_pool* old_thread_pool = context_ptr();
    target_ = other.target_;
    if (Bits & outstanding_work_tracked)
    {
      if (context_ptr())
        context_ptr()->scheduler_.work_started();
      if (old_thread_pool)
        old_thread_pool->scheduler_.work_finished();
    }
  }
  return *this;
}

template <typename Allocator, unsigned int Bits>
thread_pool::basic_executor_type<Allocator, Bits>&
thread_pool::basic_executor_type<Allocator, Bits>::operator=(
    basic_executor_type&& other) noexcept
{
  if (this != &other)
  {
    static_cast<Allocator&>(*this) = static_cast<Allocator&&>(other);
    thread_pool* old_thread_pool = context_ptr();
    target_ = other.target_;
    if (Bits & outstanding_work_tracked)
    {
      other.target_ = 0;
      if (old_thread_pool)
        old_thread_pool->scheduler_.work_finished();
    }
  }
  return *this;
}

template <typename Allocator, unsigned int Bits>
inline bool thread_pool::basic_executor_type<Allocator,
    Bits>::running_in_this_thread() const noexcept
{
  return context_ptr()->scheduler_.can_dispatch();
}

template <typename Function>
void thread_pool::execute_immediately(Function&& f)
{
  typedef decay_t<Function> function_type;

  // Make a local, non-const copy of the function.
  function_type tmp(static_cast<Function&&>(f));

#if defined(ASIO_NO_EXCEPTIONS)
  detail::fenced_block b(detail::fenced_block::full);
  static_cast<function_type&&>(tmp)();
#else // defined(ASIO_NO_EXCEPTIONS)
  try
  {
    detail::fenced_block b(detail::fenced_block::full);
    static_cast<function_type&&>(tmp)();
  }
  catch (...)
  {
    std::terminate();
  }
#endif // defined(ASIO_NO_EXCEPTIONS)
}

template <typename Allocator, unsigned int Bits>
template <typename Function>
ASIO_ALWAYS_INLINE
void thread_pool::basic_executor_type<Allocator,
    Bits>::do_execute(Function&& f, false_type) const
{
  typedef decay_t<Function> function_type;

  // Invoke immediately if the blocking.possibly property is enabled and we are
  // already inside the thread pool.
  if ((bits() & blocking_never) == 0
      && context_ptr()->scheduler_.can_dispatch())
  {
    thread_pool::execute_immediately(static_cast<Function&&>(f));
    return;
  }

  // Allocate and construct an operation to wrap the function.
  typedef detail::executor_op<function_type, Allocator> op;
  typename op::ptr p = {
      detail::addressof(static_cast<const Allocator&>(*this)),
      op::ptr::allocate(static_cast<const Allocator&>(*this)), 0 };
  p.p = new (p.v) op(static_cast<Function&&>(f),
      static_cast<const Allocator&>(*this));

  if ((bits() & relationship_continuation) != 0)
  {
    ASIO_HANDLER_CREATION((*context_ptr(), *p.p,
          "thread_pool", context_ptr(), 0, "execute(blk=never,rel=cont)"));
    context_ptr()->scheduler_.post_immediate_completion(p.p, true);
  }
  else
  {
    ASIO_HANDLER_CREATION((*context_ptr(), *p.p,
          "thread_pool", context_ptr(), 0, "execute(blk=never,rel=fork)"));
    context_ptr()->scheduler_.post_immediate_completion(p.p, false);
  }
  p.v = p.p = 0;
}

template <typename Allocator, unsigned int Bits>
void thread_pool::basic_executor_type<Allocator, Bits>::do_execute(
    detail::executor_function&& f, false_type) const
{
  // Invoke immediately if the blocking.possibly property is enabled and we are
  // already inside the thread pool.
  if ((bits() & blocking_never) == 0
      && context_ptr()->scheduler_.can_dispatch())
  {
    thread_pool::execute_immediately(
        static_cast<detail::executor_function&&>(f));
    return;
  }

  if ((bits() & relationship_continuation) != 0)
  {
    ASIO_HANDLER_CREATION((*context_ptr(), *f.get(),
          "thread_pool", context_ptr(), 0, "execute(blk=never,rel=cont)"));
    context_ptr()->scheduler_.post_immediate_completion(f.release(), true);
  }
  else
  {
    ASIO_HANDLER_CREATION((*context_ptr(), *f.get(),
          "thread_pool", context_ptr(), 0, "execute(blk=never,rel=fork)"));
    context_ptr()->scheduler_.post_immediate_completion(f.release(), false);
  }
}

template <typename Allocator, unsigned int Bits>
template <typename Function>
void thread_pool::basic_executor_type<Allocator,
    Bits>::do_execute(Function&& f, true_type) const
{
  // Obtain a non-const instance of the function.
  detail::non_const_lvalue<Function> f2(f);

  // Invoke immediately if we are already inside the thread pool.
  if (context_ptr()->scheduler_.can_dispatch())
  {
#if !defined(ASIO_NO_EXCEPTIONS)
    try
    {
#endif // !defined(ASIO_NO_EXCEPTIONS)
      detail::fenced_block b(detail::fenced_block::full);
      static_cast<decay_t<Function>&&>(f2.value)();
      return;
#if !defined(ASIO_NO_EXCEPTIONS)
    }
    catch (...)
    {
      std::terminate();
    }
#endif // !defined(ASIO_NO_EXCEPTIONS)
  }

  // Construct an operation to wrap the function.
  typedef decay_t<Function> function_type;
  detail::blocking_executor_op<function_type> op(f2.value);

  ASIO_HANDLER_CREATION((*context_ptr(), op,
        "thread_pool", context_ptr(), 0, "execute(blk=always)"));

  context_ptr()->scheduler_.post_immediate_completion(&op, false);
  op.wait();
}

#if !defined(ASIO_NO_TS_EXECUTORS)
template <typename Allocator, unsigned int Bits>
inline thread_pool& thread_pool::basic_executor_type<
    Allocator, Bits>::context() const noexcept
{
  return *context_ptr();
}

template <typename Allocator, unsigned int Bits>
inline void thread_pool::basic_executor_type<Allocator,
    Bits>::on_work_started() const noexcept
{
  context_ptr()->scheduler_.work_started();
}

template <typename Allocator, unsigned int Bits>
inline void thread_pool::basic_executor_type<Allocator,
    Bits>::on_work_finished() const noexcept
{
  context_ptr()->scheduler_.work_finished();
}

template <typename Allocator, unsigned int Bits>
template <typename Function, typename OtherAllocator>
void thread_pool::basic_executor_type<Allocator, Bits>::dispatch(
    Function&& f, const OtherAllocator& a) const
{
  typedef decay_t<Function> function_type;

  // Invoke immediately if we are already inside the thread pool.
  if (context_ptr()->scheduler_.can_dispatch())
  {
    // Make a local, non-const copy of the function.
    function_type tmp(static_cast<Function&&>(f));

    detail::fenced_block b(detail::fenced_block::full);
    static_cast<function_type&&>(tmp)();
    return;
  }

  // Allocate and construct an operation to wrap the function.
  typedef detail::executor_op<function_type, OtherAllocator> op;
  typename op::ptr p = { detail::addressof(a), op::ptr::allocate(a), 0 };
  p.p = new (p.v) op(static_cast<Function&&>(f), a);

  ASIO_HANDLER_CREATION((*context_ptr(), *p.p,
        "thread_pool", context_ptr(), 0, "dispatch"));

  context_ptr()->scheduler_.post_immediate_completion(p.p, false);
  p.v = p.p = 0;
}

template <typename Allocator, unsigned int Bits>
template <typename Function, typename OtherAllocator>
void thread_pool::basic_executor_type<Allocator, Bits>::post(
    Function&& f, const OtherAllocator& a) const
{
  typedef decay_t<Function> function_type;

  // Allocate and construct an operation to wrap the function.
  typedef detail::executor_op<function_type, OtherAllocator> op;
  typename op::ptr p = { detail::addressof(a), op::ptr::allocate(a), 0 };
  p.p = new (p.v) op(static_cast<Function&&>(f), a);

  ASIO_HANDLER_CREATION((*context_ptr(), *p.p,
        "thread_pool", context_ptr(), 0, "post"));

  context_ptr()->scheduler_.post_immediate_completion(p.p, false);
  p.v = p.p = 0;
}

template <typename Allocator, unsigned int Bits>
template <typename Function, typename OtherAllocator>
void thread_pool::basic_executor_type<Allocator, Bits>::defer(
    Function&& f, const OtherAllocator& a) const
{
  typedef decay_t<Function> function_type;

  // Allocate and construct an operation to wrap the function.
  typedef detail::executor_op<function_type, OtherAllocator> op;
  typename op::ptr p = { detail::addressof(a), op::ptr::allocate(a), 0 };
  p.p = new (p.v) op(static_cast<Function&&>(f), a);

  ASIO_HANDLER_CREATION((*context_ptr(), *p.p,
        "thread_pool", context_ptr(), 0, "defer"));

  context_ptr()->scheduler_.post_immediate_completion(p.p, true);
  p.v = p.p = 0;
}
#endif // !defined(ASIO_NO_TS_EXECUTORS)

ASIO_INLINE_NAMESPACE_END
} // namespace asio

#include "asio/detail/pop_options.hpp"

#endif // ASIO_IMPL_THREAD_POOL_HPP
