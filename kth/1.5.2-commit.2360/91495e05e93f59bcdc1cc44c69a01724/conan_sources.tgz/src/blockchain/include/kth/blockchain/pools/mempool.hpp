// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_BLOCKCHAIN_POOLS_MEMPOOL_HPP
#define KTH_BLOCKCHAIN_POOLS_MEMPOOL_HPP

#include <atomic>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <vector>

#include <kth/domain.hpp>
#include <kth/infrastructure/utility/prioritized_mutex.hpp>

#include <kth/blockchain/define.hpp>
#include <kth/blockchain/pools/mempool_hashers.hpp>
#include <kth/blockchain/pools/mempool_map.hpp>
#include <kth/blockchain/pools/mempool_stats.hpp>

namespace kth::blockchain {

// One unconfirmed transaction plus the policy metadata computed at admission.
// Holds the tx by shared_ptr (== BCHN CTransactionRef): the pool owns it, and
// prevout resolution / queries copy the shared_ptr out (a refcount bump), never
// the transaction, and it stays alive across concurrent eviction.
struct mempool_entry {
    transaction_const_ptr tx;
    uint64_t fee;
    uint32_t size;
    uint32_t sigchecks;
    uint64_t time_seen;
};

// Aggregate figures over the whole pool (== the BCHN getmempoolinfo fields KTH
// backs). Computed on demand by summary().
struct mempool_totals {
    std::size_t size;   // number of transactions
    uint64_t bytes;     // sum of serialized sizes
    uint64_t total_fee; // sum of fees (satoshis)
};

// The BCH mempool: unconfirmed transactions in two concurrent maps —
//   pool_     : txid    -> entry                (the pool)
//   spent_by_ : outpoint-> spending txid        (== BCHN mapNextTx)
// No CPFP, no ancestor/descendant fee graph, no unconfirmed chain limit. The
// spent_by_ index gives O(1) first-seen double-spend detection and conflict /
// descendant eviction; the descendant set is derived from spent_by_ (an evicted
// tx's outputs are looked up there), so no separate child graph is kept.
//
// Concurrency model: writes (add / remove_for_block / update_for_reorg) are
// serialised by the organizers' shared prioritized_mutex, so they need no
// internal locking; reads (resolve / queries) run concurrently with them, which
// is what the concurrent map backend is for. The operations are plain
// synchronous methods — they are CPU/memory work on the maps with no I/O, so
// they are called directly inside the organizer coroutines without co_await.
struct mempool {
    // Production (cfm) uses a per-node random salt for the hashers; the
    // explicit-salt ctor is for tests / reproducibility.
    mempool();
    mempool(uint64_t k0, uint64_t k1);

    // Admission of an already-validated transaction (scripts/fees checked by
    // the organizer). Returns false if the txid is already present or if any
    // input double-spends an outpoint already spent in the pool (first-seen).
    bool add(mempool_entry entry);

    // A block was connected: remove its transactions (now confirmed) and any
    // pool transaction that conflicts with them (recursively, with descendants).
    // Returns the ids of the transactions this call removed.
    std::vector<hash_digest> remove_for_block(domain::chain::block const& block);

    // Remove a transaction and every pool transaction that spends its outputs,
    // transitively. Returns the ids of the transactions this call removed.
    std::vector<hash_digest> remove_with_descendants(hash_digest const& txid);

    // Remove every transaction first seen before `seen_before` (unix seconds),
    // with its descendants (BCHN's mempool expiry). Returns the ids of the
    // transactions this call removed.
    std::vector<hash_digest> expire(uint64_t seen_before);

    // A reorg happened: re-admit transactions from the disconnected blocks that
    // are not in the new chain, then apply remove_for_block for the new blocks.
    std::vector<hash_digest> update_for_reorg(block_const_ptr_list_const_ptr outgoing,
                                              block_const_ptr_list_const_ptr incoming);

    // CCoinsViewMemPool-style prevout resolution for chained transactions: if
    // `outpoint` is an output of a pool transaction, returns it; otherwise
    // nullopt and the caller falls back to the confirmed UTXO set (UTXO-Z).
    // Takes point (the base of output_point) — the outpoint's validation cache
    // is deliberately not part of the key/lookup.
    std::optional<domain::chain::output>
    resolve(domain::chain::point const& outpoint) const;

    // The pool transaction that spends `outpoint`, if any (the spent_by_ entry,
    // == BCHN mapNextTx). gettxout asks it to report an output as spent once
    // a pool transaction spends it.
    std::optional<hash_digest> spender(domain::chain::point const& outpoint) const;

    bool contains(hash_digest const& txid) const;
    std::size_t size() const;

    // Fetch a pooled transaction by id (null if absent).
    transaction_const_ptr get(hash_digest const& txid) const;

    // Copy a pooled entry (tx + policy metadata) by id, or nullopt if absent.
    std::optional<mempool_entry> entry(hash_digest const& txid) const;

    // Read-only graph queries over the pool (mirror BCHN CTxMemPool). `parents`
    // / `children` are the direct in-mempool adjacency (== BCHN depends /
    // spentby); `ancestors` / `descendants` are their transitive closures. All
    // exclude `txid` itself and are de-duplicated. Empty if txid is not pooled.
    std::vector<hash_digest> parents(hash_digest const& txid) const;
    std::vector<hash_digest> children(hash_digest const& txid) const;
    std::vector<hash_digest> ancestors(hash_digest const& txid) const;
    std::vector<hash_digest> descendants(hash_digest const& txid) const;

    // The ids of every pooled transaction (== BCHN getrawmempool).
    std::vector<hash_digest> all_txids() const;

    // Aggregate size / bytes / total_fee over the pool (== getmempoolinfo).
    mempool_totals summary() const;

    // Visit every pooled entry. Snapshot-ish under concurrency (an entry added
    // or removed during the walk may or may not be seen) — fine for the
    // read-only listing/relay queries that use it.
    template <typename Fn>
        requires std::invocable<Fn, mempool_entry const&>
    void for_each(Fn&& fn) const {
        pool_.for_each([&](hash_digest const&, mempool_entry const& entry) {
            fn(entry);
        });
    }

    mempool_stats const& stats() const { return stats_; }

    /// A monotonically-increasing counter bumped on every mutation (add or
    /// remove). Callers cache "has the mempool changed since I last looked?"
    /// by comparing this — e.g. the block-template cache. Not a cache itself.
    uint64_t generation() const {
        return generation_.load(std::memory_order_relaxed);
    }

private:
    // Erase one tx from pool_ and release its input-outpoint claims in
    // spent_by_. Non-recursive: descendants are untouched. True if this call
    // erased it.
    bool remove_entry(hash_digest const& txid);

    // Remove a tx and, transitively, every pool tx that spends its outputs
    // (the rare invalid/conflict path), appending what it erased to `removed`.
    void remove_recursive(hash_digest const& txid, std::vector<hash_digest>& removed);

    // Direct in-mempool adjacency, un-instrumented (the public parents/children
    // wrap these with stats; the ancestors/descendants traversal reuses them so
    // the internal walk is not counted as top-level calls).
    std::vector<hash_digest> parents_of(hash_digest const& txid) const;
    std::vector<hash_digest> children_of(hash_digest const& txid) const;

    mempool_map<hash_digest, mempool_entry, salted_txid_hasher> pool_;
    mempool_map<outpoint_key, hash_digest, salted_outpoint_hasher> spent_by_;
    mempool_stats stats_;
    std::atomic<uint64_t> generation_{0};
};

// A set of entries the pool actually held, and the number that labels it.
struct pool_view {
    std::vector<mempool_entry> entries;
    uint64_t generation;
};

/// Copy the pool coherently, under the same exclusion its writers take.
///
/// `for_each` walks a map that locks per element, so on its own it collects a
/// set gathered over an interval rather than a state the pool was ever in. That
/// distinction is not academic: a template built from such a set can select a
/// transaction without its unconfirmed parent, because a prevout whose txid is
/// absent reads as already confirmed (#611). Holding the writers' mutex for the
/// walk is what makes the result a state; sampling the generation inside the
/// same lease is what makes the label describe these entries rather than some
/// instant near them.
///
/// The lease covers the copy and nothing else — everything a caller does with
/// the result touches only its own copy, and the exclusion stops admission, so
/// its length is paid by every transaction arriving meanwhile. The low-priority
/// side is deliberate: connecting a block must not wait behind a reader.
///
/// Must not be called with a suspension point inside a caller's use of it: a
/// shared_mutex may only be released by the thread that took it, and a
/// coroutine may resume on another. The copy itself is synchronous.
KB_API
pool_view lease_pool_view(prioritized_mutex& mutex, mempool const& pool);

} // namespace kth::blockchain

#endif // KTH_BLOCKCHAIN_POOLS_MEMPOOL_HPP
