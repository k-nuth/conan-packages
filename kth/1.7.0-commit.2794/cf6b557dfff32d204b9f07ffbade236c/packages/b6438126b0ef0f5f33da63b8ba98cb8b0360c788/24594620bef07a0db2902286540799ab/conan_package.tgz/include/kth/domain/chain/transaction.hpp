// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_CHAIN_TRANSACTION_HPP
#define KTH_DOMAIN_CHAIN_TRANSACTION_HPP

#include <algorithm>
#include <concepts>
#include <cstddef>
#include <cstdint>
#include <istream>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include <kth/domain/chain/chain_state.hpp>
#include <kth/domain/chain/input.hpp>
#include <kth/domain/chain/output.hpp>
#include <kth/domain/chain/point.hpp>
#include <kth/domain/chain/utxo.hpp>
#include <kth/domain/constants.hpp>
#include <kth/domain/define.hpp>
#include <kth/domain/machine/opcode.hpp>
#include <kth/domain/machine/script_flags.hpp>

#include <kth/infrastructure/error.hpp>
#include <kth/infrastructure/math/elliptic_curve.hpp>
#include <kth/infrastructure/math/hash.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>

#include <kth/domain/concepts.hpp>
#include <kth/domain/deserialization.hpp>
#include <kth/domain/wallet/payment_address.hpp>

namespace kth::domain::chain {

namespace detail {

// True when `Put::to_data` has exactly the `expect<void>` shape and cannot throw.
template <class Put>
inline constexpr bool nothrow_put_to_data_v =
    std::same_as<decltype(std::declval<Put const&>().to_data(std::declval<byte_writer&>(), true)), expect<void>>
    && noexcept(std::declval<Put const&>().to_data(std::declval<byte_writer&>(), true));

// Write a length-prefixed collection of inputs or outputs to the writer.
// Any `Put::to_data` result that converts to `expect<void>` is accepted, as
// before. The function is noexcept only for the exact `expect<void>` shape
// with a noexcept `to_data` (the writer primitives and vector iteration cannot
// throw); every other shape is conservatively potentially throwing, since
// copying, testing or converting its result is not known to be nothrow.
template <class Put>
expect<void> write(byte_writer& writer, std::vector<Put> const& puts, bool wire)
    noexcept(nothrow_put_to_data_v<Put>)
{
    if (auto r = writer.write_variable_little_endian(puts.size()); ! r) {
        return r;
    }
    for (auto const& put : puts) {
        if (auto r = put.to_data(writer, wire); ! r) {
            return r;
        }
    }
    return {};
}

} // namespace detail

class transaction;

hash_digest hash(transaction const& tx);
hash_digest outputs_hash(transaction const& tx);
hash_digest inpoints_hash(transaction const& tx);
hash_digest sequences_hash(transaction const& tx);
hash_digest utxos_hash(transaction const& tx);

hash_digest to_outputs(transaction const& tx);
hash_digest to_inpoints(transaction const& tx);
hash_digest to_sequences(transaction const& tx);
hash_digest to_utxos(transaction const& tx);

uint64_t total_input_value(transaction const& tx);
uint64_t total_output_value(transaction const& tx);
uint64_t fees(transaction const& tx);
bool is_overspent(transaction const& tx);

struct KD_API transaction {
    using ins = input::list;
    using outs = output::list;
    using list = std::vector<transaction>;

    // Constructors.
    //-----------------------------------------------------------------------------

    // A transaction is a pure structural aggregate and does no consensus
    // checks, so construction cannot fail and every state is syntactically
    // valid — including the all-default one and the partial transactions the
    // sighash algorithm builds (empty inputs or outputs). Consensus validity
    // (`empty_transaction`, etc.) is validation's concern.
    transaction() = default;
    transaction(uint32_t version, uint32_t locktime, ins inputs, outs outputs);

    /// Returns the null transaction: the all-default value, used as an "empty
    /// slot" marker (e.g. compact block reconstruction). It is a perfectly
    /// valid transaction value — "null" here is structural, not a validity
    /// claim.
    [[nodiscard]]
    static transaction null();

    [[nodiscard]]
    bool is_null() const;

    // Operators.
    //-----------------------------------------------------------------------------

    bool operator==(transaction const& x) const = default;
    bool operator!=(transaction const& x) const = default;

    // Serialization.
    //-----------------------------------------------------------------------------

    static
    expect<transaction> from_data(byte_reader& reader, bool wire = true);

    [[nodiscard]]
    expect<void> to_data(byte_writer& writer, bool wire) const noexcept;

    [[nodiscard]]
    size_t serialized_size(bool wire = true) const;

    // Properties (accessors).
    //-----------------------------------------------------------------------------

    [[nodiscard]]
    uint32_t version() const;

    [[nodiscard]]
    uint32_t locktime() const;

    [[nodiscard]]
    ins const& inputs() const;

    [[nodiscard]]
    outs const& outputs() const;

    // Hashes — recomputed on every call (no cache).
    //-----------------------------------------------------------------------------

    [[nodiscard]]
    hash_digest hash() const;

    [[nodiscard]]
    hash_digest outputs_hash() const;

    [[nodiscard]]
    hash_digest inpoints_hash() const;

    [[nodiscard]]
    hash_digest sequences_hash() const;

    [[nodiscard]]
    hash_digest utxos_hash() const;

    // Validation.
    //-----------------------------------------------------------------------------

    [[nodiscard]]
    uint64_t fees() const;

    [[nodiscard]]
    point::list previous_outputs() const;

    [[nodiscard]]
    point::list missing_previous_outputs() const;

    [[nodiscard]]
    hash_list missing_previous_transactions() const;

    [[nodiscard]]
    uint64_t total_input_value() const;

    [[nodiscard]]
    uint64_t total_output_value() const;

    [[nodiscard]]
    size_t signature_operations(bool bip16, bool bip141) const;

    [[nodiscard]]
    bool is_coinbase() const;

    [[nodiscard]]
    bool is_null_non_coinbase() const;

    [[nodiscard]]
    bool is_oversized_coinbase() const;

    [[nodiscard]]
    bool is_mature(size_t height) const;

    [[nodiscard]]
    bool is_mature(block_ticks const& ticks, size_t height) const;

    [[nodiscard]]
    bool is_internal_double_spend() const;

    [[nodiscard]]
    bool is_double_spend(bool include_unconfirmed) const;

    [[nodiscard]]
    bool is_dusty(uint64_t minimum_output_value) const;

    [[nodiscard]]
    bool is_missing_previous_outputs() const;

    [[nodiscard]]
    bool is_final(size_t block_height, uint32_t block_time) const;

    /// Height-mode locktime in ticks: final when T(block_height) > 600 * locktime.
    [[nodiscard]]
    bool is_final(block_ticks const& ticks, size_t block_height, uint32_t block_time) const;

    [[nodiscard]]
    bool is_locked(size_t block_height, uint32_t median_time_past) const;

    [[nodiscard]]
    bool is_locked(block_ticks const& ticks, size_t block_height, uint32_t median_time_past) const;

    [[nodiscard]]
    bool is_locktime_conflict() const;

    [[nodiscard]]
    bool is_overspent() const;

    /// Structural validation — no context needed, no prevout cache needed.
    /// Can be called immediately after deserialization for fast rejection.
    [[nodiscard]]
    code check(size_t max_block_size, bool transaction_pool, bool retarget) const;

    [[nodiscard]]
    size_t min_tx_size(script_flags_t flags) const;

#if defined(KTH_CURRENCY_BCH)
    /// CashTokens contextual rules, shared by mempool and block validation.
    /// Every non-null prevout cache must be populated before calling this.
    /// Coinbase transactions need no prevouts and cannot create tokens.
    [[nodiscard]]
    code validate_tokens(script_flags_t flags) const;

    /// Reject parsed token prevouts created before their network's Descartes
    /// activation. Requires populated prevouts, like validate_tokens().
    [[nodiscard]]
    code validate_token_birth(script_flags_t flags, config::network network) const;
#endif

    /// Contextual validation — requires flags, height, etc. Prevout cache must be populated.
    /// Call after check() passes and prevout cache is filled.
    [[nodiscard]]
    code accept(
        script_flags_t flags,
        size_t height,
        uint32_t median_time_past,
        size_t max_sigops,
        bool is_under_checkpoint,
        bool transaction_pool,
        bool duplicate
    ) const;

    /// As above, with the branch's tick schedule: finality, relative locks and
    /// coinbase maturity are evaluated in ticks, and `height` is the candidate
    /// block's height (its tick comes from the schedule).
    [[nodiscard]]
    code accept(
        block_ticks const& ticks,
        script_flags_t flags,
        size_t height,
        uint32_t median_time_past,
        size_t max_sigops,
        bool is_under_checkpoint,
        bool transaction_pool,
        bool duplicate
    ) const;

    [[nodiscard]]
    code connect(chain_state const& state) const;

    [[nodiscard]]
    code connect_input(chain_state const& state, size_t input_index) const;

    [[nodiscard]]
    bool is_standard() const;

    /// Flag-aware counterpart of `is_standard()`. Outputs are classified
    /// through `script::output_pattern(flags)` (so `bch_p2s` can promote a
    /// sub-201-byte non-matching scriptPubKey to `pay_to_script`, BCH
    /// 2026-May leibniz); inputs keep the classical `input_pattern()`
    /// classification — the P2S catch-all is intentionally asymmetric and
    /// applies to locking bytecode only, matching BCHN's `Solver()` being
    /// passed flags only on the scriptPubKey side.
    [[nodiscard]]
    bool is_standard(script_flags_t flags) const;

private:
    [[nodiscard]]
    bool all_inputs_final() const;


    uint32_t version_{0};
    uint32_t locktime_{0};
    input::list inputs_;
    output::list outputs_;
};

// Script result and actual executed SigChecks from one native VM execution.
// The count is meaningful on success; errors return zero.
KD_API std::pair<code, size_t> verify_with_sigchecks(transaction const& tx, uint32_t input_index, script_flags_t flags, script const& input_script, script const& prevout_script, uint64_t value);
KD_API std::pair<code, size_t> verify_with_sigchecks(transaction const& tx, uint32_t input, script_flags_t flags);

/// The same, for a caller that verifies several inputs of `tx`: `shared` keeps
/// the hashes of the whole transaction that every signature hash uses, so they
/// are computed once for the transaction instead of once per signature. Null
/// is the functions above.
/// \pre `shared`, when not null, was created for `tx`.
KD_API std::pair<code, size_t> verify_with_sigchecks(transaction const& tx, uint32_t input_index, script_flags_t flags, script const& input_script, script const& prevout_script, uint64_t value, sighash_cache* shared);
KD_API std::pair<code, size_t> verify_with_sigchecks(transaction const& tx, uint32_t input, script_flags_t flags, sighash_cache* shared);

code verify(transaction const& tx, uint32_t input_index, script_flags_t flags, script const& input_script, script const& prevout_script, uint64_t /*value*/);
code verify(transaction const& tx, uint32_t input, script_flags_t flags);

} // namespace kth::domain::chain

#endif // KTH_DOMAIN_CHAIN_TRANSACTION_HPP
