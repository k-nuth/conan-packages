// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_MESSAGE_SEND_HEADERS_HPP
#define KTH_DOMAIN_MESSAGE_SEND_HEADERS_HPP

#include <memory>
#include <string>

#include <kth/domain/define.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/data.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>
#include <kth/domain/concepts.hpp>

namespace kth::domain::message {

struct KD_API send_headers {
    using ptr = std::shared_ptr<send_headers>;
    using const_ptr = std::shared_ptr<const send_headers>;

    [[nodiscard]]
    friend bool operator==(send_headers const&, send_headers const&) = default;

    static constexpr
    size_t satoshi_fixed_size(uint32_t /*version*/) {
        // `send_headers` has an empty payload.
        return 0;
    }

    static
    expect<send_headers> from_data(byte_reader& reader, uint32_t version) noexcept;

    [[nodiscard]]
    expect<void> to_data(byte_writer& writer, uint32_t version) const noexcept;

    [[nodiscard]]
    constexpr
    size_t serialized_size(uint32_t version) const {
        return satoshi_fixed_size(version);
    }

    static
    std::string const command;

    static
    uint32_t const version_minimum;

    static
    uint32_t const version_maximum;
};

} // namespace kth::domain::message

#endif
