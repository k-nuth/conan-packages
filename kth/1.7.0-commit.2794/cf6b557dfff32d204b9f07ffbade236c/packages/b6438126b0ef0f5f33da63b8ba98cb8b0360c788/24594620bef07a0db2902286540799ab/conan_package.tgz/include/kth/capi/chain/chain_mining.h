// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_CHAIN_CHAIN_MINING_H_
#define KTH_CAPI_CHAIN_CHAIN_MINING_H_

#include <stdint.h>

#include <kth/capi/primitives.h>
#include <kth/capi/visibility.h>
#include <kth/capi/chain/mining_info.h>
#include <kth/capi/callbacks.h>

#ifdef __cplusplus
extern "C" {
#endif

// Getters

KTH_EXPORT
kth_error_code_t kth_chain_sync_mining_info(kth_chain_t self, kth_mining_info_t* out);

/**
 * Keep self and ctx alive until the terminal callback returns; handler must be non-null and must not throw.
 * Inputs are converted and copied before scheduling; terminal completion is delivered exactly once.
 * Allocation failure reports kth_ec_out_of_memory; other C++ exceptions report kth_ec_unhandled_exception.
 */
KTH_EXPORT
void kth_chain_async_mining_info(kth_chain_t self, void* ctx, kth_mining_info_fetch_handler_t handler);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // KTH_CAPI_CHAIN_CHAIN_MINING_H_
