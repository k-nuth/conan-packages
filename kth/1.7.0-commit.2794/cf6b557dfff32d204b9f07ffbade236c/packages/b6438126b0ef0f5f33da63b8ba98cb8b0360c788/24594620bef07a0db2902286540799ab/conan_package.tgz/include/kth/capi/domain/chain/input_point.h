// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_DOMAIN_CHAIN_INPUT_POINT_H_
#define KTH_CAPI_DOMAIN_CHAIN_INPUT_POINT_H_

#include <stdint.h>

#include <kth/capi/primitives.h>
#include <kth/capi/visibility.h>

#ifdef __cplusplus
extern "C" {
#endif

// Constructors

/** @param[out] out Must point to a null `kth_input_point_mut_t` slot. On success, populated with an owned handle that the caller must release via `kth_domain_chain_input_point_destruct`. Untouched on error. */
KTH_EXPORT
kth_error_code_t kth_domain_chain_input_point_construct_from_data(uint8_t const* data, kth_size_t n, kth_bool_t wire, KTH_OUT_OWNED kth_input_point_mut_t* out);

/**
 * @return Owned `kth_input_point_mut_t`. Caller must release with `kth_domain_chain_input_point_destruct`.
 * @param hash Borrowed input; must be non-null. Copied into the resulting object; ownership of `hash` stays with the caller.
 */
KTH_EXPORT KTH_OWNED
kth_input_point_mut_t kth_domain_chain_input_point_construct(kth_hash_t const* hash, uint32_t index);

/**
 * @return Owned `kth_input_point_mut_t`. Caller must release with `kth_domain_chain_input_point_destruct`.
 * @warning `hash` MUST point to a buffer of at least 32 bytes. Passing a shorter buffer is undefined behavior. Prefer the safe variant (without the `_unsafe` suffix) when your language can pass a pointer to `kth_hash_t`.
 */
KTH_EXPORT KTH_OWNED
kth_input_point_mut_t kth_domain_chain_input_point_construct_unsafe(uint8_t const* hash, uint32_t index);

/** @return Owned `kth_input_point_mut_t`. Caller must release with `kth_domain_chain_input_point_destruct`. */
KTH_EXPORT KTH_OWNED
kth_input_point_mut_t kth_domain_chain_input_point_null(void);


// Destructor

/** No-op if `self` is null. */
KTH_EXPORT
void kth_domain_chain_input_point_destruct(kth_input_point_mut_t self);


// Copy

/** @return Owned `kth_input_point_mut_t`. Caller must release with `kth_domain_chain_input_point_destruct`. */
KTH_EXPORT KTH_OWNED
kth_input_point_mut_t kth_domain_chain_input_point_copy(kth_input_point_const_t self);


// Equality

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_equals(kth_input_point_const_t self, kth_input_point_const_t other);

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_not_equal(kth_input_point_const_t self, kth_input_point_const_t other);


// Ordering

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_less(kth_input_point_const_t self, kth_input_point_const_t x);

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_greater(kth_input_point_const_t self, kth_input_point_const_t x);

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_less_or_equal(kth_input_point_const_t self, kth_input_point_const_t x);

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_greater_or_equal(kth_input_point_const_t self, kth_input_point_const_t x);


// Serialization

/** @return Owned byte buffer. Caller must release with `kth_core_destruct_array` (length is written to `out_size`). */
KTH_EXPORT KTH_OWNED
uint8_t* kth_domain_chain_input_point_to_data(kth_input_point_const_t self, kth_bool_t wire, kth_size_t* out_size);

KTH_EXPORT
kth_size_t kth_domain_chain_input_point_serialized_size(kth_input_point_const_t self, kth_bool_t wire);


// Getters

KTH_EXPORT
kth_hash_t kth_domain_chain_input_point_hash(kth_input_point_const_t self);

KTH_EXPORT
uint32_t kth_domain_chain_input_point_index(kth_input_point_const_t self);

KTH_EXPORT
uint64_t kth_domain_chain_input_point_checksum(kth_input_point_const_t self);


// Predicates

KTH_EXPORT
kth_bool_t kth_domain_chain_input_point_is_null(kth_input_point_const_t self);


// Static utilities

KTH_EXPORT
kth_size_t kth_domain_chain_input_point_satoshi_fixed_size(void);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // KTH_CAPI_DOMAIN_CHAIN_INPUT_POINT_H_
