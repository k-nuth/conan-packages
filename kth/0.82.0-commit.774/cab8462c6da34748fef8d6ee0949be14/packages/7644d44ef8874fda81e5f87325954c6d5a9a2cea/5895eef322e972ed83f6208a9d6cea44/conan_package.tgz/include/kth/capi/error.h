// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// This file is auto-generated. Do not edit manually.

#ifndef KTH_CAPI_ERROR_H_
#define KTH_CAPI_ERROR_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef enum kth_error_code {

    // general codes
    kth_ec_success = 0,
    kth_ec_deprecated = 6,
    kth_ec_unknown = 43,
    kth_ec_not_found = 3,
    kth_ec_file_system = 42,
    kth_ec_non_standard = 17,
    kth_ec_not_implemented = 4,
    kth_ec_oversubscribed = 71,

    // network
    kth_ec_service_stopped = 1,
    kth_ec_operation_failed = 2,
    kth_ec_resolve_failed = 7,
    kth_ec_network_unreachable = 8,
    kth_ec_address_in_use = 9,
    kth_ec_listen_failed = 10,
    kth_ec_accept_failed = 11,
    kth_ec_bad_stream = 12,
    kth_ec_channel_timeout = 13,
    kth_ec_address_blocked = 44,
    kth_ec_channel_stopped = 45,
    kth_ec_peer_throttling = 73,

    // database
    kth_ec_store_block_duplicate = 66,
    kth_ec_store_block_invalid_height = 67,
    kth_ec_store_block_missing_parent = 68,

    // blockchain
    kth_ec_duplicate_block = 51,
    kth_ec_orphan_block = 5,
    kth_ec_invalid_previous_block = 24,
    kth_ec_insufficient_work = 48,
    kth_ec_orphan_transaction = 14,
    kth_ec_insufficient_fee = 70,
    kth_ec_dusty_transaction = 76,
    kth_ec_stale_chain = 75,

    // check header
    kth_ec_invalid_proof_of_work = 26,
    kth_ec_futuristic_timestamp = 27,

    // accept header
    kth_ec_checkpoints_failed = 35,
    kth_ec_old_version_block = 36,
    kth_ec_incorrect_proof_of_work = 32,
    kth_ec_timestamp_too_early = 33,

    // check block
    kth_ec_block_size_limit = 50,
    kth_ec_empty_block = 47,
    kth_ec_first_not_coinbase = 28,
    kth_ec_extra_coinbases = 29,
    kth_ec_internal_duplicate = 49,
    kth_ec_block_internal_double_spend = 15,
    kth_ec_forward_reference = 79,
    kth_ec_merkle_mismatch = 31,
    kth_ec_block_legacy_sigop_limit = 30,

#if defined(KTH_CURRENCY_BCH)
    kth_ec_non_canonical_ordered = 84,
    kth_ec_block_sigchecks_limit = 85,
#endif

    // accept block
    kth_ec_block_non_final = 34,
    kth_ec_coinbase_height_mismatch = 37,
    kth_ec_coinbase_value_limit = 41,
    kth_ec_block_embedded_sigop_limit = 52,
    kth_ec_invalid_witness_commitment = 25,
    kth_ec_block_weight_limit = 82,

    // check transaction
    kth_ec_empty_transaction = 20,
    kth_ec_previous_output_null = 23,
    kth_ec_spend_overflow = 21,
    kth_ec_invalid_coinbase_script_size = 22,
    kth_ec_coinbase_transaction = 16,
    kth_ec_transaction_internal_double_spend = 72,
    kth_ec_transaction_size_limit = 53,
    kth_ec_transaction_legacy_sigop_limit = 54,

#if defined(KTH_CURRENCY_BCH)
    kth_ec_transaction_sigchecks_limit = 86,
#endif

    // accept transaction
    kth_ec_transaction_non_final = 74,
    kth_ec_premature_validation = 69,
    kth_ec_unspent_duplicate = 38,
    kth_ec_missing_previous_output = 19,
    kth_ec_double_spend = 18,
    kth_ec_coinbase_maturity = 46,
    kth_ec_spend_exceeds_value = 40,
    kth_ec_transaction_embedded_sigop_limit = 55,
    kth_ec_sequence_locked = 78,
    kth_ec_transaction_weight_limit = 83,
    kth_ec_transaction_version_out_of_range = 87,

    // connect input
    kth_ec_invalid_script = 39,
    kth_ec_invalid_script_size = 56,
    kth_ec_invalid_push_data_size = 57,
    kth_ec_invalid_operation_count = 58,
    kth_ec_invalid_stack_size = 59,
    kth_ec_invalid_stack_scope = 60,
    kth_ec_invalid_script_embed = 61,
    kth_ec_invalid_signature_encoding = 62,
    kth_ec_invalid_signature_lax_encoding = 63,
    kth_ec_incorrect_signature = 64,
    kth_ec_unexpected_witness = 77,
    kth_ec_invalid_witness = 80,
    kth_ec_dirty_witness = 81,
    kth_ec_stack_false = 65,

    // Script evaluation categories
    kth_ec_op_disabled = 100,
    kth_ec_op_reserved,
    kth_ec_op_return,

    // BIP65/BIP112 Script validation errors
    kth_ec_negative_locktime,
    kth_ec_unsatisfied_locktime,

    // Native Introspection
    kth_ec_context_not_present,
    kth_ec_invalid_tx_input_index,
    kth_ec_invalid_tx_output_index,

    // Database errors
    kth_ec_database_insert_failed,
    kth_ec_database_push_failed,
    kth_ec_database_concurrent_push_failed,
    kth_ec_chain_reorganization_failed,
    kth_ec_database_pop_failed,

    // Blockchain validation errors
    kth_ec_reorganize_empty_blocks,
    kth_ec_chain_state_invalid,
    kth_ec_pool_state_failed,
    kth_ec_transaction_lookup_failed,
    kth_ec_branch_work_failed,
    kth_ec_block_validation_state_failed,
    kth_ec_transaction_validation_state_failed,

    // Script validation errors
    kth_ec_pubkey_type,  // Invalid public key type/encoding
    kth_ec_cleanstack,  // Stack not clean after script execution

    // BIP62/Signature validation errors
    kth_ec_sig_hashtype,  // Invalid signature hash type
    kth_ec_sig_pushonly,  // Signature push only violation.
    kth_ec_sig_high_s,  // High S value in signature            // 230
    kth_ec_sig_nullfail,  // Null signature must fail
    kth_ec_minimaldata,  // Non-minimal data encoding
    kth_ec_minimalif,  // Non-minimal IF encoding
    kth_ec_minimal_number,  // Non-minimal number encoding
    kth_ec_strict_encoding,  // Strict DER encoding violation

    // Fork/Schnorr signature errors
    kth_ec_sighash_forkid,  // Invalid sighash forkid usage
    kth_ec_sig_badlength,  // Invalid signature length
    kth_ec_sig_nonschnorr,  // Non-Schnorr signature in Schnorr context
    kth_ec_illegal_forkid,  // Illegal fork ID usage
    kth_ec_must_use_forkid,  // Must use fork ID but didn't (BCHN: MUST_USE_FORKID / MISSING_FORKID)
    // Added out of order (bip147).
    kth_ec_multisig_satoshi_bug,

    // TX creation
    kth_ec_invalid_output,
    kth_ec_lock_time_conflict,
    kth_ec_input_index_out_of_range,
    kth_ec_input_sign_failed,

    // Mining
    kth_ec_low_benefit_transaction,
    kth_ec_duplicate_transaction,
    kth_ec_double_spend_mempool,
    kth_ec_double_spend_blockchain,

    // Numeric operations
    kth_ec_overflow,
    kth_ec_underflow,
    kth_ec_out_of_range,

    // Chip VM limits
    kth_ec_op_cost_limit,
    kth_ec_too_many_hash_iters,
    kth_ec_conditional_stack_depth,

    // Transaction structure
    kth_ec_invalid_tx_version,

    // Create transaction template
    kth_ec_insufficient_amount,
    kth_ec_empty_utxo_list,
    kth_ec_invalid_change,


    // Cash Tokens
    kth_ec_invalid_bitfield,
    kth_ec_token_amount_negative,
    kth_ec_token_fungible_only_amount_zero,
    kth_ec_token_amount_bitfield_mismatch,
    kth_ec_token_commitment_bitfield_mismatch,
    kth_ec_token_fungible_with_commitment,
    kth_ec_token_commitment_oversized,
    kth_ec_token_coinbase_has_tokens,
    kth_ec_token_unparseable_output,
    kth_ec_token_unparseable_input,
    kth_ec_token_input_created_pre_activation,
    kth_ec_token_inputs_missing_or_spent,
    kth_ec_token_duplicate_genesis,
    kth_ec_token_invalid_category,
    kth_ec_token_fungible_insufficient,
    kth_ec_token_nft_ex_nihilo,
    kth_ec_token_amount_overflow,
    kth_ec_token_pre_activation_input,

    // Domain object serialization/deserialization
    kth_ec_read_past_end_of_buffer,
    kth_ec_skip_past_end_of_buffer,
    kth_ec_invalid_size,
    kth_ec_invalid_script_type,
    kth_ec_script_not_push_only,
    kth_ec_script_invalid_size,
    kth_ec_invalid_address_count,
    kth_ec_bad_inventory_count,
    kth_ec_version_too_low,
    kth_ec_version_too_new,
    kth_ec_invalid_compact_block,
    kth_ec_unsupported_version,
    kth_ec_invalid_filter_add,
    kth_ec_invalid_filter_load,
    kth_ec_bad_merkle_block_count,
    kth_ec_illegal_value,

    // Database cache
    kth_ec_height_not_found,
    kth_ec_hash_not_found,
    kth_ec_empty_cache,
    kth_ec_utxo_not_found,

    // Generic script error categories (used with op_result to pair with the failing opcode)
    kth_ec_insufficient_main_stack,  // Stack has too few elements for the operation
    kth_ec_invalid_operand_size,  // Number exceeds maximum size for arithmetic operation
    kth_ec_insufficient_alt_stack,  // Alt stack empty when operation needs an element
    kth_ec_unbalanced_conditional,  // IF/ELSE/ENDIF mismatch
    kth_ec_division_by_zero,  // DIV or MOD by zero
    kth_ec_verify_failed,  // VERIFY-type opcode check failed
    kth_ec_impossible_encoding,  // NUM2BIN cannot encode in requested size
    kth_ec_invalid_split_range,  // SPLIT position out of range
    kth_ec_invalid_number_encoding,  // BIN2NUM result not minimally encoded
    kth_ec_operand_size_mismatch,  // Bitwise operation operands differ in size
} kth_error_code_t;

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* KTH_CAPI_ERROR_H_ */
