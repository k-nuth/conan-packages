// Copyright (c) 2016-2025 Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_VERSION_H_
#define KTH_CAPI_VERSION_H_

#define KTH_CAPI_VERSION "0.77.0-commit.355";

#endif //KTH_CAPI_VERSION_H_
