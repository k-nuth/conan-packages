// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <kth/blockchain/pools/mempool.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <optional>
#include <utility>
#include <vector>

#include <boost/unordered/unordered_flat_set.hpp>

#include <kth/infrastructure/utility/pseudo_random.hpp>

namespace kth::blockchain {

using namespace kth::domain::chain;

namespace {
// Bucket hint for the concurrent maps. The pool grows as needed; this just
// avoids early rehashing on a busy node.
constexpr std::size_t initial_capacity = std::size_t(1) << 16;
} // namespace

// The mempool is lock-free: it relies on the concurrent maps' per-key atomic
// operations, not on the organizers' mutex. Writes are (today) still serialised
// by that mutex, but the logic below is correct without it — see the header.

mempool::mempool()
    : mempool(pseudo_random::generate<uint64_t>(),
              pseudo_random::generate<uint64_t>()) {}

mempool::mempool(uint64_t k0, uint64_t k1)
    : pool_(initial_capacity, salted_txid_hasher{k0, k1})
    , spent_by_(initial_capacity, salted_outpoint_hasher{k0, k1}) {}

bool mempool::add(mempool_entry entry) {
    KTH_STATS_TIME_START(add);
    KTH_STATS_INCREMENT(stats_, add_calls);

    auto const& tx = *entry.tx;
    auto const txid = tx.hash();

    // First-seen: atomically claim every spent outpoint. On any conflict, roll
    // back the claims already made and reject.
    //
    // The claims go in a canonical order, not in input order, and that is what
    // makes first-seen actually pick a winner. Two transactions spending the same
    // outpoints listed differently — one {a,b}, the other {b,a} — would each take
    // one, each fail on the other, and each roll back: both rejected, when exactly
    // one should be admitted. Sorted, they contend on the same key first, so one
    // wins outright and the other fails having claimed nothing.
    std::vector<outpoint_key> keys;
    keys.reserve(tx.inputs().size());
    for (auto const& in : tx.inputs()) {
        auto const& op = in.previous_output();
        keys.push_back({op.hash(), op.index()});
    }
    std::ranges::sort(keys);

    // Sorting also puts a repeated outpoint next to itself. A transaction that
    // spends one twice never reaches here through admission — check() rejects it
    // as an internal double spend — so this guards the callers that did not come
    // that way. Without it such a transaction would fail below and be reported as
    // conflicting with another one, when what it conflicts with is itself.
    if (std::ranges::adjacent_find(keys) != keys.end()) {
        KTH_STATS_INCREMENT(stats_, add_rejected_self_conflict);
        KTH_STATS_TIME_ADD(stats_, add, add_time_ns);
        return false;
    }

    auto const release = [this, &keys](size_t claimed) {
        for (size_t i = 0; i < claimed; ++i) {
            spent_by_.erase(keys[i]);
        }
    };

    size_t claimed = 0;
    for (auto const& key : keys) {
        if ( ! spent_by_.try_insert(key, txid)) {
            release(claimed);
            KTH_STATS_INCREMENT(stats_, add_rejected_conflict);
            KTH_STATS_TIME_ADD(stats_, add, add_time_ns);
            return false;
        }
        ++claimed;
    }

    // Commit the transaction; release the claims if it is a duplicate.
    if ( ! pool_.try_insert(txid, std::move(entry))) {
        release(claimed);
        KTH_STATS_INCREMENT(stats_, add_rejected_duplicate);
        KTH_STATS_TIME_ADD(stats_, add, add_time_ns);
        return false;
    }

    KTH_STATS_INCREMENT(stats_, add_inserted);
    KTH_STATS_TIME_ADD(stats_, add, add_time_ns);
    generation_.fetch_add(1, std::memory_order_relaxed);
    return true;
}

void mempool::remove_entry(hash_digest const& txid) {
    transaction_const_ptr tx;
    bool const found = pool_.visit(txid, [&](mempool_entry const& e) {
        tx = e.tx;
    });
    if ( ! found) {
        return;
    }

    // The erase from the pool is what decides who removes the transaction: two
    // removals of the same one can both have found it above, but only one erase
    // succeeds, and only that one frees the claims. Freeing them before, or from
    // both, lets the second removal erase a claim that another transaction took
    // in the gap once the first one released it — that transaction would sit in
    // the pool unrecorded as the spender of its inputs, and a conflicting one
    // would then be admitted beside it. Until the winner releases them the keys
    // stay claimed by this transaction, so no one can take them in the meantime.
    if ( ! pool_.erase(txid)) {
        return;
    }

    for (auto const& in : tx->inputs()) {
        auto const& op = in.previous_output();
        spent_by_.erase(outpoint_key{op.hash(), op.index()});
    }
    generation_.fetch_add(1, std::memory_order_relaxed);
}

void mempool::remove_recursive(hash_digest const& txid) {
    transaction_const_ptr tx;
    bool const found = pool_.visit(txid, [&](mempool_entry const& e) {
        tx = e.tx;
    });
    if ( ! found) {
        return;
    }

    // Evict every pool tx that spends an output of this one (its descendants),
    // depth-first, before erasing this tx.
    auto const outputs = static_cast<uint32_t>(tx->outputs().size());
    for (uint32_t index = 0; index < outputs; ++index) {
        outpoint_key const out{txid, index};
        hash_digest child;
        bool const has_child = spent_by_.visit(out, [&](hash_digest const& c) {
            child = c;
        });
        if (has_child) {
            remove_recursive(child);
        }
    }

    remove_entry(txid);
}

void mempool::remove_for_block(domain::chain::block const& block) {
    KTH_STATS_INCREMENT(stats_, remove_for_block_calls);
    KTH_STATS_TIME_START(rmv);

    for (auto const& tx : block.transactions()) {
        auto const txid = tx.hash();

        // Rare path: a confirmed tx may double-spend an outpoint claimed by a
        // DIFFERENT pool tx; that pool tx is now invalid — evict it and its
        // descendants.
        for (auto const& in : tx.inputs()) {
            auto const& op = in.previous_output();
            outpoint_key const key{op.hash(), op.index()};
            hash_digest spender;
            bool const found = spent_by_.visit(key, [&](hash_digest const& s) {
                spender = s;
            });
            if (found && spender != txid) {
                remove_recursive(spender);
                KTH_STATS_INCREMENT(stats_, removed_conflict);
            }
        }

        // Normal path: the block confirmed this tx; drop it (non-recursive —
        // its children now spend on-chain outputs and stay valid).
        remove_entry(txid);
        KTH_STATS_INCREMENT(stats_, removed_confirmed);
    }

    KTH_STATS_TIME_ADD(stats_, rmv, remove_time_ns);
}

void mempool::update_for_reorg(block_const_ptr_list_const_ptr /*outgoing*/,
                               block_const_ptr_list_const_ptr incoming) {
    // Evict for the new (connected) chain.
    if (incoming) {
        for (auto const& block : *incoming) {
            remove_for_block(*block);
        }
    }

    // TODO(mempool): re-admit transactions from the disconnected (`outgoing`)
    // blocks that are not in the new chain — they become unconfirmed again.
    // They must be re-validated against the new tip and their fee/size/sigops
    // recomputed before re-entry (parents before children). Deferred; this is
    // the rare path and the common flow does not depend on it. See issue #498.
}

std::optional<output> mempool::resolve(point const& outpoint) const {
    KTH_STATS_INCREMENT(stats_, resolve_calls);

    std::optional<output> result;
    pool_.visit(outpoint.hash(), [&](mempool_entry const& e) {
        auto const& outputs = e.tx->outputs();
        if (outpoint.index() < outputs.size()) {
            result = outputs[outpoint.index()];
        }
    });

    if (result) {
        KTH_STATS_INCREMENT(stats_, resolve_hits);
    }
    return result;
}

bool mempool::contains(hash_digest const& txid) const {
    return pool_.visit(txid, [](mempool_entry const&) {});
}

transaction_const_ptr mempool::get(hash_digest const& txid) const {
    transaction_const_ptr tx;
    pool_.visit(txid, [&](mempool_entry const& e) {
        tx = e.tx;
    });
    return tx;
}

std::size_t mempool::size() const {
    return pool_.size();
}

std::optional<mempool_entry> mempool::entry(hash_digest const& txid) const {
    KTH_STATS_INCREMENT(stats_, entry_calls);
    KTH_STATS_TIME_START(entry);

    std::optional<mempool_entry> result;
    pool_.visit(txid, [&](mempool_entry const& e) {
        result = e;
    });

    KTH_STATS_TIME_ADD(stats_, entry, entry_time_ns);
    return result;
}

// Direct adjacency, un-instrumented (see header). Read pool_ / spent_by_ once
// each; de-duplicate with a linear scan (input/output counts are small).
std::vector<hash_digest> mempool::parents_of(hash_digest const& txid) const {
    std::vector<hash_digest> result;
    pool_.visit(txid, [&](mempool_entry const& e) {
        for (auto const& in : e.tx->inputs()) {
            auto const& p = in.previous_output().hash();
            if (std::find(result.begin(), result.end(), p) == result.end() && contains(p)) {
                result.push_back(p);
            }
        }
    });
    return result;
}

std::vector<hash_digest> mempool::children_of(hash_digest const& txid) const {
    std::vector<hash_digest> result;
    pool_.visit(txid, [&](mempool_entry const& e) {
        auto const outputs = static_cast<uint32_t>(e.tx->outputs().size());
        for (uint32_t index = 0; index < outputs; ++index) {
            spent_by_.visit(outpoint_key{txid, index}, [&](hash_digest const& c) {
                if (std::find(result.begin(), result.end(), c) == result.end()) {
                    result.push_back(c);
                }
            });
        }
    });
    return result;
}

std::vector<hash_digest> mempool::parents(hash_digest const& txid) const {
    KTH_STATS_INCREMENT(stats_, parents_calls);
    KTH_STATS_TIME_START(parents);
    auto result = parents_of(txid);
    KTH_STATS_TIME_ADD(stats_, parents, parents_time_ns);
    return result;
}

std::vector<hash_digest> mempool::children(hash_digest const& txid) const {
    KTH_STATS_INCREMENT(stats_, children_calls);
    KTH_STATS_TIME_START(children);
    auto result = children_of(txid);
    KTH_STATS_TIME_ADD(stats_, children, children_time_ns);
    return result;
}

namespace {
// The txid is already a uniform digest; the low 8 bytes make a fine key hash.
struct digest_hasher {
    std::size_t operator()(hash_digest const& h) const {
        std::size_t out;
        std::memcpy(&out, h.data(), sizeof(out));
        return out;
    }
};

// Breadth-first transitive closure of `step` (parents_of / children_of) from
// `txid`, excluding `txid`, de-duplicated. O(V+E) with O(1) hashed dedup — no
// node is revisited, which bounds the walk even without a chain limit.
template <typename Step>
std::vector<hash_digest> closure(hash_digest const& txid, Step&& step) {
    std::vector<hash_digest> result;
    boost::unordered_flat_set<hash_digest, digest_hasher> seen;
    auto stack = step(txid);
    for (auto const& h : stack) {
        seen.insert(h);
    }
    while ( ! stack.empty()) {
        auto const cur = stack.back();
        stack.pop_back();
        result.push_back(cur);
        for (auto const& next : step(cur)) {
            if (seen.insert(next).second) {
                stack.push_back(next);
            }
        }
    }
    return result;
}
} // namespace

std::vector<hash_digest> mempool::ancestors(hash_digest const& txid) const {
    KTH_STATS_INCREMENT(stats_, ancestors_calls);
    KTH_STATS_TIME_START(ancestors);
    auto result = closure(txid, [this](hash_digest const& h) { return parents_of(h); });
    KTH_STATS_TIME_ADD(stats_, ancestors, ancestors_time_ns);
    return result;
}

std::vector<hash_digest> mempool::descendants(hash_digest const& txid) const {
    KTH_STATS_INCREMENT(stats_, descendants_calls);
    KTH_STATS_TIME_START(descendants);
    auto result = closure(txid, [this](hash_digest const& h) { return children_of(h); });
    KTH_STATS_TIME_ADD(stats_, descendants, descendants_time_ns);
    return result;
}

std::vector<hash_digest> mempool::all_txids() const {
    KTH_STATS_INCREMENT(stats_, txids_calls);
    KTH_STATS_TIME_START(txids);

    std::vector<hash_digest> result;
    result.reserve(pool_.size());
    pool_.for_each([&](hash_digest const& txid, mempool_entry const&) {
        result.push_back(txid);
    });

    KTH_STATS_TIME_ADD(stats_, txids, txids_time_ns);
    return result;
}

mempool_totals mempool::summary() const {
    KTH_STATS_INCREMENT(stats_, info_calls);
    KTH_STATS_TIME_START(info);

    // On-demand O(n) scan. If getmempoolinfo is ever polled hard over a huge
    // pool, maintain running byte/fee totals in add/remove instead — but the
    // totals are informational (nothing consensus/mining depends on them) so
    // this stays simple until a profile says otherwise.
    mempool_totals totals{0, 0, 0};
    pool_.for_each([&](hash_digest const&, mempool_entry const& e) {
        ++totals.size;
        totals.bytes += e.size;
        totals.total_fee += e.fee;
    });

    KTH_STATS_TIME_ADD(stats_, info, info_time_ns);
    return totals;
}

namespace {

// The copy allocates, so the release must not rest on the body never throwing.
struct low_priority_lease {
    explicit low_priority_lease(prioritized_mutex& mutex) : mutex_(mutex) {
        mutex_.lock_low_priority();
    }
    ~low_priority_lease() { mutex_.unlock_low_priority(); }
    low_priority_lease(low_priority_lease const&) = delete;
    low_priority_lease& operator=(low_priority_lease const&) = delete;
private:
    prioritized_mutex& mutex_;
};

} // namespace

pool_view lease_pool_view(prioritized_mutex& mutex, mempool const& pool) {
    pool_view view;

    low_priority_lease const lease(mutex);
    view.entries.reserve(pool.size());
    pool.for_each([&](mempool_entry const& entry) { view.entries.push_back(entry); });
    view.generation = pool.generation();
    return view;
}

} // namespace kth::blockchain
