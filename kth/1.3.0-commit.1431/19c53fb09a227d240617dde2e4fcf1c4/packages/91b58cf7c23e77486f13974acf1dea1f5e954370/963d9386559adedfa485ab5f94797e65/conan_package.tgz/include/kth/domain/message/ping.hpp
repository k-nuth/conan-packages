// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_MESSAGE_PING_HPP
#define KTH_DOMAIN_MESSAGE_PING_HPP

#include <cstdint>
#include <memory>
#include <string>

#include <kth/domain/define.hpp>
#include <kth/domain/message/version.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/data.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>
#include <kth/domain/concepts.hpp>

namespace kth::domain::message {

struct KD_API ping {
    using ptr = std::shared_ptr<ping>;
    using const_ptr = std::shared_ptr<const ping>;

    static constexpr
    size_t satoshi_fixed_size(uint32_t version) {
        // Before BIP31 a ping carries no nonce.
        return version < version::level::bip31 ? 0 : sizeof(nonce_);
    }

    ping() = default;
    constexpr
    ping(uint64_t nonce)
        : nonce_(nonce)
    {}

    [[nodiscard]]
    friend bool operator==(ping const&, ping const&) = default;

    [[nodiscard]]
    constexpr
    uint64_t nonce() const {
        return nonce_;
    }

    static
    expect<ping> from_data(byte_reader& reader, uint32_t version);
    [[nodiscard]]
    expect<void> to_data(byte_writer& writer, uint32_t version) const;

    [[nodiscard]]
    constexpr
    size_t serialized_size(uint32_t version) const {
        return satoshi_fixed_size(version);
    }

    static
    std::string const command;

    static
    uint32_t const version_minimum;

    static
    uint32_t const version_maximum;

private:
    uint64_t nonce_{0};
};

} // namespace kth::domain::message

#endif
