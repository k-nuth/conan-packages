// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_INFRASTRUCTURE_INFRASTRUCTURE_HPP_
#define KTH_INFRASTRUCTURE_INFRASTRUCTURE_HPP_

/**
 * API Users: Include only this header. Direct use of other headers is fragile
 * and unsupported as header organization is subject to change.
 *
 * Maintainers: Do not include this header internal to this library.
 */

// Compiler constraints - must be first to fail early on incompatible compilers
#include <kth/infrastructure/compiler_constraints.hpp>

#include <kth/infrastructure/compat.h>
#include <kth/infrastructure/compat.hpp>
#include <kth/infrastructure/constants.hpp>
#include <kth/infrastructure/define.hpp>
#include <kth/infrastructure/error.hpp>
#include <kth/infrastructure/handlers.hpp>
#include <kth/infrastructure/path.hpp>

#include <kth/infrastructure/config/authority.hpp>
#include <kth/infrastructure/config/base16.hpp>
#include <kth/infrastructure/config/base2.hpp>
#include <kth/infrastructure/config/base58.hpp>
#include <kth/infrastructure/config/base64.hpp>
#include <kth/infrastructure/config/checkpoint.hpp>
#include <kth/infrastructure/config/directory.hpp>
#include <kth/infrastructure/config/endpoint.hpp>
#include <kth/infrastructure/config/hash160.hpp>
#include <kth/infrastructure/config/hash256.hpp>

// #include <kth/infrastructure/config/parser.hpp>

#include <kth/infrastructure/config/sodium.hpp>

#include <kth/infrastructure/formats/base_10.hpp>
#include <kth/infrastructure/formats/base_16.hpp>
#include <kth/infrastructure/formats/base_58.hpp>
#include <kth/infrastructure/formats/base_64.hpp>
#include <kth/infrastructure/formats/base_85.hpp>

#include <kth/infrastructure/log/sink.hpp>

#include <kth/infrastructure/machine/number.hpp>
#include <kth/infrastructure/machine/script_version.hpp>
#include <kth/infrastructure/machine/sighash_algorithm.hpp>

#include <kth/infrastructure/math/checksum.hpp>
#include <kth/infrastructure/math/crypto.hpp>
#include <kth/infrastructure/math/elliptic_curve.hpp>
#include <kth/infrastructure/math/hash.hpp>
#include <kth/infrastructure/math/uint256.hpp>

#include <kth/infrastructure/message/message_tools.hpp>
#include <kth/infrastructure/message/messages.hpp>
#include <kth/infrastructure/message/network_address.hpp>

#include <kth/infrastructure/unicode/console_streambuf.hpp>
#include <kth/infrastructure/unicode/file_lock.hpp>
#include <kth/infrastructure/unicode/ifstream.hpp>
#include <kth/infrastructure/unicode/ofstream.hpp>
#include <kth/infrastructure/unicode/unicode.hpp>
#include <kth/infrastructure/unicode/unicode_istream.hpp>
#include <kth/infrastructure/unicode/unicode_ostream.hpp>
#include <kth/infrastructure/unicode/unicode_streambuf.hpp>

#include <kth/infrastructure/utility/asio.hpp>
#include <kth/infrastructure/utility/assert.hpp>
#include <kth/infrastructure/utility/coroutine_config.hpp>
#include <kth/infrastructure/utility/atomic.hpp>
#include <kth/infrastructure/utility/binary.hpp>
#include <kth/infrastructure/utility/collection.hpp>
#include <kth/infrastructure/utility/color.hpp>
#include <kth/infrastructure/utility/conditional_lock.hpp>
#include <kth/infrastructure/utility/container_sink.hpp>
#include <kth/infrastructure/utility/data.hpp>
#include <kth/infrastructure/utility/deadline.hpp>
#include <kth/infrastructure/utility/decorator.hpp>
#include <kth/infrastructure/utility/duration_jitter.hpp>
#include <kth/infrastructure/utility/enable_shared_from_base.hpp>
#include <kth/infrastructure/utility/endian.hpp>
#include <kth/infrastructure/utility/exceptions.hpp>
#include <kth/infrastructure/utility/flush_lock.hpp>
#include <kth/infrastructure/utility/interprocess_lock.hpp>
#include <kth/infrastructure/utility/monitor.hpp>
#include <kth/infrastructure/utility/noncopyable.hpp>
#include <kth/infrastructure/utility/operators.hpp>
#include <kth/infrastructure/utility/ostream_writer.hpp>

#ifdef KTH_WITH_PNG
#include <kth/infrastructure/utility/png.hpp>
#endif

#include <kth/infrastructure/utility/prioritized_mutex.hpp>
#include <kth/infrastructure/utility/pseudo_random.hpp>
#include <kth/infrastructure/utility/reader.hpp>
#include <kth/infrastructure/utility/salted_hashers.hpp>
#include <kth/infrastructure/utility/scope_lock.hpp>
#include <kth/infrastructure/utility/sequential_lock.hpp>
#include <kth/infrastructure/utility/serializer.hpp>
#include <kth/infrastructure/utility/socket.hpp>
#include <kth/infrastructure/utility/string.hpp>
#include <kth/infrastructure/utility/system_memory.hpp>
#if !defined(__EMSCRIPTEN__)
#include <kth/infrastructure/utility/async_channel.hpp>
#include <kth/infrastructure/utility/awaitable_helpers.hpp>
#include <kth/infrastructure/utility/cpu_executor.hpp>
#include <kth/infrastructure/utility/task_group.hpp>
#endif
#include <kth/infrastructure/utility/thread.hpp>
#include <kth/infrastructure/utility/threadpool.hpp>
#include <kth/infrastructure/utility/timer.hpp>
#include <kth/infrastructure/utility/track.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>
#include <kth/infrastructure/utility/writer.hpp>

// #include <kth/infrastructure/wallet/message.hpp>
#include <kth/infrastructure/wallet/uri.hpp>

#ifdef KTH_WITH_QRENCODE
#include <kth/infrastructure/wallet/qrcode.hpp>
#endif

#if ! defined(__EMSCRIPTEN__)
#include <kth/infrastructure/utility/pending.hpp>
#endif

// =============================================================================
// DEPRECATED - moved to deprecated/ folder (see doc/asio.md)
// =============================================================================
// #include <kth/infrastructure/utility/delegates.hpp>
// #include <kth/infrastructure/utility/dispatcher.hpp>
// #include <kth/infrastructure/utility/resubscriber.hpp>
// #include <kth/infrastructure/utility/sequencer.hpp>
// #include <kth/infrastructure/utility/subscriber.hpp>
// #include <kth/infrastructure/utility/synchronizer.hpp>
// #include <kth/infrastructure/utility/work.hpp>

#endif /*KTH_INFRASTRUCTURE_INFRASTRUCTURE_HPP_*/
