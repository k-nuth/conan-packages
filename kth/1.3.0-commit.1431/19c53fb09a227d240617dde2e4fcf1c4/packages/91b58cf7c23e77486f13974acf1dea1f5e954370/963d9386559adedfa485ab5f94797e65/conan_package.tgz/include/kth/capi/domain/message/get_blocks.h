// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_DOMAIN_MESSAGE_GET_BLOCKS_H_
#define KTH_CAPI_DOMAIN_MESSAGE_GET_BLOCKS_H_

#include <stdint.h>

#include <kth/capi/primitives.h>
#include <kth/capi/visibility.h>

#ifdef __cplusplus
extern "C" {
#endif

// Constructors

/** @return Owned `kth_get_blocks_mut_t`. Caller must release with `kth_chain_get_blocks_destruct`. */
KTH_EXPORT KTH_OWNED
kth_get_blocks_mut_t kth_domain_message_get_blocks_construct_default(void);

/** @param[out] out Must point to a null `kth_get_blocks_mut_t` slot. On success, populated with an owned handle that the caller must release via `kth_chain_get_blocks_destruct`. Untouched on error. */
KTH_EXPORT
kth_error_code_t kth_domain_message_get_blocks_construct_from_data(uint8_t const* data, kth_size_t n, uint32_t version, KTH_OUT_OWNED kth_get_blocks_mut_t* out);

/**
 * @return Owned `kth_get_blocks_mut_t`. Caller must release with `kth_chain_get_blocks_destruct`.
 * @param start Borrowed input. Copied by value into the resulting object; ownership of `start` stays with the caller.
 * @param stop Borrowed input; must be non-null. Copied into the resulting object; ownership of `stop` stays with the caller.
 */
KTH_EXPORT KTH_OWNED
kth_get_blocks_mut_t kth_domain_message_get_blocks_construct(kth_hash_list_const_t start, kth_hash_t const* stop);

/**
 * @return Owned `kth_get_blocks_mut_t`. Caller must release with `kth_chain_get_blocks_destruct`.
 * @param start Borrowed input. Copied by value into the resulting object; ownership of `start` stays with the caller.
 * @warning `stop` MUST point to a buffer of at least 32 bytes. Passing a shorter buffer is undefined behavior. Prefer the safe variant (without the `_unsafe` suffix) when your language can pass a pointer to `kth_hash_t`.
 */
KTH_EXPORT KTH_OWNED
kth_get_blocks_mut_t kth_domain_message_get_blocks_construct_unsafe(kth_hash_list_const_t start, uint8_t const* stop);


// Destructor

/** No-op if `self` is null. */
KTH_EXPORT
void kth_domain_message_get_blocks_destruct(kth_get_blocks_mut_t self);


// Copy

/** @return Owned `kth_get_blocks_mut_t`. Caller must release with `kth_chain_get_blocks_destruct`. */
KTH_EXPORT KTH_OWNED
kth_get_blocks_mut_t kth_domain_message_get_blocks_copy(kth_get_blocks_const_t self);


// Equality

KTH_EXPORT
kth_bool_t kth_domain_message_get_blocks_equals(kth_get_blocks_const_t self, kth_get_blocks_const_t other);

KTH_EXPORT
kth_bool_t kth_domain_message_get_blocks_not_equal(kth_get_blocks_const_t self, kth_get_blocks_const_t other);


// Serialization

/** @return Owned byte buffer. Caller must release with `kth_core_destruct_array` (length is written to `out_size`). */
KTH_EXPORT KTH_OWNED
uint8_t* kth_domain_message_get_blocks_to_data(kth_get_blocks_const_t self, uint32_t version, kth_size_t* out_size);

KTH_EXPORT
kth_size_t kth_domain_message_get_blocks_serialized_size(kth_get_blocks_const_t self, uint32_t version);


// Getters

/** @return Borrowed `kth_hash_list_const_t` view into `self`. Do not destruct; the parent object retains ownership. Invalidated by any mutation of `self`. */
KTH_EXPORT
kth_hash_list_const_t kth_domain_message_get_blocks_start_hashes(kth_get_blocks_const_t self);

KTH_EXPORT
kth_hash_t kth_domain_message_get_blocks_stop_hash(kth_get_blocks_const_t self);


// Setters

/** @param value Borrowed input. Copied by value into the resulting object; ownership of `value` stays with the caller. */
KTH_EXPORT
void kth_domain_message_get_blocks_set_start_hashes(kth_get_blocks_mut_t self, kth_hash_list_const_t value);

/** @param value Borrowed input; must be non-null. Copied into the resulting object; ownership of `value` stays with the caller. */
KTH_EXPORT
void kth_domain_message_get_blocks_set_stop_hash(kth_get_blocks_mut_t self, kth_hash_t const* value);

/** @warning `value` MUST point to a buffer of at least 32 bytes. Passing a shorter buffer is undefined behavior. Prefer the safe variant (without the `_unsafe` suffix) when your language can pass a pointer to `kth_hash_t`. */
KTH_EXPORT
void kth_domain_message_get_blocks_set_stop_hash_unsafe(kth_get_blocks_mut_t self, uint8_t const* value);

#ifdef __cplusplus
} // extern "C"
#endif

#endif // KTH_CAPI_DOMAIN_MESSAGE_GET_BLOCKS_H_
