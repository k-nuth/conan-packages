// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_CHAIN_OUTPUT_POINT_HPP
#define KTH_DOMAIN_CHAIN_OUTPUT_POINT_HPP

#include <cstddef>
#include <cstdint>
#include <vector>

#include <kth/domain/chain/output.hpp>
#include <kth/domain/chain/point.hpp>
#include <kth/domain/chain/script.hpp>
#include <kth/domain/define.hpp>
namespace kth::domain::chain {

struct KD_API output_point : point {
public:
    using list = std::vector<output_point>;

    // THIS IS FOR LIBRARY USE ONLY, DO NOT CREATE A DEPENDENCY ON IT.
    struct validation_type {
        /// An output is spent if a valid transaction has a valid claim on it.
        /// When validating blocks only long chain blocks can have a claim.
        /// When validating memory pool tx another mempool tx can have a claim.
        bool spent = false;

        /// A spend is confirmed if spender is in long chain (not memory pool).
        bool confirmed = false;

        /// The previous output is a coinbase (must verify spender maturity).
        bool coinbase = false;

        /// Prevout height is used for coinbase maturity and relative lock time.
        size_t height = 0;

        /// Median time past is used for relative lock time.
        uint32_t median_time_past = 0;

        /// The output cache contains the output referenced by the input point.
        /// If the cache.value is not_found (default) the output is not found.
        output cache = output{};

        //TODO(fernando): add a compilation flag to exclude this...
        /// Tells if the output cache was found in the mempool or in the UTXO Set.
        bool from_mempool = false;
    };

    // Constructors.
    //-------------------------------------------------------------------------

    // NOTE: default ctor produces the coinbase null prevout (null_hash,
    // null_index). Kept because several aggregate types (history,
    // token_genesis_params, utxo, config::point) rely on it as a
    // default-init member; removing it cascades through wallet/cashtoken
    // and the config wrappers. Tracked as a follow-up to fully apply the
    // "valid by construction" pattern (see task list).
    output_point();
    output_point(hash_digest const& hash, uint32_t index);

    output_point(point const& x);
    output_point& operator=(point const& /*x*/);

    // Shadows the inherited `point::null()` so the return type is
    // `output_point`. Without this, `output_point::null()` resolves
    // to the base-class static and slices to `point` — callers (and
    // generated bindings) that expected an `output_point` back end
    // up with a `point`. Forwards to the base factory via the
    // `point`-taking conversion constructor so the coinbase sentinel
    // (`null_hash + null_index`) stays in one place. Not `constexpr`
    // because the `validation_type` member brings in a non-constexpr
    // `output` default, but `noexcept` mirrors `point::null()`.
    [[nodiscard]]
    static
    output_point null() noexcept {
        return output_point{point::null()};
    }

    // Operators.
    //-------------------------------------------------------------------------

    // Comparison operators are inherited from `point` (which has
    // `<=> = default` synthesising `==` / `!=` / `<` / `>` / `<=` / `>=`).
    // `validation` is not a base-class member, so slicing to `point`
    // naturally excludes it from comparisons.

    // Validation.
    //-------------------------------------------------------------------------

    /// True if cached previous output is mature enough to spend from height.
    [[nodiscard]]
    bool is_mature(size_t height) const;

    // THIS IS FOR LIBRARY USE ONLY, DO NOT CREATE A DEPENDENCY ON IT.
    mutable validation_type validation;

// protected:
//     // So that input may call reset from its own.
//     friend class input;
};

} // namespace kth::domain::chain

#endif
