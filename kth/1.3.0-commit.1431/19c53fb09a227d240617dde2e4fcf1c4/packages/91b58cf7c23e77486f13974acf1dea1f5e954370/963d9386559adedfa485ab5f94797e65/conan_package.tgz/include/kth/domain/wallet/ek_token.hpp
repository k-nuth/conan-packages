// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_WALLET_EK_TOKEN_HPP
#define KTH_WALLET_EK_TOKEN_HPP

#include <string>
#include <string_view>

#include <kth/domain/define.hpp>
#include <kth/domain/deserialization.hpp>
#include <kth/domain/wallet/encrypted_keys.hpp>

namespace kth::domain::wallet {

/**
 * BIP38 intermediate passphrase token.
 *
 * Fallible construction goes through `parse_from` which returns
 * `expect<ek_token>`.
 */
struct KD_API ek_token {
    [[nodiscard]]
    static
    expect<ek_token> parse_from(std::string_view encoded);

    explicit constexpr
    ek_token(encrypted_token const& value) noexcept
        : token_(value) {}

    [[nodiscard]]
    friend auto operator<=>(ek_token const& a, ek_token const& b) = default;

    [[nodiscard]] constexpr
    encrypted_token const& token() const noexcept { return token_; }

    [[nodiscard]]
    std::string to_string() const;

private:
    encrypted_token token_;
};

} // namespace kth::domain::wallet

#endif
