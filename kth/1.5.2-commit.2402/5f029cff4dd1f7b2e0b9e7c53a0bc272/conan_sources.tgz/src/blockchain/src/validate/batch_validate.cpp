// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <kth/blockchain/validate/batch_validate.hpp>

#include <algorithm>
#include <atomic>
#include <cstring>
#include <limits>
#include <optional>
#include <thread>
#include <vector>

#include <boost/unordered/unordered_flat_map.hpp>
#include <boost/unordered/unordered_flat_set.hpp>

#include <kth/blockchain/abla_pipeline.hpp>
#include <kth/blockchain/interface/block_chain.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/blockchain/validate/validate_header.hpp>
#include <kth/blockchain/validate/validate_input.hpp>
#include <kth/domain/constants.hpp>
#include <kth/domain/chain/faster_blocks.hpp>
#include <kth/infrastructure/utility/assert.hpp>

namespace kth::blockchain {

using namespace kth::domain::chain;

namespace {

// Key for the intra-batch created-output and spent-output indexes.
struct bv_outpoint {
    hash_digest hash;
    uint32_t index;
    bool operator==(bv_outpoint const& o) const {
        return index == o.index && hash == o.hash;
    }
};

// The store's native key for a domain outpoint.
inline utxoz::raw_outpoint to_raw_outpoint(domain::chain::output_point const& op) {
    auto const h = op.hash();
    return utxoz::make_outpoint(std::span<uint8_t const, 32>{h.data(), 32}, op.index());
}

struct bv_outpoint_hasher {
    size_t operator()(bv_outpoint const& k) const noexcept {
        size_t h;
        std::memcpy(&h, k.hash.data(), sizeof(h));
        return h ^ (size_t(k.index) * 0x9e3779b97f4a7c15ull);
    }
};

// An output produced by a block inside the batch (not yet in UTXO-Z).
struct created_output {
    output const* out;
    size_t height;     // block height that created it
    bool coinbase;
};

// A prevout resolved from UTXO-Z (owns the output by value).
struct db_prevout {
    output out;
    size_t height;
    bool coinbase;
};

// One transaction to script-verify, filled during the serial pass and run in
// parallel. Verifying a whole transaction (rather than a single input) lets the
// signature-checker context be built once per tx instead of once per input.
// Flags are the per-height consensus flags for the block the tx belongs to.
struct verify_task {
    transaction const* tx;
    domain::script_flags_t flags;
    size_t height;   // for diagnostics and per-block SigChecks accounting
};

} // namespace

code enforce_sigcheck_limits(
    std::vector<sigcheck_entry> const& entries,
    std::vector<uint64_t> const& block_limits,
    uint64_t tx_limit) {
    return enforce_sigcheck_limits(entries, block_limits,
        std::vector<uint64_t>(block_limits.size(), tx_limit));
}

code enforce_sigcheck_limits(
    std::vector<sigcheck_entry> const& entries,
    std::vector<uint64_t> const& block_limits,
    std::vector<uint64_t> const& tx_limits) {
    size_t ignored = 0;
    return enforce_sigcheck_limits(entries, block_limits, tx_limits, ignored);
}

code enforce_sigcheck_limits(
    std::vector<sigcheck_entry> const& entries,
    std::vector<uint64_t> const& block_limits,
    std::vector<uint64_t> const& tx_limits,
    size_t& failed_block) {

    KTH_CONTRACT(tx_limits.size() == block_limits.size());

    std::vector<uint64_t> block_sigchecks(block_limits.size(), 0);
    size_t cur_tx = std::numeric_limits<size_t>::max();
    uint64_t tx_sigchecks = 0;

    for (auto const& e : entries) {
        // Precondition: every entry's block_index addresses block_limits.
        KTH_CONTRACT(e.block_index < block_limits.size());

        if (e.tx_index != cur_tx) {
            cur_tx = e.tx_index;
            tx_sigchecks = 0;
        }
        tx_sigchecks += e.sigchecks;
        if (tx_sigchecks > tx_limits[e.block_index]) {
            failed_block = e.block_index;
            return error::transaction_sigchecks_limit;
        }

        block_sigchecks[e.block_index] += e.sigchecks;
        if (block_sigchecks[e.block_index] > block_limits[e.block_index]) {
            failed_block = e.block_index;
            return error::block_sigchecks_limit;
        }
    }
    return error::success;
}

code validate_block_batch(
    block_chain& chain,
    settings const& settings,
    domain::config::network network,
    std::vector<block_const_ptr> const& blocks,
    size_t start_height) {
    batch_rejection dropped;
    return validate_block_batch(chain, settings, network, blocks, start_height, dropped);
}

code validate_block_batch(
    block_chain& chain,
    settings const& settings,
    domain::config::network network,
    std::vector<block_const_ptr> const& blocks,
    size_t start_height,
    batch_rejection& rejection) {

    if (blocks.empty()) {
        return error::success;
    }

    // Every refusal leaves through one of these two, so the report cannot drift
    // from the verdict. `refuse` names the block; `fault` is for a failure that
    // is not any block's — a store that did not answer, a state that could not
    // be derived — and names none.
    auto const refuse = [&rejection](size_t block, code ec) {
        rejection.block = block;
        return ec;
    };
    auto const fault = [&rejection](code ec) {
        rejection.block.reset();
        return ec;
    };

    // Headers-first sync has already checked the headers, but not the bodies.
    // Reject malformed transactions and block structure before resolving any
    // prevouts or scheduling script verification.
    for (size_t i = 0; i < blocks.size(); ++i) {
        if (auto const ec = blocks[i]->check_body()) {
            return refuse(i, ec);
        }
    }

    // Per-height consensus flags: build every block's chain_state from the
    // header_index, the same construction header validation uses, so each block
    // is judged by the rules of its own height. Using a fixed all-forks flag set
    // would misvalidate historical blocks (e.g. strict-DER before BIP66).
    //
    // Not derived block to block with from_pool_ptr: that transition promotes a
    // POOL state to the block state at the same height — its contract for
    // populate_chain_state — so chained over a batch it kept every block at the
    // first block's height, and a batch that began below an activation validated
    // the blocks above it with the old rules (test/batch_activation_boundary.cpp).
    validate_header const header_validator(settings, network);
    auto const& header_index = chain.headers();

    domain::chain::chain_state::ptr state;
    std::vector<domain::script_flags_t> block_flags(blocks.size());
    // Per-block tick schedule and whether the CHIP-2025-03 coinbase shape rule
    // governs the block. Each comes from that block's OWN branch-local state, so
    // a batch that crosses the activation judges the blocks on either side by
    // their own schedule.
    std::vector<domain::chain::block_ticks> block_schedule(blocks.size());
    std::vector<uint8_t> block_governed(blocks.size(), 0);
    std::vector<uint32_t> block_mtp(blocks.size());
    // Per-block dynamic SigChecks limit (consensus), one per block in the batch.
    std::vector<uint64_t> block_sigcheck_limit(blocks.size());
    // Per-block limit on one transaction's SigChecks: 3000 once the May 2020
    // rules are active at that block's height, 20000 before (see
    // max_tx_sigchecks_before_activation).
    std::vector<uint64_t> block_tx_sigcheck_limit(blocks.size());

#if defined(KTH_CURRENCY_BCH)
    // The ABLA state OF every block in the batch (abla_pipeline.hpp): the
    // persisted state of the connected tip advanced block by block through the
    // sizes of the blocks being validated, at the intervals of their branch.
    // Header validation has no such state, so a limit read from a chain_state
    // built without it would be the floor.
    std::vector<domain::chain::abla::state> abla_states;
    {
        std::vector<uint64_t> sizes(blocks.size());
        for (size_t i = 0; i < blocks.size(); ++i) {
            sizes[i] = blocks[i]->serialized_size(1);
        }
        auto const last_idx = header_index.find(blocks.back()->hash());
        if (last_idx == header_index::null_index) {
            return fault(error::not_found);
        }
        auto states = abla_states_for_batch(chain, settings, network, uint32_t(start_height), sizes, last_idx);
        if ( ! states) {
            return fault(states.error());
        }
        abla_states = std::move(*states);
    }
#endif

    boost::unordered_flat_map<bv_outpoint, created_output, bv_outpoint_hasher> created;
    boost::unordered_flat_set<bv_outpoint, bv_outpoint_hasher> spent;
    std::vector<verify_task> tasks;

    boost::unordered_flat_map<bv_outpoint, db_prevout, bv_outpoint_hasher> db_resolved;

    // This call's OWN batch of unresolved lookups. It never leaves this
    // function, and the store keeps no copy, so nothing here can be consumed by
    // a concurrent transaction validation and nothing of its can arrive here —
    // which is what stopped a foreign key from being read as a missing prevout
    // of this block (#646).
    std::vector<utxoz::lookup_request> pending;

    // The lowest block that spends each key in `pending`, recorded as the
    // lookup is emitted. A proven absence comes back as a key, and this is what
    // turns it into a block to attribute it to.
    boost::unordered_flat_map<utxoz::raw_outpoint, size_t> first_spender;

    // -----------------------------------------------------------------------
    // Full intra-batch created-output index. Under BCH CTOR a tx may spend the
    // output of any other tx in the batch created at its own height or earlier.
    // -----------------------------------------------------------------------
    for (size_t i = 0; i < blocks.size(); ++i) {
        auto const height = start_height + i;
        for (auto const& tx : blocks[i]->transactions()) {
            auto const& outs = tx.outputs();
            auto const txid = tx.hash();
            bool const cb = tx.is_coinbase();
            for (uint32_t oi = 0; oi < outs.size(); ++oi) {
                created.insert({bv_outpoint{txid, oi}, created_output{&outs[oi], height, cb}});
            }
        }
    }

    // -----------------------------------------------------------------------
    // Phase 1 (serial): per-height consensus flags, double-spend detection, and
    // EMIT every UTXO-Z lookup. find()/get_utxo is a two-phase contract — its
    // not_resolved only means "the active versions cannot answer"; the older
    // lookup", NOT "does not exist". So we do not conclude anything here.
    // -----------------------------------------------------------------------
    for (size_t i = 0; i < blocks.size(); ++i) {
        auto const height = start_height + i;
        auto const& block = *blocks[i];

        auto const parent_idx = header_index.find(block.header().previous_block_hash());
        if (parent_idx == header_index::null_index) {
            // Parent header not in the index: cannot build chain_state (the
            // KTH_ASSERT downstream is a no-op in Release, so guard here).
            return fault(error::not_found);
        }
#if defined(KTH_CURRENCY_BCH)
        auto cs = header_validator.chain_state_at(
            block.header(), block.hash(), height, parent_idx, header_index, &abla_states[i]);
#else
        auto cs = header_validator.chain_state_at(
            block.header(), block.hash(), height, parent_idx, header_index);
#endif
        if ( ! cs) {
            // The state for this height could not be built. Like the ABLA
            // derivation above, that is a failure to judge, not a judgement.
            return fault(cs.error());
        }
        state = std::move(*cs);
        if ( ! state) {
            return fault(error::operation_failed);
        }
        block_flags[i] = state->enabled_flags();
        if (state->is_enabled(domain::machine::script_flags::bip34_rule)
            && ! block.is_valid_coinbase_script(height)) {
            return refuse(i, error::coinbase_height_mismatch);
        }
#if defined(KTH_CURRENCY_BCH)
        if (state->is_euclid_enabled()) {
            if ( ! block.is_canonical_ordered()) {
                return refuse(i, error::non_canonical_ordered);
            }
        } else if (block.is_forward_reference()) {
            return refuse(i, error::forward_reference);
        }
#endif

#if defined(KTH_CURRENCY_BCH)
        block_schedule[i] = state->ticks();
#endif
        block_mtp[i] = state->median_time_past();
        if (block.serialized_size(0) > state->dynamic_max_block_size()) {
            return refuse(i, error::block_size_limit);
        }
#if defined(KTH_CURRENCY_BCH)
        block_governed[i] = state->is_faster_blocks_active() ? 1 : 0;
#endif
        // Per-block dynamic SigChecks limit: the ABLA block-size limit at this
        // height divided by the fixed ratio, matching BCHN's
        // GetMaxBlockSigChecksCount(nMaxBlockSize).
        block_sigcheck_limit[i] =
            state->dynamic_max_block_size() / block_maxbytes_maxsigchecks_ratio;
        block_tx_sigcheck_limit[i] =
            script::is_enabled(block_flags[i], domain::machine::script_flags::bch_enforce_sigchecks)
                ? max_tx_sigchecks
                : max_tx_sigchecks_before_activation;

#if defined(KTH_CURRENCY_BCH)
        // Consensus per-transaction size cap, coinbase included and independent
        // of the block size limit.
        for (auto const& tx : block.transactions()) {
            if (tx.serialized_size(true) > max_tx_size) {
                return refuse(i, error::transaction_size_limit);
            }
        }
#endif

        for (auto const& tx : block.transactions()) {
            auto const finality_time = script::is_enabled(block_flags[i], domain::machine::script_flags::bip113_rule)
                ? block_mtp[i] : block.header().timestamp();
            // Coinbase finality is covered too: a non-final input sequence
            // makes its locktime binding like any other transaction's.
            if (!tx.is_final(block_schedule[i], height, finality_time)) {
                return refuse(i, error::block_non_final);
            }
            if (tx.is_coinbase()) {
                continue;
            }
            for (auto const& in : tx.inputs()) {
                auto const& op = in.previous_output();
                bv_outpoint const key{op.hash(), op.index()};

                // Double spend within the batch (or a prevout claimed twice).
                if ( ! spent.insert(key).second) {
                    return refuse(i, error::double_spend);
                }

                // Resolved intra-batch (created at this height or earlier)?
                if (auto const it = created.find(key);
                    it != created.end() && it->second.height <= height) {
                    continue;
                }

                // Otherwise it must come from UTXO-Z. get_utxo() probes the
                // ACTIVE versions only; a miss is kept in a batch THIS call owns
                // and resolved after the loop. Nothing is queued inside the
                // store, so no other component can consume these and none of
                // theirs can arrive here.
                auto const utxo = chain.get_utxo(op, height);
                if (utxo) {
                    db_resolved.insert({key, db_prevout{utxo->output, utxo->height, utxo->coinbase}});
                    continue;
                }
                if (utxo.error() != database::result_code::not_resolved) {
                    // A storage failure, not an answer about this prevout.
                    // Reporting it as a missing input would reject a block over
                    // a disk that did not respond.
                    spdlog::error("[batch_validate] the UTXO store failed reading {}:{}; "
                        "refusing to judge these blocks",
                        encode_hash(op.hash()), op.index());
                    return fault(error::operation_failed);
                }
                auto const raw = to_raw_outpoint(op);
                // try_emplace keeps the first, which is the lowest block: the
                // walk is in height order.
                first_spender.try_emplace(raw, i);
                pending.emplace_back(raw, height);
            }
        }
    }

    // -----------------------------------------------------------------------
    // Second phase: resolve THIS call's batch against the older versions.
    //
    // The batch is ours and stays ours — resolve() borrows the span and keeps
    // nothing. That is what makes the `absent` list below a statement about
    // these prevouts and no one else's: before UTXO-Z 0.10.0 this drained a
    // global queue, so a lookup emitted by a concurrent transaction validation
    // could be consumed here, come back absent, and reject a valid block.
    // -----------------------------------------------------------------------
    if ( ! pending.empty()) {
        auto resolved = chain.utxo_resolve(pending);
        if ( ! resolved) {
            // version_unreadable / catalog_unreadable. A LOCAL storage failure,
            // never a consensus verdict: missing_previous_output says the block
            // spends something that does not exist, which would reject a block
            // that may be perfectly valid and is the kind of answer that gets
            // cached. Nothing was consumed, so this is retryable.
            spdlog::error("[batch_validate] resolving {} prevout lookup(s) failed "
                "(batch {}-{}); refusing to judge these blocks rather than calling "
                "unresolved prevouts missing",
                pending.size(), start_height, start_height + blocks.size() - 1);
            return fault(error::operation_failed);
        }

        // Matched back BY KEY. The lists are deduplicated over distinct keys and
        // are not parallel to `pending`.
        for (auto const& [rk, entry] : resolved->found) {
            bv_outpoint key;
            std::memcpy(key.hash.data(), rk.data(), key.hash.size());
            std::memcpy(&key.index, rk.data() + key.hash.size(), sizeof(key.index));
            db_resolved.insert({key, db_prevout{entry.output(), entry.height(), entry.coinbase()}});
        }

        // `absent` is proven absence and only that — a version that could not be
        // read is an error above, not an entry here. Every one of these keys is
        // a prevout of THIS batch, so a missing one is an invalid block.
        if ( ! resolved->absent.empty()) {
            // The LOWEST block that spends any absent key, not the first key
            // the store happened to list: the list is deduplicated over
            // distinct keys and carries no order a caller may rely on, and two
            // runs over the same batch have to name the same block.
            std::optional<size_t> lowest;
            utxoz::raw_outpoint const* named = nullptr;
            for (auto const& rk : resolved->absent) {
                auto const it = first_spender.find(rk);
                if (it == first_spender.end()) {
                    continue;   // not a key this batch emitted; see below
                }
                if ( ! lowest || it->second < *lowest) {
                    lowest = it->second;
                    named = &rk;
                }
            }
            if ( ! lowest) {
                // Every absent key is one of ours by the resolution's contract,
                // so none of them being ours is the store answering a question
                // this batch did not ask. That is not a verdict on any block.
                spdlog::error("[batch_validate] the resolution reported {} absent key(s) "
                    "this batch never emitted (batch {}-{}); refusing to judge these blocks",
                    resolved->absent.size(), start_height, start_height + blocks.size() - 1);
                return fault(error::operation_failed);
            }
            hash_digest h;
            uint32_t idx;
            std::memcpy(h.data(), named->data(), h.size());
            std::memcpy(&idx, named->data() + h.size(), sizeof(idx));
            spdlog::error("[batch_validate] prevout not found {}:{} spent at height {} "
                "({} missing total, batch {}-{})", encode_hash(h), idx,
                start_height + *lowest, resolved->absent.size(),
                start_height, start_height + blocks.size() - 1);
            return refuse(*lowest, error::missing_previous_output);
        }
    }

    // -----------------------------------------------------------------------
    // Phase 2 (serial): now that every prevout is resolved, check coinbase
    // maturity, fees and coinbase value, and populate each input's prevout cache.
    // -----------------------------------------------------------------------
    for (size_t i = 0; i < blocks.size(); ++i) {
        auto const height = start_height + i;
        uint64_t block_fees = 0;
        uint64_t coinbase_value = 0;
        auto const& ticks = block_schedule[i];

        // CHIP-2025-03: from the block built on H_a, a coinbase with version 1,
        // locktime 0 and outputs of at least 25 BCH is invalid.
        if (block_governed[i] != 0 && blocks[i]->has_forbidden_coinbase_shape()) {
            return refuse(i, error::coinbase_shape);
        }

        for (auto const& tx : blocks[i]->transactions()) {
            if (tx.is_coinbase()) {
                for (auto const& o : tx.outputs()) {
                    coinbase_value += o.value();
                }
                continue;
            }

            uint64_t in_value = 0;
            uint64_t out_value = 0;
            for (auto const& o : tx.outputs()) {
                out_value += o.value();
            }

            auto const& inputs = tx.inputs();
            for (uint32_t ii = 0; ii < inputs.size(); ++ii) {
                auto const& op = inputs[ii].previous_output();
                bv_outpoint const key{op.hash(), op.index()};

                output const* out = nullptr;
                size_t prevout_height = 0;
                bool prevout_coinbase = false;

                if (auto const it = created.find(key);
                    it != created.end() && it->second.height <= height) {
                    out = it->second.out;
                    prevout_height = it->second.height;
                    prevout_coinbase = it->second.coinbase;
                } else if (auto const it2 = db_resolved.find(key); it2 != db_resolved.end()) {
                    out = &it2->second.out;
                    prevout_height = it2->second.height;
                    prevout_coinbase = it2->second.coinbase;
                } else {
                    // Neither created in this batch nor resolved from the store,
                    // and the resolution above already returned every absence it
                    // proved. Reaching here means this prevout was never asked
                    // about, which is a defect in the collection loop rather
                    // than a fact about the block — so it is reported as a local
                    // failure, not as a consensus verdict.
                    spdlog::error("[batch_validate] prevout {}:{} spent@{} was never resolved "
                        "(batch_start={}, utxo_size={}); refusing to judge these blocks",
                        encode_hash(op.hash()), op.index(), height, start_height,
                        // A store that will not answer its size is itself worth
                        // seeing here, so the code is printed rather than a
                        // number that would read as an empty set.
                        chain.utxo_count()
                            .transform([](size_t n) { return std::to_string(n); })
                            .value_or(std::string("unavailable")));
                    return fault(error::operation_failed);
                }

                // 100 ten-minute block-equivalents, in ticks.
                if (prevout_coinbase &&
                    ticks.height_to_tick(height) - ticks.height_to_tick(prevout_height) < coinbase_maturity * base_block_interval) {
                    return refuse(i, error::coinbase_maturity);
                }

                op.validation.cache = *out;
                op.validation.coinbase = prevout_coinbase;
                op.validation.height = prevout_height;
                op.validation.median_time_past = 0;
                auto const& in = inputs[ii];
                if (script::is_enabled(block_flags[i], domain::machine::script_flags::bip68_rule)
                    && tx.version() >= relative_locktime_min_version
                    && !(in.sequence() & relative_locktime_disabled)
                    && (in.sequence() & relative_locktime_time_locked)) {
                    // BIP68 measures time from the funding block's parent MTP,
                    // on the same branch as the block being validated. This
                    // also handles CTOR parents created in the current block.
                    auto const parent_idx = header_index.find(blocks[i]->header().previous_block_hash());
                    auto const funding_parent = prevout_height == 0 ? 0 : prevout_height - 1;
                    auto const funding_mtp = domain::chain::median_time_past_at(funding_parent,
                        [&](size_t h) -> std::optional<uint32_t> {
                            auto const idx = header_index.get_ancestor(parent_idx, int32_t(h));
                            if (idx == header_index::null_index) {
                                return std::nullopt;
                            }
                            return header_index.get_timestamp(idx);
                        });
                    if (!funding_mtp) {
                        return fault(error::operation_failed);
                    }
                    op.validation.median_time_past = *funding_mtp;
                }
                op.validation.spent = false;
                op.validation.confirmed = true;

                in_value += out->value();
            }

            if (script::is_enabled(block_flags[i], domain::machine::script_flags::bip68_rule)
                && tx.is_locked(ticks, height, block_mtp[i])) {
                return refuse(i, error::sequence_locked);
            }

            if (in_value < out_value) {
                return refuse(i, error::spend_exceeds_value);
            }
            block_fees += (in_value - out_value);

            // One script-verification unit per transaction (all its inputs share
            // one signature-checker context).
            tasks.push_back(verify_task{&tx, block_flags[i], height});
        }

        auto const reward = block::subsidy(ticks, height, settings.retarget) + block_fees;
        if (coinbase_value > reward) {
            return refuse(i, error::coinbase_value_limit);
        }
    }

    // -----------------------------------------------------------------------
    // Phase 2 (parallel): script/signature verification, one transaction per task
    // (its inputs share a signature-checker context). Independent now that every
    // prevout cache is populated; split across the hardware. Each transaction's
    // total SigChecks is recorded and enforced against the per-tx / per-block
    // limits in Phase 3 below.
    // -----------------------------------------------------------------------
    if (tasks.empty()) {
        return error::success;
    }

#if defined(KTH_BROWSER_NODE)
    unsigned hw = 1; // The Worker owns validation; no hidden native thread creation.
#else
    unsigned hw = std::thread::hardware_concurrency();
#endif
    size_t const workers = std::max<size_t>(1, std::min<size_t>(hw ? hw : 1, tasks.size()));

    // One verdict per task, written only by the worker that ran it and read
    // only after the join. Which task the batch is refused for is decided by a
    // scan of this vector in emission order — height order — and not by which
    // worker reported first.
    std::vector<code> task_errors(tasks.size(), error::success);
    // Total SigChecks per transaction; each worker writes its own slot (no contention).
    std::vector<size_t> task_sigchecks(tasks.size(), 0);

    // The lowest height a failure has been seen at. A worker skips the tasks
    // of HIGHER blocks once this is set — none of them can be the attributed
    // block, so the early exit for the rest of the batch is kept — but goes on
    // judging tasks at or below it, so every transaction that could lower the
    // attribution is judged. That is what makes the scan below name the same
    // block and the same code on every run, whatever the interleaving.
    std::atomic<size_t> failed_height{std::numeric_limits<size_t>::max()};
    std::atomic<bool> threw{false};

    auto run_bucket = [&](size_t bucket) {
      try {
        // A stride visits tasks in increasing index, and tasks are emitted in
        // height order, so once a task is above the failed height every later
        // one in this stride is too.
        for (size_t t = bucket; t < tasks.size(); t += workers) {
            auto const& task = tasks[t];
            if (threw.load(std::memory_order_relaxed) ||
                task.height > failed_height.load(std::memory_order_acquire)) {
                break;
            }
            auto const res = validate_input::verify_transaction(*task.tx, task.flags);
            if (res.first != error::success) {
                task_errors[t] = res.first;
                auto seen = failed_height.load(std::memory_order_acquire);
                while (task.height < seen &&
                       ! failed_height.compare_exchange_weak(seen, task.height,
                             std::memory_order_acq_rel, std::memory_order_acquire)) {
                }
                continue;
            }
            task_sigchecks[t] = res.second;
        }
      } catch (std::exception const& e) {
        // A worker thread must not let an exception escape (std::terminate).
        if ( ! threw.exchange(true)) {
            spdlog::error("[batch_validate] script verification threw: {}", e.what());
        }
      }
    };

    std::vector<std::thread> pool;
    pool.reserve(workers - 1);
    for (size_t w = 1; w < workers; ++w) {
        pool.emplace_back(run_bucket, w);
    }
    run_bucket(0);
    for (auto& th : pool) {
        th.join();
    }

    if (threw.load(std::memory_order_acquire)) {
        // Not a verdict on any block: a worker did not finish judging.
        return fault(error::operation_failed);
    }

    // The first refused transaction in emission order. Every task at or below
    // the lowest failing height was judged (see run_bucket), so the first
    // failure the scan meets is the lowest one there is.
    for (size_t t = 0; t < tasks.size(); ++t) {
        if (task_errors[t] == error::success) {
            continue;
        }
        auto const& task = tasks[t];
        // Re-run per input to pinpoint the culprit and emit a decisive
        // diagnostic (everything needed to reproduce it in a standalone
        // verify_script test). Only on failure, so it is off the hot path.
        auto const& inputs = task.tx->inputs();
        for (uint32_t ii = 0; ii < inputs.size(); ++ii) {
            if (validate_input::verify_script(*task.tx, ii, task.flags).first == error::success) {
                continue;
            }
            auto const& pv = inputs[ii].previous_output();
            spdlog::error("[batch_validate] script FAIL h={} err={} flags={:#x} tx={} in={} prevout={}:{} value={} prevout_script={} input_script={}",
                task.height, task_errors[t].message(),
                uint64_t(task.flags),
                encode_hash(task.tx->hash()), ii,
                encode_hash(pv.hash()), pv.index(),
                pv.validation.cache.value(),
                encode_base16(to_data_chunk(pv.validation.cache.script(), false)),
                encode_base16(to_data_chunk(inputs[ii].script(), false)));
            break;
        }
        return refuse(task.height - start_height, task_errors[t]);
    }

    // -----------------------------------------------------------------------
    // Phase 3 (serial): enforce the SigChecks consensus limits from the per-tx
    // totals — the per-transaction limit of the block each transaction is in
    // and the dynamic ABLA limit per block. Each task is one transaction, so
    // there is one entry per task.
    // (BCHN stops as soon as a limiter is exceeded; validating the whole batch
    // first and checking the sums is equivalent for accept/reject, only less
    // DoS-optimal, which is acceptable on the IBD path.)
    // -----------------------------------------------------------------------
    std::vector<sigcheck_entry> entries;
    entries.reserve(tasks.size());
    for (size_t t = 0; t < tasks.size(); ++t) {
        entries.push_back(sigcheck_entry{
            tasks[t].height - start_height,
            t,   // one task is one transaction
            uint64_t(task_sigchecks[t])});
    }
    size_t over_limit = 0;
    if (auto const ec = enforce_sigcheck_limits(
            entries, block_sigcheck_limit, block_tx_sigcheck_limit, over_limit); ec) {
        return refuse(over_limit, ec);
    }
    return error::success;
}

} // namespace kth::blockchain
