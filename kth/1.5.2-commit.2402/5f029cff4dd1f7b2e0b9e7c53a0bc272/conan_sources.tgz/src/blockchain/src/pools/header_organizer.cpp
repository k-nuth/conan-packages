// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <kth/blockchain/pools/header_organizer.hpp>

#include <spdlog/spdlog.h>

#include <kth/infrastructure/utility/stats.hpp>
#include <kth/infrastructure/utility/timer.hpp>

#include <kth/blockchain/parking.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/blockchain/tick_schedule.hpp>
#include <kth/blockchain/validate/validate_header.hpp>
#include <kth/domain.hpp>

namespace kth::blockchain {

// =============================================================================
// Construction
// =============================================================================

header_organizer::header_organizer(header_index& index, settings const& settings,
                                   domain::config::network network)
    : index_(index)
    , validator_(settings, network)
    , finalizer_(index, settings.max_reorg_depth, settings.finalization_delay_seconds,
                 static_cast<int64_t>(zulu_time()))
{}

void header_organizer::note_block_validated(int32_t block_valid_height) {
    // Deep-reorg parking measures against the validated chain, not the header
    // tip, so the organizer has to remember how far blocks actually reach.
    block_valid_height_.store(block_valid_height, std::memory_order_release);

    auto const before = finalizer_.finalized_height();
    // The active height map names the branch whose blocks are connected. The
    // best header tip can be ahead or on a different unconnected branch.
    auto const validated_tip = block_valid_height < 0
        ? header_index::null_index : index_.active_at(block_valid_height);
    if (validated_tip == header_index::null_index) {
        return;
    }
#if defined(KTH_CURRENCY_BCH)
    auto const schedule = tick_schedule_for_tip(validator_, index_, validated_tip);
    if (!schedule) {
        spdlog::warn("[header_organizer] Finalization deferred: no schedule for validated height {}",
            block_valid_height);
        return;
    }
    finalizer_.maybe_advance(validated_tip, block_valid_height,
        static_cast<int64_t>(zulu_time()), *schedule);
#else
    finalizer_.maybe_advance(validated_tip, block_valid_height, static_cast<int64_t>(zulu_time()));
#endif
    auto const after = finalizer_.finalized_height();
    if (after != before) {
        spdlog::info("[header_organizer] Finalized block advanced to height {}", after);
    }
}

// =============================================================================
// Lifecycle
// =============================================================================

bool header_organizer::start() {
    stopped_ = false;
    return true;
}

bool header_organizer::stop() {
    stopped_ = true;
    return true;
}

// =============================================================================
// Initialization
// =============================================================================

void header_organizer::sync_tip() {
    // Tip = entry with maximum cumulative chain_work. The header_index
    // now stores chain_work as uint256_t (computed from header bits via
    // header_basis::proof), so this is the canonical Bitcoin tip even
    // when forks coexist in the index. Tie-break on the lowest index_t,
    // which corresponds to the entry that landed first.
    auto const size = index_.size();
    if (size == 0) {
        return;
    }

    index_t best_idx = header_index::null_index;
    uint256_t best_work{};
    for (index_t i = 0; i < index_t(size); ++i) {
        if (index_.has_status(i, header_status::failed_valid) ||
            index_.has_status(i, header_status::failed_child)) {
            continue;
        }
        auto const w = index_.get_chain_work(i);
        if (best_idx == header_index::null_index || w > best_work) {
            best_work = w;
            best_idx = i;
        }
    }
    if (best_idx == header_index::null_index) {
        spdlog::critical("[header_organizer] No non-failed header is available at startup");
        return;
    }
    {
        std::lock_guard<std::mutex> const lock(tip_mutex_);
        tip_index_.store(best_idx, std::memory_order_release);

        // Materialize the active chain (height -> index) for this tip. The index also
        // holds side branches, so the rest of the node can only address blocks by
        // height through this mapping.
        index_.active_set_tip(best_idx);
    }

    spdlog::info("[header_organizer] Synced tip: index {}, hash {}, active height {}",
        best_idx, encode_hash(index_.get_hash(best_idx)), index_.active_tip_height());
}

void header_organizer::adopt_tip(index_t tip_idx) {
    if (tip_idx == header_index::null_index) {
        spdlog::error("[header_organizer] adopt_tip called with a null index; keeping tip {}", tip_index());
        return;
    }
    {
        std::lock_guard<std::mutex> const lock(tip_mutex_);
        tip_index_.store(tip_idx, std::memory_order_release);

        // The height mapping moves with the tip, under the same lock. The switch
        // deliberately leaves this to us: publishing it there would let a header
        // batch that validated against the old tip slip its own publication in
        // between, and the two would end up naming different branches.
        //
        // active_set_tip bumps the chain generation when this is a branch change,
        // which is what marks work requested against the old chain as stale.
        index_.active_set_tip(tip_idx);
    }
    spdlog::info("[header_organizer] Adopted tip: index {}, hash {}, height {}, generation {}",
        tip_idx, encode_hash(index_.get_hash(tip_idx)), index_.get_height(tip_idx),
        index_.generation());
}

// =============================================================================
// Header Addition
// =============================================================================

header_organize_result header_organizer::add_headers(domain::message::header::list const& headers) {
    header_organize_result result;

    if (stopped()) {
        result.error = error::service_stopped;
        return result;
    }

    if (headers.empty()) {
        result.error = error::success;
        return result;
    }

    spdlog::debug("[header_organizer] add_headers() called with {} headers", headers.size());

    // One snapshot of the tip for the whole batch: reorg execution can adopt a
    // new one while this runs, and deciding "extends the tip" against one value
    // and anchoring against another would store the batch on the wrong parent.
    // Whether it is still the tip when the batch is published is re-checked below.
    auto const tip_idx = tip_index();
    if (tip_idx == database::header_index::null_index) {
        spdlog::error("[header_organizer] add_headers() called with uninitialized tip_index_ — call sync_tip() first");
        return {error::operation_failed, 0, 0, 0};
    }
    auto const tip_hash = index_.get_hash(tip_idx);

    // Determine the batch anchor: the index entry the first header builds on.
    //   (1) anchor == tip                        -> forward extension of the active chain.
    //   (2) anchor is a known entry below the tip -> a side branch (fork). Validated
    //       and stored against its OWN ancestor so difficulty / MTP / checkpoint
    //       context is correct, then compared against the tip's work.
    //   (3) anchor unknown                       -> orphan; validation surfaces the
    //       missing-parent error (this is also the old ABC/BCHN duplicate-retry case).
    auto const first_prev_hash = headers.front().previous_block_hash();
    if (index_.is_restored_failure(first_prev_hash)) {
        result.error = error::invalid_previous_block;
        return result;
    }
    bool const extends_tip = (first_prev_hash == tip_hash);

    index_t anchor_idx = tip_idx;
    if ( ! extends_tip) {
        anchor_idx = index_.find(first_prev_hash);
        if (anchor_idx == header_index::null_index) {
            // Unknown parent (orphan): validate against the tip so the missing-parent
            // error is raised and the batch rejected, as before.
            anchor_idx = tip_idx;
        }
    }

    // A header the connect path refused in context, or one that descends from
    // such a header. The flag is the index's own, set by the execution layer
    // while the writers are parked and before the tip steps back; `failed_child`
    // is set here, lazily, on a known descendant the moment a batch walks onto
    // it. Nothing builds on either: not a new header, and not a re-sent known
    // one — a known header is skipped below on the strength of having been
    // validated once, and this is the one verdict that came later.
    auto const failed = [this](index_t idx) {
        return idx != header_index::null_index &&
            (index_.has_status(idx, header_status::failed_valid) ||
             index_.has_status(idx, header_status::failed_child));
    };

    // Running parent starts at the anchor (the tip for a forward extension, the fork
    // ancestor for a side branch) and advances as each header is stored.
    index_t parent_idx = anchor_idx;
    index_t branch_head_idx = anchor_idx;
    int32_t height = index_.get_height(anchor_idx) + 1;

    // The anchor is the one entry a batch can name that nothing in this walk
    // has checked. Refused if it is a failed block, and refused — and flagged
    // — if it is the child of one: a descendant stored before its parent was
    // refused carries no flag of its own, and this is where a batch first
    // stands on it. Deeper descendants are caught the same way once their own
    // parent has been flagged, and until then by the coordinator's memory of
    // refused hashes, which filters every switch onto such a branch.
    if (failed(anchor_idx)) {
        // Nothing of the batch is stored and the tip does not move; the
        // publication below is a no-op on the unchanged head, which is what
        // carries the rejection out.
        spdlog::warn("[header_organizer] Rejecting batch anchored on a failed block at height {}",
            index_.get_height(anchor_idx));
        result.error = error::invalid_previous_block;
    } else if (anchor_idx != tip_idx && failed(index_.get_parent_index(anchor_idx))) {
        index_.add_status(anchor_idx, header_status::failed_child);
        spdlog::warn("[header_organizer] Rejecting batch anchored on a descendant of a failed block "
            "at height {}; the descendant is now flagged", index_.get_height(anchor_idx));
        result.error = error::invalid_previous_block;
    }

    // Whether parent_idx is known to descend from the finalized block. A child of a
    // verified parent inherits the property, so a contiguous run of new headers costs
    // one ancestor walk instead of one per header. Jumping to an already-known header
    // (the `continue` below) moves the parent anywhere in the index, so it clears this.
    bool parent_descends_finalized = false;

    spdlog::debug("[header_organizer] Starting validation at height {}, anchor_index {}, extends_tip {}",
        height, anchor_idx, extends_tip);

    for (auto const& header : headers) {
        if (result.error) {
            break;      // anchored on a failed block: nothing of this batch is looked at
        }

        // Compute hash first (needed for validation)
        KTH_STATS_TIME_START(hash);
        auto const hash = domain::chain::hash(header);
        KTH_STATS_TIME_END(global_sync_stats(), hash, hash_time_ns, hash_calls);

        if (index_.is_restored_failure(hash)) {
            result.error = error::duplicate_block;
            break;
        }

        // Already known (duplicate/retry batch, or a re-announced branch header): it
        // was validated when first added, so skip re-validation and just advance the
        // running parent. Resync the height from the stored entry. This also covers
        // the below-tip retry batch the old early-return special-cased.
        if (auto const known_idx = index_.find(hash); known_idx != header_index::null_index) {
            // Known is not enough to follow. The running parent only ever moves
            // along the batch's own chain of previous-hashes: a known header
            // that is not the running parent's child would move it to an
            // arbitrary entry, and with the batch extending the tip, publish
            // that entry as the tip without a single check — any branch at all,
            // including one behind a refused block.
            // A known first header establishes the batch's starting point.
            // Its parent need not be in the index (for example a retry starting
            // at the stored root); the tip fallback is not its claimed parent.
            // Subsequent entries must still follow the preceding batch entry.
            if (&header != &headers.front() && index_.get_parent_index(known_idx) != parent_idx) {
                spdlog::warn("[header_organizer] Rejecting batch: known header at height {} does not "
                    "follow the header before it", index_.get_height(known_idx));
                result.error = error::invalid_previous_block;
                break;
            }
            if (failed(known_idx)) {
                // A refused block offered again. Validated once as a header,
                // refused since as a block: the later verdict stands, and the
                // tip is not moved back onto it.
                spdlog::warn("[header_organizer] Rejecting batch: known header at height {} was "
                    "refused by the connect path", index_.get_height(known_idx));
                result.error = error::duplicate_block;
                break;
            }
            parent_idx = known_idx;
            branch_head_idx = known_idx;
            height = index_.get_height(known_idx) + 1;
            // The parent moved to an arbitrary entry: re-verify before the next new header.
            parent_descends_finalized = false;
            spdlog::debug("[header_organizer] Header already exists at index {}", known_idx);
            continue;
        }

        // A NEW header's parent is the running parent: the anchor, a known
        // header, or a header this batch just added. The first two were
        // refused above if failed, and the batch ended there; the third never
        // is. So a new header never builds on a failed block from here.

        // Header finalization (BCHN ContextualCheckBlockHeader / -finalizeheaders):
        // a NEW header whose parent does not descend from the finalized block extends
        // a branch that forks below finalization. Reject the batch, store nothing more,
        // and signal the caller to penalize the peer. Checked per NEW header (not just
        // the batch anchor) so a getheaders reply that overlaps a known point and then
        // continues onto a sub-finalized branch cannot slip new headers through.
        //
        // Already-known headers took the `continue` above (mirrors BCHN returning early
        // for known headers), so honest stale-retry of buried headers is not penalized.
        // While nothing is finalized yet (startup window / finalization disabled),
        // descends_from_finalized() is always true and nothing is rejected — matching
        // BCHN, where finalization is inactive until the node has been up long enough.
        if ( ! parent_descends_finalized) {
            if ( ! finalizer_.descends_from_finalized(parent_idx)) {
                spdlog::warn("[header_organizer] Rejecting header that forks below the finalized block "
                    "(parent height {}, finalized height {})",
                    index_.get_height(parent_idx), finalizer_.finalized_height());
                result.error = error::finalized_header_violation;
                break;
            }
            parent_descends_finalized = true;
        }

        // Validate header with full chain-state validation against its running parent.
        // This includes: PoW check, difficulty, checkpoint, version, MTP
        KTH_STATS_TIME_START(validate);
        auto const ec = validate_full(header, hash, height, parent_idx);
        KTH_STATS_TIME_END(global_sync_stats(), validate, validate_time_ns, validate_calls);

        if (ec) {
            spdlog::debug("[header_organizer] Header validation failed at height {}: {}",
                height, ec.message());
            result.error = ec;
            break;
        }

        KTH_STATS_TIME_START(index_add);
        auto const add_result = index_.add(hash, header);
        KTH_STATS_TIME_END(global_sync_stats(), index_add, index_add_time_ns, index_add_calls);

        // New header (known ones took the `continue` above), so this always inserts.
        // The parent becomes this header, a child of a parent already verified to
        // descend from the finalized block, so parent_descends_finalized still holds.
        parent_idx = add_result.index;
        branch_head_idx = add_result.index;
        ++height;
        ++result.headers_added;

        // Record wall-clock reception time for the finalization time rule.
        // (Headers loaded from the store at startup keep 0 = immediately eligible.)
        index_.set_received_time(add_result.index, static_cast<uint32_t>(zulu_time()));

        // Mark as valid header
        index_.add_status(add_result.index, header_status::valid_header);

        if (add_result.capacity_warning) {
            spdlog::warn("[header_organizer] Header index at 95% capacity!");
        }
    }

    // Decide the active tip. A forward extension advances it linearly. A side branch
    // only becomes the tip if it has strictly greater cumulative work — and even then
    // the actual switch is deferred to the execution layer, so here we only flag the
    // reorg candidate and keep the coordinator syncing (stale_chain, no forward count).
    bool published = false;
    if (extends_tip) {
        std::lock_guard<std::mutex> const lock(tip_mutex_);
        // Still the tip this batch was validated against? A switch that executed
        // while it validated has already moved the chain and re-pointed the active
        // heights; publishing here would put the abandoned branch back.
        if (tip_index_.load(std::memory_order_acquire) == tip_idx) {
            tip_index_.store(branch_head_idx, std::memory_order_release);
            // Extend the active chain over the headers just linked in. Walks back only
            // as far as the newly added run, since everything below is already active.
            index_.active_set_tip(branch_head_idx);
            published = true;
        } else {
            spdlog::warn("[header_organizer] The tip moved while this batch validated; keeping the "
                "chain the switch published and reporting no progress");
        }
    }

    if ( ! extends_tip && ! result.error) {
        // Under the tip lock, and only while the tip is still the one this batch
        // was validated against. The fork is derived from that tip and the parking
        // rule then reads the active chain: taken from either side of a switch,
        // the two would describe different branches, and the fork would not be an
        // ancestor of the validated tip the rule measures against.
        std::lock_guard<std::mutex> const lock(tip_mutex_);
        auto const branch_work = index_.get_chain_work(branch_head_idx);
        auto const tip_work = index_.get_chain_work(tip_idx);
        if (tip_index_.load(std::memory_order_acquire) != tip_idx) {
            spdlog::warn("[header_organizer] The tip moved while this batch validated; not judging "
                "the branch against a chain that is no longer active");
        } else if (branch_work > tip_work) {
            auto const fork_idx = index_.find_fork(branch_head_idx, tip_idx);
            auto const fork_height = (fork_idx == header_index::null_index)
                ? -1 : index_.get_height(fork_idx);

            // A parked branch is left exactly where it is: stored, still gaining
            // work, not a candidate. The lines below then report the batch as
            // non-advancing, which is already what a heavier branch does.
            if ( ! parked(fork_idx, fork_height, branch_work)) {
                result.reorg_candidate = true;
                result.reorg_branch_head = branch_head_idx;
                result.reorg_fork_height = fork_height;
                spdlog::warn("[header_organizer] Reorg candidate: side branch (head height {}) has "
                    "greater cumulative work than the active tip (height {}); fork at height {}",
                    index_.get_height(branch_head_idx), index_.get_height(tip_idx), fork_height);
            }
        }
        // The active tip did not advance: signal keep-syncing without reporting forward
        // progress (preserves the coordinator contract for stale/duplicate batches).
        result.error = error::stale_chain;
        result.headers_added = 0;
    }

    if (extends_tip && ! published) {
        // Same contract as a batch that did not advance the tip: the coordinator
        // keeps syncing and asks again from wherever the chain now is.
        result.error = error::stale_chain;
        result.headers_added = 0;
    }

    spdlog::debug("[header_organizer] Validation complete: {} headers added, total size {}",
        result.headers_added, index_.size());

    result.index_size = index_.size();
    result.index_memory_bytes = index_.memory_usage();

    return result;
}

bool header_organizer::parked(index_t fork_idx, int32_t fork_height, uint256_t const& branch_work) const {
    // One snapshot for the whole decision: the block-storage path can advance
    // this while the decision is being made, and mixing two readings of it would
    // compare a depth against one height and a threshold against another.
    auto const validated_height = block_valid_height_.load(std::memory_order_acquire);

    // No fork point (disjoint branches — should not happen with a shared genesis)
    // or nothing validated yet: no validated block would be rewound, so there is
    // nothing to park. The disjoint case is reported as fork height -1, which the
    // execution layer refuses anyway.
    if (fork_idx == header_index::null_index || validated_height < 0) {
        return false;
    }

    // Above the validated tip the branch costs no rewind at all.
    if ( ! parking::is_deep_reorg(fork_height, validated_height)) {
        return false;
    }

    auto const validated_tip_idx = index_.active_at(validated_height);
    if (validated_tip_idx == header_index::null_index) {
        // The active chain is mid-switch or shorter than the validated height.
        // Fail closed: refuse to promote a branch against a chain we cannot read.
        spdlog::warn("[header_organizer] Parking branch: no active entry at validated height {}",
            validated_height);
        return true;
    }

#if defined(KTH_CURRENCY_BCH)
    auto const schedule = tick_schedule_for_tip(validator_, index_, validated_tip_idx);
    if (!schedule) {
        spdlog::warn("[header_organizer] Parking branch: no schedule for validated height {}",
            validated_height);
        return true;
    }
    auto const required = parking::required_work(index_, fork_idx, validated_tip_idx, *schedule);
#else
    auto const required = parking::required_work(index_, fork_idx, validated_tip_idx);
#endif
    if (branch_work > required) {
        return false;
    }

    spdlog::warn("[header_organizer] Parking branch forking at height {}: it would rewind {} validated "
        "blocks and has not exceeded the defending chain's work threshold",
        fork_height, validated_height - fork_height);
    return true;
}

// =============================================================================
// State Queries
// =============================================================================

int32_t header_organizer::header_height() const {
    auto const idx = tip_index();
    if (idx == header_index::null_index) {
        return -1;  // No headers yet (only genesis)
    }
    return index_.get_height(idx);
}

uint32_t header_organizer::tip_timestamp() const {
    auto const idx = tip_index();
    if (idx == header_index::null_index) {
        return 0;
    }
    return index_.get_timestamp(idx);
}

// =============================================================================
// Validation
// =============================================================================

code header_organizer::validate_full(domain::chain::header const& header,
                                     hash_digest const& hash,
                                     int32_t height,
                                     header_index::index_t parent_idx) const {
    // First do context-free check (PoW, timestamp not too far in future)
    // Skip PoW check if under checkpoint (trusted headers)
    if (!validator_.is_under_checkpoint(size_t(height))) {
        auto const ec = validator_.check(header);
        if (ec) {
            return ec;
        }
    }

    // Then do full accept validation with chain_state built from header_index
    // This validates: difficulty, checkpoint, version, MTP
    return validator_.accept_full(header, hash, size_t(height), parent_idx, index_);
}

} // namespace kth::blockchain
