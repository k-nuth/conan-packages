// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_BLOCKCHAIN_BLOCK_CHAIN_HPP
#define KTH_BLOCKCHAIN_BLOCK_CHAIN_HPP

#include <atomic>
#include <chrono>
#include <cstddef>
#include <cstdint>
#include <ctime>
#include <filesystem>
#include <functional>
#include <expected>
#include <mutex>
#include <optional>
#include <span>
#include <utility>
#include <vector>
#include <variant>

#include <kth/infrastructure/utility/atomic.hpp>

#include <boost/smart_ptr/atomic_shared_ptr.hpp>
#include <boost/smart_ptr/make_shared.hpp>
#include <boost/smart_ptr/shared_ptr.hpp>
#include <boost/unordered/unordered_flat_map.hpp>
#include <boost/unordered/unordered_flat_set.hpp>

#include <kth/database.hpp>
#include <kth/database/block_store.hpp>
#include <kth/database/databases/utxoz_database.hpp>
#include <kth/domain.hpp>
#include <kth/domain/chain/light_block.hpp>

#include <kth/blockchain/chain_progress.hpp>
#include <kth/blockchain/define.hpp>
#include <kth/blockchain/header_index.hpp>
#include <kth/blockchain/local_block_admission.hpp>
#include <kth/blockchain/utxo_gate.hpp>
#include <kth/blockchain/pools/block_organizer.hpp>
#include <kth/blockchain/pools/branch.hpp>
#include <kth/blockchain/pools/capture_gate.hpp>
#include <kth/blockchain/pools/block_template.hpp>
#include <kth/blockchain/pools/mempool.hpp>
#include <kth/blockchain/pools/mempool_admissions.hpp>
#include <kth/blockchain/pools/mempool_limit.hpp>
#include <kth/blockchain/pools/mempool_transaction_summary.hpp>
#include <kth/blockchain/pools/transaction_organizer.hpp>
#include <kth/blockchain/populate/populate_chain_state.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/blockchain/validate/block_validation.hpp>
#include <kth/blockchain/validate/transaction_validation.hpp>

#include <asio/any_io_executor.hpp>
#include <asio/awaitable.hpp>
#include <stop_token>
#include <asio/experimental/concurrent_channel.hpp>


namespace kth::blockchain {

/// Recency from the validated header tip's timestamp. Pure, so that "cannot be
/// established" is reachable from a test rather than argued about.
[[nodiscard]]
KB_API bool recency_is_stale(std::optional<uint32_t> tip_timestamp, time_t limit_seconds);

/// The startup reconciliation decision, pure for the same reason: an operational
/// read failure cannot be forced out of the database on demand.
[[nodiscard]]
KB_API std::optional<uint32_t> reconcile_tip(
    uint32_t marker_height,
    std::expected<uint32_t, database::result_code> const& built,
    bool utxo_set_is_empty);


using kth::awaitable_expected;
using database::heights_t;

// One pooled transaction's own metadata (== BCHN getmempoolentry scalars; its
// depends / spentby are separate list queries).
struct mempool_entry_info {
    uint64_t fee;   // satoshis
    uint32_t size;  // serialized bytes
    uint64_t time;  // time first seen (unix seconds)
};

/// Unified blockchain interface.
/// Thread safety: get_* methods are NOT thread safe, fetch_* methods are thread safe.
namespace detail { struct block_chain_internal; }

struct KB_API block_chain {
    using executor_type = ::asio::any_io_executor;

    using mempool_mini_hash_map = boost::unordered_flat_map<mini_hash, domain::chain::transaction>;

    // =========================================================================
    // CONSTRUCTION
    // =========================================================================

    block_chain(blockchain::settings const& chain_settings,
                database::settings const& database_settings,
                domain::config::network network,
                bool relay_transactions = true,
                std::shared_ptr<block_submission_channel> submissions = {});

    ~block_chain();

    // Non-copyable, non-movable
    block_chain(block_chain const&) = delete;
    block_chain& operator=(block_chain const&) = delete;
    block_chain(block_chain&&) = delete;
    block_chain& operator=(block_chain&&) = delete;

    // =========================================================================
    // THREAD POOL
    // =========================================================================

    [[nodiscard]] threadpool& thread_pool() { return priority_pool_; }

    // =========================================================================
    // LIFECYCLE
    // =========================================================================

    /// @param disk_magic Magic bytes for block files (e.g., 0xd9b4bef9 for BCH mainnet)
    [[nodiscard]] bool start(uint32_t disk_magic);
    [[nodiscard]] bool stop();
    [[nodiscard]] bool close();
    [[nodiscard]] bool stopped() const;

    // =========================================================================
    // ORGANIZERS (Core blockchain operations)
    // =========================================================================

    /// Submit through the node's existing header/body/connect pipeline.
    /// Success means connected publication, not merely queued or stored.
    /// A standalone chain without an admission owner refuses with service_stopped.
    /// Cancelling the waiter does not roll back work already admitted.
    /// Returns the owner's complete outcome, including invalid-duplicate status.
    /// This is one submission-and-reply operation, never a later result query.
    [[nodiscard]]
    ::asio::awaitable<block_submission_result> submit_block(block_const_ptr block);

    /// Copy a caller-owned block into the admission request before suspension.
    [[nodiscard]]
    ::asio::awaitable<block_submission_result> submit_block(domain::chain::block const& block);

    /// Read rejection identities before admission starts; the coordinator owns the live set.
    [[nodiscard]] awaitable_expected<std::vector<hash_digest>> rejected_blocks() const;
    /// Persist a contextual verdict before publishing it to submitters.
    [[nodiscard]] ::asio::awaitable<code> record_rejected_block(hash_digest hash);

    /// Constructor-bound endpoint; the sync coordinator is its sole consumer.
    [[nodiscard]] block_submission_channel& block_submissions() noexcept;
    [[nodiscard]] bool has_block_submissions() const noexcept { return bool(block_submissions_); }


    /// Fast IBD: merkle validation (+ disk storage when enabled) for blocks under checkpoint.
    /// Posts work to priority_pool_ so network pool stays free for downloads.
    [[nodiscard]]
    ::asio::awaitable<code> organize_fast(std::shared_ptr<domain::chain::light_block const> block, size_t height);

    /// Fast IBD: parallel merkle validation for a chunk of light_blocks.
    /// Posts N merkle checks to priority_pool_ in parallel, awaits all results.
    [[nodiscard]]
    ::asio::awaitable<code> validate_chunk(
        std::vector<std::shared_ptr<domain::chain::light_block const>> const& blocks,
        uint32_t start_height);

    /// Fast IBD: store a validated light_block to flat files + update header_index + LMDB height.
    /// Posts disk I/O to priority_pool_ so the network executor stays free.
    [[nodiscard]]
    ::asio::awaitable<code> store_block(
        std::shared_ptr<domain::chain::light_block const> const& block,
        uint32_t height);

    /// Fast IBD: store an entire chunk of validated light_blocks in a single post to pool.
    /// Eliminates per-block post+await round-trip overhead (1 round-trip instead of N).
    [[nodiscard]]
    ::asio::awaitable<code> store_chunk(
        std::vector<std::shared_ptr<domain::chain::light_block const>> const& blocks,
        uint32_t start_height);

    /// Validate `tx` against the chain and admit it to the mempool: the entry
    /// for every transaction from outside the node (sendrawtransaction, the
    /// peers, the C-API). transaction_validate() validates without admitting.
    [[nodiscard]]
    ::asio::awaitable<code> submit_transaction(transaction_const_ptr tx);

    [[nodiscard]]
    ::asio::awaitable<code> organize(double_spend_proof_const_ptr ds_proof);

    // Headers-first sync: organize a header without full block data
    [[nodiscard]]
    ::asio::awaitable<code> organize_header(header_const_ptr header);

    // Headers-first sync: organize multiple headers in a single batch
    [[nodiscard]]
    code organize_headers_batch(domain::chain::header::list const& headers, size_t start_height);

#if ! defined(KTH_DB_READONLY)
    /// Make the persisted by-height headers describe `headers` from
    /// `start_height` up, and nothing above them. This is how a reorganization
    /// updates that table: all of it or none, so a failed write cannot leave the
    /// replaced range naming two branches at once.
    ///
    /// A write, so it follows the layers below it out of read-only builds.
    /// (organize_headers_batch above is not guarded, and so fails to link
    /// rather than to compile in such a build — pre-existing, left alone here.)
    code replace_headers_from(domain::chain::header::list const& headers, size_t start_height);

    /// Called by the coordinator with writers parked; preserve the retained row.
    [[nodiscard]] code truncate_headers_after(uint32_t height);
#endif // ! defined(KTH_DB_READONLY)

    /// Open the exclusive window over the UTXO store, for ONE logical operation.
    ///
    /// Held from before the first mutation until the set is coherent again — a
    /// connect batch's inserts through its deletions, a rewind's restorations
    /// through its final sweep. Per call would keep readers out of the mappings
    /// and still admit one between the inserts and the deletions, where the set
    /// holds outputs the blocks spent.
    ///
    /// Blocks until every admitted reader has left. Never held across a
    /// suspension point: the mutating stretches it guards are synchronous.
    /// Fails with `recovery_required` once the gate has latched: an operation
    /// that may have left the set half-applied did not finish, and nothing after
    /// it is admitted.
    [[nodiscard]]
    std::expected<utxo_write_window, database::result_code> begin_utxo_write() {
        return utxo_gate_.write();
    }

    /// What the persisted transition record says about the last transition
    /// (#600). Read before anything is mutated: `start()` asks it and refuses
    /// to come up on a database whose last transition did not finish.
    ///
    /// Outside the read-only guard, and deliberately: a build that only reads
    /// still must not serve answers from a UTXO set that may be half-applied.
    [[nodiscard]]
    database::transition_check read_transition_record() const;

#if ! defined(KTH_DB_READONLY)
    [[nodiscard]]
    ::asio::awaitable<code> push(transaction_const_ptr tx);

    [[nodiscard]] code push_sync(transaction_const_ptr tx);
    [[nodiscard]] bool insert(block_const_ptr block, size_t height);

#ifndef KTH_UTXOZ_REFERENCE_MODE
    // Apply a batch of UTXO changes (full mode only — reference mode uses apply_utxo_delta_raw)
    template <database::utxo_insert_range Inserts>
    [[nodiscard]]
    database::result_code apply_utxo_inserts(
        utxo_write_window const& window, Inserts const& inserts) {
        return utxoz_db_.with_write(window,
            [&](auto& db) { return db.apply_inserts(inserts); });
    }
#endif

    // Apply a batch of raw UTXO changes (zero-copy path, no domain objects)
    template <typename Inserts>
    [[nodiscard]]
    database::result_code apply_utxo_inserts_raw(
        utxo_write_window const& window, Inserts const& inserts) {
        auto const code = utxoz_db_.with_write(window,
            [&](auto& db) { return db.apply_inserts_raw(inserts); });
        // The window latches anyway on the way out, because a caller that gets
        // anything but success returns without completing. This closes the gate
        // at the point the store said so, which is what a caller reading the
        // code with needs_recovery() is entitled to assume already happened.
        if (database::needs_recovery(code)) {
            utxo_gate_.latch_observed();
        }
        return code;
    }

    /// Apply a batch of deletions this caller owns. See
    /// utxoz_database::apply_deletes: three-way partition over DISTINCT keys,
    /// matched back BY KEY, and only `unresolved` may be resent.
    [[nodiscard]]
    utxoz::deletion_progress utxo_apply_deletes(
        utxo_write_window const& window,
        std::span<utxoz::deferred_deletion_entry const> requests);

    /// The connected tip to trust at startup, reconciling the two persisted
    /// markers and correcting the stored one when they disagree (#653).
    ///
    /// nullopt means the markers could not be read — an operational failure, not
    /// an absent marker — and start() fails closed on it rather than publishing
    /// chain state at a height nothing vouches for.
    [[nodiscard]]
    std::optional<uint32_t> reconcile_connected_tip(uint32_t marker_height);

    /// Write the CONNECTED tip. Only the batch that connected those blocks may
    /// call it — the storage paths must not, since storing is not connecting —
    /// and the connect path publishes it through publish_transition instead, in
    /// the transaction that also clears the record. What remains here is the
    /// startup reconciliation above, which corrects a marker written by an
    /// earlier version.
    database::result_code set_last_block_height(uint32_t height);

    // Get/set the last block height for which UTXO set was built
    [[nodiscard]]
    std::expected<uint32_t, database::result_code> get_utxo_built_height() const;

    [[nodiscard]]
    database::result_code set_utxo_built_height(uint32_t height);

    // =========================================================================
    // The transition record and the barriers under it (#600)
    // =========================================================================
    //
    // Applying a batch's UTXO delta mutates the maps in place. There is no
    // staging, no transaction and nothing to roll back, so the sequence cannot
    // be made reversible — it is made DETECTABLE instead. A record written
    // before the first mutation and cleared only once every store has been put
    // on stable storage says, at the next start, whether the last transition
    // finished. It never says how to repair one that did not.
    //
    // The order is the mechanism, and every step of it is a barrier that has to
    // be checked. Stated once, here, because it is the same on both paths — the
    // connect batch in node/sync/block_tasks.cpp and the reorganization in
    // switch_to_branch below:
    //
    //   1  begin_transition()                     the gate closes
    //   2  begin_transition_record(...)           one LMDB transaction
    //   3  env_sync()                             or the record is decorative
    //   4  apply the UTXO delta                   the first mutation
    //   5  write the undo records
    //   6  drain the deferred deletions           a failure is fatal, not logged
    //   7  flush_undo(every rev file touched)     not just the last
    //   8  the undo directory                     inside flush_undo
    //   9  utxo_sync()
    //  10  publish_transition(...)                ONE transaction: heights AND clear
    //  11  env_sync()
    //  12  mempool, publish_chain_view(), end_transition()
    //
    // Steps 10 and 11 are what close the window: there is no instant where the
    // height says "arrived" and the record says "clean" separately.

    /// Step 2. Records, durably once step 3 has run, that a transition is about
    /// to mutate the stores.
    [[nodiscard]]
    database::result_code begin_transition_record(database::utxo_transition_record const& record);

    /// A step INSIDE a transition: move the heights in one transaction and
    /// leave the record where it is. A reorganization rolls both heights back
    /// one block at a time, and each of those steps has to be all-or-nothing on
    /// its own without being mistaken for the end of the transition.
    [[nodiscard]]
    database::result_code set_heights(database::transition_heights const& heights);

    /// Step 10. The heights the transition reached and the clearing of its
    /// record, in one transaction.
    [[nodiscard]]
    database::result_code publish_transition(database::transition_heights const& heights);

    /// Step 10 with the ABLA state of every block the transition connected, in
    /// the same transaction (see internal_database::publish_transition). The
    /// state that governs a connected block is durable exactly when the height
    /// that declares it connected is.
    [[nodiscard]]
    database::result_code publish_transition(database::transition_heights const& heights,
                                             std::span<database::header_abla_record const> abla_records);

    /// Steps 3 and 11. The LMDB environment is opened MDB_NOSYNC, so a commit
    /// that returned success has not necessarily reached the disk.
    [[nodiscard]]
    database::result_code env_sync();

    /// Steps 7 and 8. The contents of every rev file the transition wrote, then
    /// the directory entries naming them.
    [[nodiscard]]
    std::expected<void, database::block_store::undo_flush_error>
    flush_undo(std::span<int32_t const> file_numbers);

    /// Step 9. UTXO-Z's own durability barrier, which `close()` does not run,
    /// under the window of the operation it belongs to. Takes the capability
    /// rather than opening its own: the connect batch and the rewind both call
    /// it while still holding theirs, and this gate is deliberately not
    /// recursive.
    [[nodiscard]]
    database::barrier_outcome utxo_sync(utxo_write_window const& window);

    /// What this node may claim about a published transition: the weakest of
    /// the four barriers above, not any one store's answer.
    [[nodiscard]]
    database::durability_level durability() const;
    /// Resolve a batch of typed lookups this caller owns, against the older
    /// versions. Probe with get_utxo()/find first: this does not read the active
    /// versions, so an unprobed key that lives there comes back absent.
    ///
    /// `absent` is proven absence; an error means the resolution could not cover
    /// everything and returns no lists at all, and must never be read as absence.
    /// Results are matched back BY KEY.
    [[nodiscard]]
    std::expected<database::utxoz_database::entry_resolution, database::result_code>
    utxo_resolve(std::span<utxoz::lookup_request const> requests) const;

    /// Probe the ACTIVE versions only. `not_resolved` means the older versions
    /// were not consulted — it is NOT absence, and nothing was queued: keeping
    /// the request and handing it to utxo_resolve_raw() is the caller's job.
    [[nodiscard]]
    std::expected<database::utxoz_database::raw_stored, database::result_code>
    find_utxo_raw(utxoz::raw_outpoint const& key, uint32_t height) const;

    /// Raw counterpart of utxo_resolve(): same ownership and same contract.
    [[nodiscard]]
    std::expected<database::utxoz_database::raw_resolution, database::result_code>
    utxo_resolve_raw(std::span<utxoz::lookup_request const> requests) const;


#if ! defined(KTH_DB_READONLY)
    // Persist a block's undo data and record its position on the header index.
    // The undo record shares the block's file number, so the block must already
    // be stored (have_data) when this is called.
    //
    // Returns WHICH rev file the record landed in, because the caller owes a
    // durability barrier over every file the transition touched and a batch that
    // crosses a rotation writes into more than one. Empty on failure.
    [[nodiscard]]
    std::optional<int32_t> store_block_undo(database::header_index::index_t idx,
                                            database::block_undo const& undo,
                                            hash_digest const& prev_hash);
#endif

    // Read back a block's undo data, if any was recorded.
    [[nodiscard]]
    std::expected<database::block_undo, database::result_code>
    read_block_undo(database::header_index::index_t idx, hash_digest const& prev_hash) const;

#if ! defined(KTH_DB_READONLY)
    // Disconnect the block at `height` from the active chain, reverting its
    // effect on the UTXO set: the outputs it created are removed (recomputed by
    // re-reading the block) and the outputs it spent are restored from its undo
    // data, with their original creation heights.
    //
    // Only the UTXO set and the height markers are touched — the block data stays
    // on disk, so the block can be reconnected without re-downloading. `height`
    // must be the current validated tip: blocks are disconnected one at a time,
    // newest first.
    [[nodiscard]]
    /// @param absence_tolerated Per key, whether a proven absence may be
    ///        tolerated. Derived PER BLOCK from that block's own inverse delta —
    ///        the outputs it created and spent itself — and folded in
    ///        conservatively: the value ANDs across blocks, so one appearance
    ///        that requires the key to exist and be deleted dominates every
    ///        appearance that would excuse it. The batch is applied once at the
    ///        end and UTXO-Z answers once per distinct key, which is exactly why
    ///        a union of "tolerable" would be wrong.
    /// @param pending_deletes Accumulates this block's inverse-delta deletions.
    ///        The rewind owns the batch and applies it once at the end: the
    ///        descent through the version files is paid per batch, not per key.
    database::disconnect_result disconnect_block(uint32_t height,
        utxo_write_window const& window,
        boost::unordered_flat_map<utxoz::raw_outpoint, bool>& absence_tolerated,
        std::vector<utxoz::deferred_deletion_entry>& pending_deletes);

    // Rewind the UTXO state to `fork_height` so the chain can move onto
    // `branch_head`.
    //
    // Disconnects the abandoned blocks newest-first, restoring their spent
    // outputs from undo data, and rolls the height markers back to the fork.
    //
    // It does NOT publish the new branch: the height mapping and the organizer's
    // tip have to move together, under the organizer's lock, or a header batch
    // that validated against the old tip can publish between the two halves and
    // leave them naming different branches. header_organizer::adopt_tip does
    // both; call it as soon as this returns (node::sync::execute_reorg is the
    // one place that owns the whole sequence). Until then the chain still reads
    // as the old branch above the fork, which is why this must run with the
    // writers quiesced.
    //
    // Must be called with the UTXO build quiesced (see reorg_pause below): it
    // rewrites the UTXO set and the height markers.
    // The caller is responsible for re-driving block download for the new branch:
    // its blocks are headers-only at this point, so the validated tip ends at
    // fork_height.
    struct switch_result {
        bool ok{false};
        // Height the validated tip ended at, when it is known. On an aborted
        // disconnect this is how far it got — NOT where it started — so the caller
        // must resync from it. Empty means the tip could not be determined at all
        // (nothing was touched); the caller must then leave its counters alone
        // rather than treat it as height 0.
        std::optional<uint32_t> validated_tip;
        // Whether any block was actually disconnected. Carried rather than
        // inferred: several rejections happen before anything is touched and
        // still report the current tip, so comparing heights cannot tell them
        // from a switch that rewound to where the chain already was. A caller
        // that republished on those would move the generation and drop the
        // template cache for a switch that did nothing.
        bool mutated{false};
        // Whether the node may carry on. A switch can be rejected without
        // anything being wrong — a null head, a fork that is not above the tip —
        // and those are ordinary. This is for the other kind: the transition
        // record could not be written, or could not be made durable, or the
        // switch could not be recorded as finished. Carried rather than inferred
        // from `mutated`, because the first two happen before anything is
        // touched and still leave a database this process must not keep writing
        // to (#600).
        bool fatal{false};
    };

    [[nodiscard]]
    switch_result switch_to_branch(database::header_index::index_t branch_head, uint32_t fork_height);

    // Awaitable form of switch_to_branch: runs the disconnect on priority_pool_
    // instead of the caller's executor. A switch reads, parses and reverts every
    // abandoned block, so running it inline would stall the coordinator coroutine
    // and everything else sharing that executor for the whole reorg.
    [[nodiscard]]
    ::asio::awaitable<switch_result> switch_to_branch_async(
        database::header_index::index_t branch_head, uint32_t fork_height);
#endif

    // =========================================================================
    // Reorg barrier
    // =========================================================================
    //
    // A chain switch rewrites the UTXO set and the active chain while the block
    // pipeline (download -> validation -> storage -> UTXO build) is writing
    // against the chain being abandoned.
    //
    // A pause flag is checked by every participating task between units of work,
    // and a count tracks how many are parked. The switching side raises the pause
    // and waits until every registered participant is parked. A task that is
    // mid-unit finishes it first, so the barrier is only ever crossed at a unit
    // boundary. Unlike a pair of booleans this needs no store-load ordering
    // argument: the count only moves when a task is genuinely parked.
    //
    // Scope, stated plainly: this covers the tasks that write chain state
    // (block storage, UTXO build). The download and validation stages are NOT
    // drained yet — see the PR description.
    //
    // Participation is by explicit registration, not a hardcoded count: the
    // barrier is reached when every task that registered is parked. A task
    // deregisters when it exits, so a retired task neither blocks the barrier
    // forever nor counts as parked.

    void register_reorg_participant() {
        reorg_registered_.fetch_add(1, std::memory_order_seq_cst);
        (void)reorg_barrier_events_.try_send(std::monostate{});
    }
    void unregister_reorg_participant() {
        reorg_registered_.fetch_sub(1, std::memory_order_seq_cst);
        (void)reorg_barrier_events_.try_send(std::monostate{});
    }

    void request_reorg_pause(bool paused) { reorg_pause_.store(paused, std::memory_order_seq_cst); }
    [[nodiscard]] bool reorg_pause_requested() const { return reorg_pause_.load(std::memory_order_seq_cst); }

    // Called by a registered task when it parks at / leaves the barrier.
    void enter_reorg_barrier() {
        reorg_parked_.fetch_add(1, std::memory_order_seq_cst);
        (void)reorg_barrier_events_.try_send(std::monostate{});
    }
    void leave_reorg_barrier() {
        reorg_parked_.fetch_sub(1, std::memory_order_seq_cst);
        (void)reorg_barrier_events_.try_send(std::monostate{});
    }

    /// Coordinator-only wake source. A queued notification retains the debt
    /// to inspect the existing barrier counters; a full channel loses no wake.
    [[nodiscard]] ::asio::experimental::select_channel<std::monostate>&
    reorg_barrier_events() noexcept { return reorg_barrier_events_; }

    // Bumped by each completed switch. Work that was requested against the old
    // chain carries the previous generation; the storage path drops it instead of
    // applying it, which is what makes a stale chunk buffered during the barrier
    // harmless rather than corrupting.
    [[nodiscard]] uint64_t chain_generation() const { return header_index_.generation(); }

    // Parked and registered counts, for a caller that has to report why the
    // barrier was never reached.
    [[nodiscard]] std::pair<size_t, size_t> reorg_barrier_state() const {
        return {reorg_parked_.load(std::memory_order_seq_cst),
                reorg_registered_.load(std::memory_order_seq_cst)};
    }

    [[nodiscard]] bool reorg_barrier_reached() const {
        auto const registered = reorg_registered_.load(std::memory_order_seq_cst);
        // No participants: nothing writes the chain, so the barrier is trivially
        // satisfied (also the state after shutdown).
        return reorg_parked_.load(std::memory_order_seq_cst) >= registered;
    }

    /// Compact the UTXO store.
    /// @return true if compaction ran and succeeded. A caller that ignores this
    ///         is back to the 0.8.0 contract, where compaction could not fail.
    [[nodiscard]]
    /// Compact the UTXO store's version files.
    ///
    /// Replaces `utxo_compact()`, and the rename is the point: the old signature
    /// returned `bool`, in which "the store latched and will refuse everything
    /// from now on" and "there was a problem reclaiming space" are the same
    /// answer. Its one caller logged the second, saying the set was intact.
    ///
    /// A new NAME rather than a new return type on the old one: changing only
    /// the return keeps the mangled symbol on the Itanium ABI while changing how
    /// the value comes back, so an old binary would link and corrupt its stack.
    [[nodiscard]]
    std::expected<void, database::result_code> compact_utxo();
    /// The three UTXO reports. Renamed from `utxo_print_*` for the same reason
    /// as above: a distinct symbol, so the error cannot arrive through a
    /// signature that had nowhere to put it.
    [[nodiscard]] std::expected<void, database::result_code> print_utxo_statistics();
    [[nodiscard]] std::expected<void, database::result_code> print_utxo_sizing_report();
    [[nodiscard]] std::expected<void, database::result_code> print_utxo_height_range_stats();

    // UTXO-Z iteration (for building bloom filter after IBD)
    /// @return false if the walk did not cover the whole set (see
    ///         utxoz_database::for_each_utxo). Nodiscard because the callback
    ///         sees no difference between a complete walk and one that stopped.
    template <typename F>
    [[nodiscard]]
    bool utxo_for_each(utxo_write_window const& window, F&& callback) const {
        // Under the window rather than a lease: a full walk of every version is
        // exactly the shape that must not overlap a mutation, and the bloom
        // filter it feeds decides which keys a later delta may SKIP.
        return utxoz_db_.with_read(window,
            [&](auto const& db) { return db.for_each_utxo(std::forward<F>(callback)); });
    }

    // UTXO-Z size (number of UTXOs in the set)
    [[nodiscard]]
    /// How many UTXOs the store holds.
    ///
    /// Replaces `utxo_size()`, which could only answer with a number — so a
    /// latched store returned 0, and 0 is a real answer meaning "empty".
    [[nodiscard]]
    std::expected<size_t, database::result_code> utxo_count() const;

    // Set/clear bloom filter for skip-insert optimization
    void set_utxo_bloom(std::shared_ptr<database::utxo_bloom_filter const> bloom);
    void clear_utxo_bloom();
#endif

    // =========================================================================
    // CHAIN STATE
    // =========================================================================

    /// The chain state, the tip it describes and the number that labels the
    /// pair — published together, read together.
    ///
    /// Everything a caller needs about the connected chain comes from one
    /// reference. That is not a convenience: the state used to be computed once
    /// at startup and never advance, and the readers that noticed combined it
    /// with a fresh read of the height or the tip hash — a stale value beside a
    /// current one, describing a chain that never existed (#605). With the three
    /// in one immutable object behind one pointer, a reader sees the old triple
    /// or the new one and there is no third possibility to reason about.
    struct published_chain_view {
        /// The context for validating the block after the connected tip, so its
        /// height is the tip's plus one.
        domain::chain::chain_state::ptr state;
        /// The height of the connected tip. Carried rather than derived: every
        /// reader that wanted it was subtracting one from the state's height,
        /// and an off-by-one in a comparison against the header tip is the kind
        /// of thing that reads as "not caught up" forever.
        size_t connected_tip_height;
        /// The hash of the block at the connected tip.
        hash_digest tip_hash;
        /// Advances once per coherent state published — never per internal step,
        /// and monotonically, including a reorganization that moves the tip
        /// down.
        uint64_t generation;
    };

    using chain_view_ptr = boost::shared_ptr<published_chain_view const>;

    /// The published view. Null only before the first publication, which
    /// start() performs.
    [[nodiscard]]
    chain_view_ptr chain_view() const;

    /// Commit an already validated transaction only against the publication it
    /// was validated for. No suspension or script work under the mempool lock.
    [[nodiscard]]
    code commit_validated_transaction(mempool_entry entry, chain_view_ptr const& expected);

    // Metadata relative to a single connected publication. The overload taking
    // a view lets multi-part API responses retain the same reference chain.
    // An unavailable reference leaves both depths at -1; own branch metadata
    // remains available independently of the connected publication.
    [[nodiscard]] std::expected<block_progress, code>
    get_block_progress(hash_digest const& hash, chain_view_ptr const& view) const;
    [[nodiscard]] std::expected<block_progress, code>
    get_block_progress(hash_digest const& hash) const;
    [[nodiscard]] awaitable_expected<block_progress>
    fetch_block_progress(hash_digest const& hash) const;
    [[nodiscard]] awaitable_expected<block_progress>
    fetch_chain_progress() const;


    /// Build the view for `connected_tip_height` and publish it.
    ///
    /// `connected_tip_height` is the last block whose state — the UTXO delta,
    /// the undo records, the by-height header table and the mempool — is
    /// coherently applied. Headers arriving on their own connect nothing, so
    /// they neither publish nor advance the generation.
    ///
    /// The height is the only thing the caller supplies. State and hash are
    /// derived from it here, so a caller cannot assemble a combination that
    /// never existed; the generation advances internally, once.
    ///
    /// Fails rather than keeping the previous view: at the close of a batch or a
    /// reorganization, being unable to publish means the coherent state that was
    /// just reached cannot be described, and the caller must treat that as fatal
    /// rather than carry on against a view that describes an older chain.
    [[nodiscard]]
    code publish_chain_view(size_t connected_tip_height);

    /// Close template capture and wait for the captures already admitted.
    ///
    /// Called before the first mutation of a batch or a reorganization, so that
    /// nothing captures the stores while they are being changed. Returns false
    /// if a transition is already running, which the caller must treat as fatal
    /// rather than proceed: two at once is not a state this has an answer for.
    [[nodiscard]]
    bool begin_transition();

    /// Reopen capture. Only after the transition's state has been published —
    /// a failure leaves the gate closed while the node winds down, which is why
    /// this is a call and not a scope guard.
    void end_transition();

    [[nodiscard]]
    bool transition_in_progress() const;

    /// Whether this node should be serving mining work: it has connected
    /// everything it has headers for, and that tip is recent.
    ///
    /// Two components, because they fail for different reasons and only one is
    /// about the clock. `caught_up` compares the published view's connected tip
    /// against the active header tip — not the stored block marker, which
    /// during a sync sits far ahead of both. `fresh` measures the published
    /// tip's timestamp against the configured limit; a limit of zero disables
    /// that half only, and never turns a node that is behind into one that is
    /// caught up.
    struct sync_status {
        bool caught_up;
        bool fresh;
        [[nodiscard]] bool synchronized() const { return caught_up && fresh; }
    };

    [[nodiscard]]
    sync_status synchronization() const;

    /// Evaluate an already captured tip/header height without loading another
    /// publication. RPC responses can use the same snapshot for all tip fields.
    [[nodiscard]]
    sync_status synchronization(published_chain_view const& view, int32_t header_tip) const;

    /// The state for a branch under consideration, seeded from the published
    /// one. Block validation only; the published view is what everything else
    /// reads.
    domain::chain::chain_state::ptr chain_state(branch::const_ptr branch) const;

    /// Validator-owned side store for transient per-block validation state,
    /// keyed by block hash. This replaces the old mutable `block::validation`
    /// member so the domain value type carries only consensus/wire data.
    block_validation_store& block_validations() const;

    /// Validator-owned side store for transient per-transaction validation
    /// state, keyed by transaction hash. Replaces the old mutable
    /// `transaction::validation` member.
    transaction_validation_store& transaction_validations() const;

    /// The unconfirmed-transaction mempool. Owned here; the organizers admit to
    /// it (tx accept) and evict from it (block connect / reorg).
    // A block was connected: drop the transactions it confirmed and any pooled
    // transaction that conflicts with them (recursively, with descendants).
    //
    // This lives here, and not in the caller, because the mempool's writes are
    // serialized by the validation mutex — the one the transaction organizer
    // holds while admitting. Calling mempool::remove_for_block directly from the
    // block-connect path would race an admission in flight. The lock is taken at
    // high priority: connecting a block takes precedence over admitting, which is
    // what a prioritized mutex is for.
    //
    // The raw form exists for the block-connect path, which holds bytes rather
    // than parsed blocks: it parses only when there is something to remove, and
    // decides that under the lock, so an admission cannot slip in between the
    // decision and the removal. Returns an error if the bytes do not parse,
    // rather than passing for a block with nothing to confirm.
    code mempool_remove_for_block(byte_span raw);

    // The same, for a caller that has already parsed the block.
    void mempool_remove_for_block(domain::chain::block const& block);

    // Expire every pool transaction first seen before `seen_before` (unix
    // seconds), with its descendants. The walk and the removal run on the
    // chain's executor under the validation mutex, like the other mempool
    // writers; the caller only waits for the count of what left the pool.
    ::asio::awaitable<size_t> mempool_expire(uint64_t seen_before);

    // BCHN -mempoolexpiry: until `stop` is requested or the chain stops, every
    // `period` expire what was first seen more than `expiry` ago. Waiting is a
    // timer raced against `stop`, so a stop wakes it; a stop requested before
    // it begins returns without expiring anything.
    ::asio::awaitable<void> run_mempool_expiry(std::chrono::seconds expiry,
        std::chrono::steady_clock::duration period, std::stop_token stop);

    // The fee per 1000 virtual bytes the mempool asks now: 0 until it has been
    // full, then the rate it evicted plus the increment, decaying after blocks.
    [[nodiscard]]
    uint64_t mempool_minimum_fee_per_kb();

    // mempool_minimum_fee_per_kb(), on the chain's executor: the caller waits
    // for the validation lock without holding a thread of its own.
    [[nodiscard]]
    ::asio::awaitable<uint64_t> mempool_minimum_fee();

    // Rung when the mempool's minimum fee may have moved: an eviction raised
    // it, or a block changed how it decays. One slot, so rings coalesce: what
    // it wakes reads the minimum afresh. Closed by stop().
    [[nodiscard]]
    ::asio::experimental::select_channel<std::monostate>& mempool_fee_events() noexcept {
        return mempool_fee_events_;
    }

    // Transactions admitted to the mempool, for announcing them (BCHN relays
    // each one it admits, in the order it admitted them). Each carries its
    // entry_id, increasing with admission; a peer's service walks them from
    // where it last stopped.
    struct mempool_admitted {
        std::vector<mempool_entry> entries;
        uint64_t last;   // the last admission's id, pooled or not
    };

    // Up to `limit` transactions still pooled and admitted after `after`, in
    // order, on the chain's executor under the validation lock.
    [[nodiscard]]
    ::asio::awaitable<mempool_admitted> mempool_admitted_after(uint64_t after, size_t limit);

    // The last admission's id, on the chain's executor; zero before any.
    [[nodiscard]]
    ::asio::awaitable<uint64_t> mempool_last_admission();

    // Everything pooled, in admission order (what was pooled otherwise, with
    // id zero, first), with the last admission's id at the time: a peer's
    // answer to `mempool` (BIP35). On the chain's executor under the
    // validation lock.
    [[nodiscard]]
    ::asio::awaitable<mempool_admitted> mempool_snapshot();

    // Rung when a transaction is admitted. One slot, so rings coalesce: what
    // it wakes reads the last admission afresh. Closed by stop().
    [[nodiscard]]
    ::asio::experimental::select_channel<std::monostate>& mempool_admission_events() noexcept {
        return mempool_admission_events_;
    }

    // A pooled transaction with its entry_id, or nullopt (a peer's `getdata`).
    [[nodiscard]]
    std::optional<mempool_entry> get_mempool_transaction(hash_digest const& txid) const;

    // The mempool's estimated memory, in bytes, as its limit counts it.
    [[nodiscard]]
    uint64_t mempool_usage();

    // Evict down to `limit` bytes now, as admission does past the configured
    // limit. Returns how many transactions left.
    size_t mempool_trim(uint64_t limit);

    blockchain::mempool& mempool_ref();
    blockchain::mempool const& mempool_ref() const;

    // =========================================================================
    // SUBSCRIPTIONS
    // =========================================================================

    using block_channel_ptr = block_organizer::block_broadcaster::channel_ptr;
    using transaction_channel_ptr = transaction_organizer::transaction_broadcaster::channel_ptr;
    using ds_proof_channel_ptr = transaction_organizer::ds_proof_broadcaster::channel_ptr;

    [[nodiscard]]
    block_channel_ptr subscribe_blockchain();
    [[nodiscard]]
    transaction_channel_ptr subscribe_transaction();
    [[nodiscard]]
    ds_proof_channel_ptr subscribe_ds_proof();

    void unsubscribe_blockchain(block_channel_ptr const& channel);
    void unsubscribe_transaction(transaction_channel_ptr const& channel);
    void unsubscribe_ds_proof(ds_proof_channel_ptr const& channel);

    // =========================================================================
    // VALIDATION
    // =========================================================================

    [[nodiscard]]
    ::asio::awaitable<code> transaction_validate(transaction_const_ptr tx) const;

    // =========================================================================
    // PROPERTIES
    // =========================================================================

    /// Timestamp of the validated header tip, or nullopt when it cannot be
    /// established — three distinct ways, all of which answer stale.
    ///
    /// Declared beside is_stale() and OUTSIDE the read-only guard on purpose:
    /// is_stale() is available in a read-only build and calls this, so a
    /// declaration behind the write guard would not compile there. Only
    /// reconcile_connected_tip(), which writes, belongs inside it.
    [[nodiscard]]
    std::optional<uint32_t> active_tip_timestamp() const;

    bool is_stale() const;
    settings const& chain_settings() const;
    executor_type executor() const;

    /// Data directory (parent of internal_db_dir, contains utxoz/, blocks/, etc.)
    [[nodiscard]]
    std::filesystem::path data_dir() const;

    /// Access the header index (for headers-first sync).
    /// True only while the node is hydrating: from the start of block_chain::
    /// start until the header index has been materialised.
    ///
    /// The chain state reads its header from the index, which is the runtime
    /// source of truth. During hydration there is no index to read yet -- start
    /// publishes a chain view before the organizer runs sync_tip(), so
    /// active_at() answers null for every height -- and the durable checkpoint is
    /// the right place to ask.
    ///
    /// Explicit rather than inferred from an absent entry. "The index does not
    /// have it" means one thing while hydrating and something else afterwards:
    /// once the node is running, a header the index cannot produce is a broken
    /// invariant, and quietly answering it from the checkpoint would restore the
    /// dependency this exists to remove (#697).
    [[nodiscard]] bool hydrating() const { return hydrating_.load(std::memory_order_acquire); }



    [[nodiscard]] header_index& headers() { return header_index_; }
    [[nodiscard]] header_index const& headers() const { return header_index_; }


    // =========================================================================
    // DATABASE READERS (Low-level, NOT thread safe)
    // =========================================================================

    [[nodiscard]] std::expected<heights_t, database::result_code> get_last_heights() const;
    [[nodiscard]] std::expected<domain::chain::header, database::result_code> get_header(size_t height) const;
    [[nodiscard]] std::expected<database::header_with_abla_state_t, database::result_code> get_header_and_abla_state(size_t height) const;
    [[nodiscard]] std::expected<domain::chain::header::list, database::result_code> get_headers(size_t from, size_t to) const;
    [[nodiscard]] std::expected<size_t, database::result_code> get_height(hash_digest const& block_hash) const;
    [[nodiscard]] std::expected<uint32_t, database::result_code> get_bits(size_t height) const;
    [[nodiscard]] std::expected<uint32_t, database::result_code> get_timestamp(size_t height) const;
    [[nodiscard]] std::expected<uint32_t, database::result_code> get_version(size_t height) const;
    [[nodiscard]] std::expected<hash_digest, database::result_code> get_block_hash(size_t height) const;
    [[nodiscard]] std::expected<uint256_t, database::result_code> get_branch_work(uint256_t const& maximum, size_t height) const;

    struct output_info {
        domain::chain::output output;
        size_t height;
        uint32_t median_time_past;
        bool coinbase;
    };

    [[nodiscard]] std::expected<output_info, database::result_code> get_utxo(
        domain::chain::output_point const& outpoint, size_t branch_height) const;

    [[nodiscard]] bool header_exists(hash_digest const& block_hash) const;
    [[nodiscard]] bool block_exists(hash_digest const& block_hash) const;

    // =========================================================================
    // FETCH OPERATIONS (Thread safe, coroutine-based)
    // =========================================================================

    // Block fetching. The block is read from the flat files through its
    // header-index record, on the chain's pool rather than the caller's
    // executor. By height: the block on the active chain. By hash: any stored
    // block the index holds, side branches included, with its own height.
    // not_found when the node does not hold the block's data; operation_failed
    // when the stored record cannot be read or is not the block the index names.
    [[nodiscard]] awaitable_expected<std::pair<block_const_ptr, size_t>>
    fetch_block(size_t height) const;

    [[nodiscard]] awaitable_expected<std::pair<block_const_ptr, size_t>>
    fetch_block(hash_digest const& hash) const;

    // Batch fetch: single LMDB transaction for multiple blocks (optimized for UTXO building)
    [[nodiscard]] std::expected<domain::chain::block::list, database::result_code>
    fetch_blocks(uint32_t from, uint32_t to) const;

    // Raw batch fetch: returns serialized block data without deserialization
    [[nodiscard]] std::expected<std::vector<data_chunk>, database::result_code>
    fetch_blocks_raw(uint32_t from, uint32_t to) const;

    [[nodiscard]] awaitable_expected<std::pair<header_ptr, size_t>>
    fetch_block_header(size_t height) const;

    [[nodiscard]] awaitable_expected<std::pair<header_ptr, size_t>>
    fetch_block_header(hash_digest const& hash) const;

    [[nodiscard]] awaitable_expected<size_t>
    fetch_block_height(hash_digest const& hash) const;

    [[nodiscard]] awaitable_expected<std::tuple<hash_digest, uint32_t, size_t>>
    fetch_block_hash_timestamp(size_t height) const;

    [[nodiscard]] awaitable_expected<std::tuple<header_const_ptr, size_t, std::shared_ptr<hash_list>, uint64_t>>
    fetch_block_header_txs_size(hash_digest const& hash) const;

    [[nodiscard]] awaitable_expected<heights_t>
    fetch_last_height() const;

    // Merkle/Compact blocks
    [[nodiscard]] awaitable_expected<std::pair<merkle_block_ptr, size_t>>
    fetch_merkle_block(size_t height) const;

    [[nodiscard]] awaitable_expected<std::pair<merkle_block_ptr, size_t>>
    fetch_merkle_block(hash_digest const& hash) const;

    [[nodiscard]] awaitable_expected<std::pair<compact_block_ptr, size_t>>
    fetch_compact_block(size_t height) const;

    [[nodiscard]] awaitable_expected<std::pair<compact_block_ptr, size_t>>
    fetch_compact_block(hash_digest const& hash) const;

    // Transaction fetching
    [[nodiscard]] awaitable_expected<std::tuple<transaction_const_ptr, size_t, size_t>>
    fetch_transaction(hash_digest const& hash, bool require_confirmed) const;

    [[nodiscard]] awaitable_expected<std::pair<size_t, size_t>>
    fetch_transaction_position(hash_digest const& hash, bool require_confirmed) const;

    [[nodiscard]] awaitable_expected<transaction_const_ptr>
    fetch_unconfirmed_transaction(hash_digest const& hash) const;

    // Locator operations
    [[nodiscard]] awaitable_expected<inventory_ptr>
    fetch_locator_block_hashes(get_blocks_const_ptr locator, hash_digest const& threshold, size_t limit) const;

    [[nodiscard]] awaitable_expected<headers_ptr>
    fetch_locator_block_headers(get_headers_const_ptr locator, hash_digest const& threshold, size_t limit) const;

    [[nodiscard]] awaitable_expected<get_headers_ptr>
    fetch_block_locator(domain::chain::block::indexes const& heights) const;

    // Server queries
    [[nodiscard]] awaitable_expected<double_spend_proof_const_ptr>
    fetch_ds_proof(hash_digest const& hash) const;

    // =========================================================================
    // MEMPOOL / TRANSACTION POOL
    // =========================================================================

    [[nodiscard]] awaitable_expected<blockchain::block_template>
    fetch_template() const;

    // Full mining template (header fields + coinbase value + tx selection) for
    // getblocktemplate[light]. C-API counterpart: kth_chain_async_fetch_mining_template.
    // coinbase_reserve_size is the space held back for the caller's coinbase; a
    // caller with extra coinbase outputs, such as an SV2 CoinbaseOutputDataSize
    // request, raises it above default_coinbase_reserve_size. The reserve is
    // part of the template cache key.
    [[nodiscard]] awaitable_expected<blockchain::mining_template>
    fetch_mining_template(uint64_t coinbase_reserve_size) const;

    // Optional request clock for deterministic callers; nullopt samples wall time.
    awaitable_expected<blockchain::mining_template>
    fetch_mining_template(uint64_t coinbase_reserve_size, std::optional<uint32_t> request_time) const;

    // Mining-relevant chain snapshot (height, difficulty, mempool size, network)
    // for getmininginfo. C-API counterpart: kth_chain_async_fetch_mining_info.
    [[nodiscard]] awaitable_expected<blockchain::mining_info>
    fetch_mining_info() const;

    [[nodiscard]] awaitable_expected<inventory_ptr>
    fetch_mempool(size_t count_limit, uint64_t minimum_fee) const;

    std::vector<mempool_transaction_summary> get_mempool_transactions(std::vector<std::string> const& payment_addresses, bool use_testnet_rules) const;
    std::vector<mempool_transaction_summary> get_mempool_transactions(std::string const& payment_address, bool use_testnet_rules) const;
    std::vector<domain::chain::transaction> get_mempool_transactions_from_wallets(std::vector<domain::wallet::payment_address> const& payment_addresses, bool use_testnet_rules) const;

    mempool_mini_hash_map get_mempool_mini_hash_map(domain::message::compact_block const& block) const;
    void fill_tx_list_from_mempool(domain::message::compact_block const& block, size_t& mempool_count, std::vector<domain::chain::transaction>& txn_available, std::unordered_map<uint64_t, uint16_t> const& shorttxids) const;

    // Mempool query readers, backing the typical BCH JSON-RPC mempool calls.
    hash_list get_mempool_txids() const;                                                             // getrawmempool
    blockchain::mempool_totals get_mempool_info() const;                                             // getmempoolinfo
    std::optional<mempool_entry_info> get_mempool_entry(hash_digest const& txid) const;              // getmempoolentry
    hash_list get_mempool_depends(hash_digest const& txid) const;                                    // getmempoolentry.depends
    hash_list get_mempool_spentby(hash_digest const& txid) const;                                    // getmempoolentry.spentby
    hash_list get_mempool_ancestors(hash_digest const& txid) const;                                  // getmempoolancestors
    hash_list get_mempool_descendants(hash_digest const& txid) const;                                // getmempooldescendants

    // Persist the mempool to <datadir>/mempool.dat (called on shutdown; also
    // backs a future savemempool). Returns false on I/O error.
    bool dump_mempool_to_disk() const;

    // Re-admit the persisted mempool through normal validation against the
    // current tip (called on startup, after the chain is up). Now-invalid /
    // confirmed / conflicting transactions are dropped. Returns the count admitted.
    [[nodiscard]] ::asio::awaitable<size_t> load_mempool_from_disk();

    // =========================================================================
    // FILTERS
    // =========================================================================

    [[nodiscard]] ::asio::awaitable<code>
    filter_blocks(get_data_ptr message) const;

    [[nodiscard]] ::asio::awaitable<code>
    filter_transactions(get_data_ptr message) const;

    domain::chain::chain_state::ptr chain_state() const;

private:
    using handle = database::data_base::handle;

    // Read the block stored at `pos`, which the index names `hash` at `height`,
    // on the chain's pool. Values only: nothing of the index is read after the
    // caller captured them.
    [[nodiscard]] awaitable_expected<std::pair<block_const_ptr, size_t>>
    read_stored_block(hash_digest const& hash, size_t height, database::flat_file_pos pos) const;

    template <typename R>
    void read_serial(R const& reader) const;

    template <typename Handler, typename... Args>
    bool finish_read(handle sequence, Handler handler, Args... args) const;


    // <datadir>/mempool.dat — sibling of the blocks/ and utxoz/ directories.
    std::filesystem::path mempool_dat_path() const;

    /// Whether the last chain transition finished, and therefore whether this
    /// database may be opened for operation at all (#600). Logs the refusal —
    /// the transition's type, id and height range, and an explicit instruction
    /// to rebuild — and does not claim recovery is automatic, because it is not.
    [[nodiscard]]
    bool check_last_transition() const;

#if ! defined(KTH_DB_READONLY)
    /// Step 6 for the reorganization path: apply the deletions the rewind owes,
    /// and refuse the switch unless every one of them is accounted for.
    ///
    /// A rewind's inverse delta erases the outputs the abandoned blocks CREATED.
    /// UTXO-Z 0.10.0 has no single-key erase(): removal is a batch the CALLER
    /// owns, applied once by apply_deletes(), which descends through the version
    /// files searching each for fewer keys than the last. Publishing without
    /// applying it declares the rewind finished while outputs of abandoned
    /// blocks are still in the set — spendable inputs to validation and the
    /// mempool.
    ///
    /// @par The three lists, and why they are three
    /// `erased` is applied, and is a fact even when `error` is set, because the
    /// walk writes as it goes. `absent` is PROVEN not stored, established only
    /// after every version that could hold the key was read; it never stands for
    /// an operational fault. `unresolved` is what is still owed, and the only
    /// category that may be resent — resending an `erased` key asks about
    /// something now genuinely gone, gets `absent` back, and turns this switch's
    /// own success into a refusal.
    ///
    /// @par Why entitlement is not asked of the store
    /// Whether a proven absence is legitimate is a question about the delta this
    /// rewind applied, not about the database: an output created AND spent
    /// inside one abandoned block never entered the set, so failing to erase it
    /// is correct. That is decided from `absence_tolerated`, and nothing in this
    /// path reads the store to decide it — which is also why it cannot race with
    /// a concurrent reader, however that reader is scheduled.
    ///
    /// @par Retries
    /// Bounded, and within THIS operation and this process. An interrupted
    /// transition is refused at the next start and rebuilt, never resumed — see
    /// check_last_transition, and #648 for the journal that would change that.
    ///
    /// @param absence_tolerated Per key, whether a proven absence may be
    ///        tolerated. Built PER BLOCK and folded conservatively, so one
    ///        appearance that requires the key to exist dominates every
    ///        appearance that would excuse it.
    ///
    /// @return false if a proven absence is unaccounted for, if the walk
    ///         reported a fault, or if the obligation outlives its attempts. The
    ///         record then stays and the caller must treat the switch as fatal.
    [[nodiscard]]
    bool sweep_reorg_deletions(uint64_t operation_id,
        utxo_write_window const& window,
        boost::unordered_flat_map<utxoz::raw_outpoint, bool> const& absence_tolerated,
        std::span<utxoz::deferred_deletion_entry const> pending_deletes);

    /// Steps 6 to 11 of the durable order, for the reorganization path: the
    /// deferred deletions, the barriers, then the coherent heights and the
    /// clearing of the transition record in one transaction, then that
    /// transaction onto the disk.
    ///
    /// Step 6 comes first and is not optional (see sweep_reorg_deletions). A
    /// barrier over a set that still owes deletions puts exactly that set on the
    /// disk, so ordering the drain after the sync would make the outputs of
    /// abandoned blocks durable rather than remove them.
    ///
    /// `connected_height` is where the switch actually left the chain, which is
    /// the fork when it completed and the height it stopped at when it did not.
    /// Either way it is a state the stores agree on — which is the only thing
    /// clearing the record asserts.
    ///
    /// @return false if any barrier or the publication failed. The record then
    ///         stays in place and the caller must treat the switch as fatal.
    [[nodiscard]]
    bool publish_reorg_transition(uint32_t connected_height, uint64_t operation_id,
        utxo_write_window const& window,
        boost::unordered_flat_map<utxoz::raw_outpoint, bool> const& absence_tolerated,
        std::span<utxoz::deferred_deletion_entry const> pending_deletes);
#endif

    // Thread safe members
    std::atomic<bool> stopped_;
    std::shared_ptr<block_submission_channel> const block_submissions_;

    // Reorg barrier (see request_reorg_pause / enter_reorg_barrier above).
    std::atomic<bool> reorg_pause_{false};
    std::atomic<size_t> reorg_parked_{0};
    std::atomic<size_t> reorg_registered_{0};
    ::asio::experimental::select_channel<std::monostate> reorg_barrier_events_{1, 1};
    settings const& settings_;
    time_t const notify_limit_seconds_;

    populate_chain_state const chain_state_populator_;
    database::data_base database_;
    // db.nocow: the UTXO-Z directory is created NOCOW on btrfs.
    bool const in_place_nocow_;

    /// The published state on its own. Private: a caller that wants the state
    /// wants the tip and the generation that go with it, and reading them apart
    /// is what produced the combinations #605 was about. The one legitimate use
    /// is seeding a branch's state below.
    mutable capture_gate capture_gate_;

    // One swap publishes the whole triple; see published_chain_view.
    mutable boost::atomic_shared_ptr<published_chain_view const> chain_view_;
    std::atomic<uint64_t> view_generation_{0};

    // Thread safe
    mutable prioritized_mutex validation_mutex_;
    mutable threadpool priority_pool_;


    // Must be declared before block_organizer_: the organizer's block_pool is
    // constructed with a reference to this store.
    mutable block_validation_store block_validations_;
    mutable transaction_validation_store transaction_validations_;

    blockchain::mempool mempool_;
    // The size limit's state. Read and written only under validation_mutex_,
    // like every write to mempool_ (see mempool_limit).
    mempool_limit mempool_limit_;

    // Under validation_mutex_: the limit's bookkeeping for a connected block,
    // and a trim, each ringing mempool_fee_events_ when the minimum moved.
    void note_mempool_block_connected();
    size_t trim_mempool(uint64_t limit);
    ::asio::experimental::select_channel<std::monostate> mempool_fee_events_{1};

    // Under validation_mutex_: the order of admission, and its doorbell.
    mempool_admissions mempool_admissions_;
    ::asio::experimental::select_channel<std::monostate> mempool_admission_events_{1};

    // Immutable template publication. A one-token channel serializes rebuilds
    // across asynchronous input refresh without holding a thread-affine mutex.
    // Requests first try the published cache; after obtaining the token they
    // recapture and check it again. Closing the channel wakes queued requests.
    //
    // boost::atomic_shared_ptr (not std::atomic<std::shared_ptr>): the latter is
    // unsupported on macOS libc++.
    struct template_snapshot {
        blockchain::mining_template value;
        hash_digest previous;
        uint64_t generation;
        uint32_t time;
        uint64_t coinbase_reserve_size;
    };
    mutable boost::atomic_shared_ptr<template_snapshot> template_cache_;
    /// Ends the hydration phase. Called once, by the start path, after the header
    /// index has been materialised. One way only: there is no counterpart that
    /// reopens it, so a run that has begun answering from the index cannot go
    /// back to answering from the checkpoint.
    void end_hydration() { hydrating_.store(false, std::memory_order_release); }

    /// The lock and the cursor behind the single header-persistence writer.
    ///
    /// The cursor is a cache of what was written, never a substitute for it: it
    /// moves forward only after a successful write, so losing it costs a rewrite
    /// and cannot open a gap. Seeded at start from the durable marker, because a
    /// fresh process over an existing datadir otherwise believes nothing is
    /// durable and rewrites the whole table on its first request.
    /// Both are guarded by `header_persist_mutex_` and neither is atomic: the
    /// cursor belongs to the whole critical section, not to a single load. A
    /// public unsynchronised read of it is a data race with the writer, whatever
    /// the reader intends to do with the value.
    [[nodiscard]] std::mutex& header_persist_mutex() { return header_persist_mutex_; }
    [[nodiscard]] uint32_t headers_persisted_through() const { return headers_persisted_through_; }
    void set_headers_persisted_through(uint32_t height) { headers_persisted_through_ = height; }

    friend struct detail::block_chain_internal;

    std::atomic<bool> hydrating_{true};
    std::mutex header_persist_mutex_;
    uint32_t headers_persisted_through_{0};
    // One rebuild owner; queued callers suspend and shutdown wakes them.
    mutable ::asio::experimental::concurrent_channel<void(std::error_code)> template_rebuild_gate_;

    transaction_organizer transaction_organizer_;
    block_organizer block_organizer_;
    header_index header_index_;

    // Flat file block storage (for fast sequential I/O during IBD)
    std::unique_ptr<database::block_store> block_store_;

    // UTXO-Z high-performance UTXO database
    // The gate first: guarded_store holds a pointer to it, so it must outlive
    // the store and therefore be declared before it.
    mutable utxo_gate utxo_gate_;
    guarded_store<database::utxoz_database> utxoz_db_;
};

} // namespace kth::blockchain

#endif // KTH_BLOCKCHAIN_BLOCK_CHAIN_HPP
