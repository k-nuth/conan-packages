// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <kth/blockchain/validate/validate_block.hpp>

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <memory>

#include <kth/blockchain/interface/block_chain.hpp>
#include <kth/blockchain/pools/branch.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/blockchain/validate/validate_header.hpp>
#include <kth/blockchain/validate/validate_input.hpp>
#include <kth/domain.hpp>
#include <kth/domain/multi_crypto_support.hpp>

#include <asio/co_spawn.hpp>
#include <asio/post.hpp>
#include <asio/use_awaitable.hpp>
#include <asio/experimental/concurrent_channel.hpp>

namespace kth::blockchain {

using namespace kd::chain;
using namespace kd::machine;
using kd::script_flags_t;

// Database access is limited to: populator:
// spend: { spender }
// block: { bits, version, timestamp }
// transaction: { exists, height, output }

validate_block::validate_block(executor_type executor, size_t threads, block_chain const& chain, settings const& settings, domain::config::network network, bool relay_transactions)
    : stopped_(true)
    , chain_(chain)
    , network_(network)
    , executor_(std::move(executor))
    , threads_(threads)
    , block_populator_(executor_, threads_, chain, relay_transactions)
{}

// Start/stop sequences.
//-----------------------------------------------------------------------------

void validate_block::start() {
    stopped_ = false;
}

void validate_block::stop() {
    stopped_ = true;
}

// Check.
//-----------------------------------------------------------------------------
// These checks are context free.

::asio::awaitable<code> validate_block::check(block_const_ptr block, bool headers_pre_validated) const {
    // The block hasn't been checked yet.
    if (block->transactions().empty()) {
        co_return error::success;
    }

    // TODO: make configurable for each parallel segment.
    // This one is more efficient with one thread than parallel.
    auto const threads = std::min(size_t(1), threads_);
    auto const count = block->transactions().size();
    auto const buckets = std::min(threads, count);
    KTH_ASSERT(buckets != 0);

    // Use a channel to collect results from parallel tasks
    using result_channel = ::asio::experimental::concurrent_channel<void(std::error_code, code)>;
    auto channel = std::make_shared<result_channel>(executor_, buckets);

    // Launch parallel tasks
    for (size_t bucket = 0; bucket < buckets; ++bucket) {
        ::asio::post(executor_, [this, block, bucket, buckets, channel]() {
            auto result = check_block_bucket(block, bucket, buckets);
            channel->try_send(std::error_code{}, result);
        });
    }

    // Wait for all results
    code final_result = error::success;
    for (size_t i = 0; i < buckets; ++i) {
        auto [ec, result] = co_await channel->async_receive(::asio::as_tuple(::asio::use_awaitable));
        if (ec) {
            co_return error::operation_failed;
        }
        if (result != error::success && final_result == error::success) {
            final_result = result;
        }
    }

    if (final_result) {
        co_return final_result;
    }

    // Run context free checks, sets time internally.
    // For headers-first sync, skip header validation (PoW, timestamp) since
    // headers were already validated during header sync.
    if (headers_pre_validated) {
        co_return block->check_body();
    }
    co_return block->check();
}

code validate_block::check_block_bucket(block_const_ptr block, size_t bucket, size_t buckets) const {
    if (stopped()) {
        return error::service_stopped;
    }

    auto const& txs = block->transactions();

    // Generate each tx hash (stored in tx cache).
    for (auto tx = bucket; tx < txs.size(); tx = ceiling_add(tx, buckets)) {
        txs[tx].hash();
    }

    return error::success;
}

// Accept sequence.
//-----------------------------------------------------------------------------
// These checks require chain state, and block state if not under checkpoint.

::asio::awaitable<code> validate_block::accept(branch::const_ptr branch, bool headers_pre_validated) const {
    auto const block = branch->top();
    KTH_ASSERT(block);

    // Populate chain state for the next block.
    auto const block_state = chain_.chain_state(branch);
    chain_.block_validations().mutate(block->hash(), [&](auto& bv){ bv.state = block_state; });

    if ( ! block_state) {
        co_return error::block_validation_state_failed;
    }

    // Populate block state for the top block (others are valid).
    auto const populate_ec = co_await block_populator_.populate(branch);

    if (stopped()) {
        co_return error::service_stopped;
    }

    if (populate_ec) {
        co_return populate_ec;
    }

    auto const& state = *block_state;

    // Run contextual block non-tx checks (sets start time).
    // For headers-first sync, skip header validation since headers were
    // already validated during header sync.
    if ( ! headers_pre_validated) {
        // Full validation: validate header first
        auto const header_ec = validate_header::accept_header(block->header(), block->hash(), state);
        if (header_ec) {
            co_return header_ec;
        }
    }

    // Validate block body (same for both cases)
    auto const body_ec = accept_block_body(*block, state);
    if (body_ec) {
        co_return body_ec;
    }

    auto const sigops = std::make_shared<atomic_counter>(0);

#if defined(KTH_CURRENCY_BCH)
    bool const bip141 = false;
#else
    auto const bip141 = state.is_enabled(domain::machine::script_flags::bip141_rule);
#endif

    if (state.is_under_checkpoint()) {
        co_return error::success;
    }

    auto const count = block->transactions().size();
    auto const bip16 = state.is_enabled(domain::machine::script_flags::bip16_rule);
    auto const buckets = std::min(threads_, count);
    KTH_ASSERT(buckets != 0);

    // Use a channel to collect results from parallel tasks
    using result_channel = ::asio::experimental::concurrent_channel<void(std::error_code, code)>;
    auto channel = std::make_shared<result_channel>(executor_, buckets);

    // Launch parallel tasks
    for (size_t bucket = 0; bucket < buckets; ++bucket) {
        ::asio::post(executor_, [this, block, bucket, buckets, sigops, bip16, bip141, channel]() {
            auto result = accept_transactions_bucket(block, bucket, buckets, sigops, bip16, bip141);
            channel->try_send(std::error_code{}, result);
        });
    }

    // Wait for all results
    code accept_result = error::success;
    for (size_t i = 0; i < buckets; ++i) {
        auto [ec, result] = co_await channel->async_receive(::asio::as_tuple(::asio::use_awaitable));
        if (ec) {
            co_return error::operation_failed;
        }
        if (result != error::success && accept_result == error::success) {
            accept_result = result;
        }
    }

    if (accept_result) {
        co_return accept_result;
    }

    // Check sigops limit
#if defined(KTH_CURRENCY_BCH)
    if (block_state->is_fermat_enabled()) {
        co_return error::success;
    }

    size_t allowed_sigops = get_allowed_sigops(block->serialized_size(1));
    auto const exceeded = *sigops > allowed_sigops;
#else
    auto const max_sigops = bip141 ? max_fast_sigops : get_allowed_sigops(block->serialized_size(1));
    auto const exceeded = *sigops > max_sigops;
#endif
    co_return exceeded ? error::block_embedded_sigop_limit : error::success;
}

code validate_block::accept_transactions_bucket(block_const_ptr block, size_t bucket, size_t buckets, atomic_counter_ptr sigops, bool bip16, bool bip141) const {
#if defined(KTH_CURRENCY_BCH)
    bip141 = false;
#endif
    if (stopped()) {
        return error::service_stopped;
    }

    code ec(error::success);
    domain::chain::chain_state::ptr state_ptr;
    chain_.block_validations().visit(block->hash(), [&](auto const& bv){ state_ptr = bv.state; });
    KTH_ASSERT(state_ptr);
    auto const& state = *state_ptr;
    auto const flags = state.enabled_flags();
    auto const height = state.height();
    auto const mtp = state.median_time_past();
    auto const max_sigops = state.is_lobachevski_enabled()
        ? state.dynamic_max_block_sigops()
        : static_max_block_sigops(state.network());
    auto const under_checkpoint = state.is_under_checkpoint();
    auto const& txs = block->transactions();
    auto const count = txs.size();

    // Run contextual tx non-script checks (not in tx order).
    // Reads of the transaction_validation_store here are const and race-free:
    // all writes to it were done in the serial populate pre-pass.
    for (auto tx = bucket; tx < count && !ec; tx = ceiling_add(tx, buckets)) {
        auto const& transaction = txs[tx];
        bool validated = false;
        bool duplicate = false;
        chain_.transaction_validations().visit(transaction.hash(), [&](auto const& tv){ validated = tv.validated; duplicate = tv.duplicate; });
        if ( ! validated) {
            ec = transaction.accept(flags, height, mtp, max_sigops, under_checkpoint, false /*transaction_pool*/, duplicate);
        }
        *sigops += transaction.signature_operations(bip16, bip141);
    }

    return ec;
}

// Connect sequence.
//-----------------------------------------------------------------------------
// These checks require chain state, block state and perform script validation.

::asio::awaitable<code> validate_block::connect(branch::const_ptr branch) const {
    auto const block = branch->top();
    KTH_ASSERT(block);
    domain::chain::chain_state::ptr state_ptr;
    chain_.block_validations().visit(block->hash(), [&](auto const& bv){ state_ptr = bv.state; });
    KTH_ASSERT(state_ptr);

    if (state_ptr->is_under_checkpoint()) {
        co_return error::success;
    }

    auto const non_coinbase_inputs = block->total_inputs(false);

    // Return if there are no non-coinbase inputs to validate.
    if (non_coinbase_inputs == 0) {
        co_return error::success;
    }

    auto const buckets = std::min(threads_, non_coinbase_inputs);
    KTH_ASSERT(buckets != 0);

    // Use a channel to collect results from parallel tasks
    using result_channel = ::asio::experimental::concurrent_channel<void(std::error_code, code)>;
    auto channel = std::make_shared<result_channel>(executor_, buckets);

    // Launch parallel tasks
    for (size_t bucket = 0; bucket < buckets; ++bucket) {
        ::asio::post(executor_, [this, block, bucket, buckets, channel]() {
            auto result = connect_inputs_bucket(block, bucket, buckets);
            channel->try_send(std::error_code{}, result);
        });
    }

    // Wait for all results
    code connect_result = error::success;
    for (size_t i = 0; i < buckets; ++i) {
        auto [ec, result] = co_await channel->async_receive(::asio::as_tuple(::asio::use_awaitable));
        if (ec) {
            co_return error::operation_failed;
        }
        if (result != error::success && connect_result == error::success) {
            connect_result = result;
        }
    }

    co_return connect_result;
}

code validate_block::connect_inputs_bucket(block_const_ptr block, size_t bucket, size_t buckets) const {
    KTH_ASSERT(bucket < buckets);
    code ec(error::success);
    domain::chain::chain_state::ptr state_ptr;
    chain_.block_validations().visit(block->hash(), [&](auto const& bv){ state_ptr = bv.state; });
    KTH_ASSERT(state_ptr);
    auto const flags = state_ptr->enabled_flags();
    auto const& txs = block->transactions();
    size_t position = 0;

#if defined(KTH_CURRENCY_BCH)
    size_t block_sigchecks = 0;
#endif

    // Must skip coinbase here as it is already accounted for.
    for (auto tx = txs.begin() + 1; tx != txs.end(); ++tx) {
        bool current = false;
        bool validated = false;
        chain_.transaction_validations().visit(tx->hash(), [&](auto const& tv){ current = tv.current; validated = tv.validated; });

        // The tx is pooled with current fork state so outputs are validated.
        if (current) {
            continue;
        }

        // The tx was validated before its insertion in the mempool
        if (validated) {
            continue;
        }

        size_t input_index;
        auto const& inputs = tx->inputs();

        for (input_index = 0; input_index < inputs.size(); ++input_index, ++position) {
            if (position % buckets != bucket) {
                continue;
            }

            if (stopped()) {
                return error::service_stopped;
            }

            auto const& prevout = inputs[input_index].previous_output();

            if ( ! prevout.validation.cache.is_valid()) {
                ec = error::missing_previous_output;
                break;
            }

            size_t sigchecks;
            std::tie(ec, sigchecks) = validate_input::verify_script(*tx, input_index, flags);
            if (ec != error::success) {
                break;
            }

#if defined(KTH_CURRENCY_BCH)
            block_sigchecks += sigchecks;
            if (block_sigchecks > state_ptr->dynamic_max_block_sigchecks()) {
                ec = error::block_sigchecks_limit;
                break;
            }
#endif
        }

        if (ec) {
            auto const height = state_ptr->height();
            dump(ec, *tx, input_index, flags, height);
            break;
        }
    }

    return ec;
}

// Utility.
//-----------------------------------------------------------------------------

void validate_block::dump(code const& ec, transaction const& tx, uint32_t input_index, script_flags_t flags, size_t height) {
    auto const& prevout = tx.inputs()[input_index].previous_output();
    auto const script = kth::to_data_chunk(prevout.validation.cache.script(), false);
    auto const hash = encode_hash(prevout.hash());
    auto const tx_hash = encode_hash(tx.hash());

    spdlog::debug("[blockchain] Verify failed [{}] : {}\n"
        " flags        : {}\n"
        " outpoint     : {}:{}\n"
        " script       : {}\n"
        " value        : {}\n"
        " inpoint      : {}:{}\n"
        " transaction  : {}",
        height, ec.message(), flags, hash, prevout.index(), encode_base16(script),
        prevout.validation.cache.value(), tx_hash, input_index, encode_base16(kth::to_data_chunk(tx, true)));
}

// =============================================================================
// Static validation functions (pure, no side effects)
// These replace the accept/connect methods that were in block_basis.
// =============================================================================

code validate_block::accept_block_body(
    domain::chain::block const& block,
    domain::chain::chain_state const& state) {

    auto const& header = block.header();
    auto const block_size = block.serialized_size();

    auto const bip16 = state.is_enabled(domain::machine::script_flags::bip16_rule);
    auto const bip34 = state.is_enabled(domain::machine::script_flags::bip34_rule);
    auto const bip113 = state.is_enabled(domain::machine::script_flags::bip113_rule);
    auto const bip141 = false;  // No segwit

    // Block size validation
#if defined(KTH_CURRENCY_BCH)
    if (state.is_lobachevski_enabled()) {
        if (block_size > state.dynamic_max_block_size()) {
            return error::block_size_limit;
        }
    } else if (state.is_pythagoras_enabled()) {
        if (block_size > static_max_block_size(state.network())) {
            return error::block_size_limit;
        }
    } else {
        if (block_size > max_block_size::mainnet_old) {
            return error::block_size_limit;
        }
    }
#else
    if (block_size > max_block_size::mainnet_old) {
        return error::block_size_limit;
    }
#endif

    // Under checkpoint: Only verify merkle root (done in check_body)
    if (state.is_under_checkpoint()) {
        return error::success;
    }

    // Transaction ordering check
#if defined(KTH_CURRENCY_BCH)
    if (state.is_euclid_enabled()) {
        if ( ! block.is_canonical_ordered()) {
            return error::non_canonical_ordered;
        }
    } else {
        if (block.is_forward_reference()) {
            return error::forward_reference;
        }
    }
#else
    if (block.is_forward_reference()) {
        return error::forward_reference;
    }
#endif

    // Coinbase script height check (BIP34)
    if (bip34 && !block.is_valid_coinbase_script(state.height())) {
        return error::coinbase_height_mismatch;
    }

    // Coinbase claim check
    if ( ! block.is_valid_coinbase_claim(state.height())) {
        return error::coinbase_value_limit;
    }

    // Finality check
    auto const block_time = bip113 ? state.median_time_past() : header.timestamp();
    if ( ! block.is_final(state.height(), block_time)) {
        return error::block_non_final;
    }

    // Sigops check (for non-Fermat BCH or BTC/LTC)
#if defined(KTH_CURRENCY_BCH)
    if ( ! state.is_fermat_enabled()) {
#endif
        size_t const allowed_sigops = get_allowed_sigops(block_size);
        if (block.signature_operations(bip16, bip141) > allowed_sigops) {
            return error::block_embedded_sigop_limit;
        }
#if defined(KTH_CURRENCY_BCH)
    }
#endif

    return error::success;
}

} // namespace kth::blockchain
