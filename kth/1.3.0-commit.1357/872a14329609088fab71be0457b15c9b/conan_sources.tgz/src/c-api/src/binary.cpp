// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <string_view>
#include <utility>

#include <kth/capi/binary.h>

#include <kth/capi/conversions.hpp>
#include <kth/capi/helpers.hpp>
#include <kth/infrastructure/utility/binary.hpp>

// File-local alias so `kth::cpp_ref<T>(...)` and friends don't
// spell out the full qualified C++ name at every call site.
namespace {
using cpp_t = kth::binary;
} // namespace

// ---------------------------------------------------------------------------
extern "C" {

// Constructors

kth_binary_mut_t kth_core_binary_construct_default(void) {
    return kth::leak<cpp_t>();
}

kth_binary_mut_t kth_core_binary_construct_from_size_number(kth_size_t size, uint32_t number) {
    auto const size_cpp = kth::sz(size);
    return kth::leak<cpp_t>(size_cpp, number);
}

kth_binary_mut_t kth_core_binary_construct_from_size_blocks(kth_size_t size, uint8_t const* blocks, kth_size_t n) {
    KTH_PRECONDITION(blocks != nullptr || n == 0);
    auto const size_cpp = kth::sz(size);
    auto const blocks_cpp = kth::byte_span(blocks, kth::sz(n));
    return kth::leak<cpp_t>(size_cpp, blocks_cpp);
}

kth_error_code_t kth_core_binary_parse_from(char const* bit_string, KTH_OUT_OWNED kth_binary_mut_t* out) {
    KTH_PRECONDITION(bit_string != nullptr);
    KTH_PRECONDITION(out != nullptr);
    KTH_PRECONDITION(*out == nullptr);
    auto const bit_string_cpp = std::string_view(bit_string);
    auto result = cpp_t::parse_from(bit_string_cpp);
    if ( ! result) return kth::to_c_err(result.error());
    *out = kth::leak(std::move(*result));
    return kth_ec_success;
}


// Destructor

void kth_core_binary_destruct(kth_binary_mut_t self) {
    kth::del<cpp_t>(self);
}


// Copy

kth_binary_mut_t kth_core_binary_copy(kth_binary_const_t self) {
    KTH_PRECONDITION(self != nullptr);
    return kth::clone<cpp_t>(self);
}


// Equality

kth_bool_t kth_core_binary_equals(kth_binary_const_t self, kth_binary_const_t other) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(other != nullptr);
    return kth::eq<cpp_t>(self, other);
}

kth_bool_t kth_core_binary_not_equal(kth_binary_const_t self, kth_binary_const_t other) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(other != nullptr);
    return kth::ne<cpp_t>(self, other);
}


// Ordering

kth_bool_t kth_core_binary_less(kth_binary_const_t self, kth_binary_const_t x) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(x != nullptr);
    return kth::lt<cpp_t>(self, x);
}

kth_bool_t kth_core_binary_greater(kth_binary_const_t self, kth_binary_const_t x) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(x != nullptr);
    return kth::gt<cpp_t>(self, x);
}

kth_bool_t kth_core_binary_less_or_equal(kth_binary_const_t self, kth_binary_const_t x) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(x != nullptr);
    return kth::le<cpp_t>(self, x);
}

kth_bool_t kth_core_binary_greater_or_equal(kth_binary_const_t self, kth_binary_const_t x) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(x != nullptr);
    return kth::ge<cpp_t>(self, x);
}


// Getters

uint8_t* kth_core_binary_blocks(kth_binary_const_t self, kth_size_t* out_size) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(out_size != nullptr);
    auto const& data = kth::cpp_ref<cpp_t>(self).blocks();
    return kth::create_c_array(data, *out_size);
}

char* kth_core_binary_to_string(kth_binary_const_t self) {
    KTH_PRECONDITION(self != nullptr);
    auto const s = kth::cpp_ref<cpp_t>(self).to_string();
    return kth::create_c_str(s);
}

kth_size_t kth_core_binary_size(kth_binary_const_t self) {
    KTH_PRECONDITION(self != nullptr);
    return kth::cpp_ref<cpp_t>(self).size();
}


// Predicates

kth_bool_t kth_core_binary_is_prefix_of_span(kth_binary_const_t self, uint8_t const* field, kth_size_t n) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(field != nullptr || n == 0);
    auto const field_cpp = kth::byte_span(field, kth::sz(n));
    return kth::bool_to_int(kth::cpp_ref<cpp_t>(self).is_prefix_of(field_cpp));
}

kth_bool_t kth_core_binary_is_prefix_of_uint32(kth_binary_const_t self, uint32_t field) {
    KTH_PRECONDITION(self != nullptr);
    return kth::bool_to_int(kth::cpp_ref<cpp_t>(self).is_prefix_of(field));
}

kth_bool_t kth_core_binary_is_prefix_of_binary(kth_binary_const_t self, kth_binary_const_t field) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(field != nullptr);
    auto const& field_cpp = kth::cpp_ref<cpp_t>(field);
    return kth::bool_to_int(kth::cpp_ref<cpp_t>(self).is_prefix_of(field_cpp));
}


// Operations

void kth_core_binary_resize(kth_binary_mut_t self, kth_size_t size) {
    KTH_PRECONDITION(self != nullptr);
    auto const size_cpp = kth::sz(size);
    kth::cpp_ref<cpp_t>(self).resize(size_cpp);
}

kth_bool_t kth_core_binary_at(kth_binary_const_t self, kth_size_t index) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(index < kth::cpp_ref<cpp_t>(self).size());
    auto const index_cpp = kth::sz(index);
    return kth::bool_to_int(kth::cpp_ref<cpp_t>(self).operator[](index_cpp));
}

void kth_core_binary_append(kth_binary_mut_t self, kth_binary_const_t post) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(post != nullptr);
    auto const& post_cpp = kth::cpp_ref<cpp_t>(post);
    kth::cpp_ref<cpp_t>(self).append(post_cpp);
}

void kth_core_binary_prepend(kth_binary_mut_t self, kth_binary_const_t prior) {
    KTH_PRECONDITION(self != nullptr);
    KTH_PRECONDITION(prior != nullptr);
    auto const& prior_cpp = kth::cpp_ref<cpp_t>(prior);
    kth::cpp_ref<cpp_t>(self).prepend(prior_cpp);
}

void kth_core_binary_shift_left(kth_binary_mut_t self, kth_size_t distance) {
    KTH_PRECONDITION(self != nullptr);
    auto const distance_cpp = kth::sz(distance);
    kth::cpp_ref<cpp_t>(self).shift_left(distance_cpp);
}

void kth_core_binary_shift_right(kth_binary_mut_t self, kth_size_t distance) {
    KTH_PRECONDITION(self != nullptr);
    auto const distance_cpp = kth::sz(distance);
    kth::cpp_ref<cpp_t>(self).shift_right(distance_cpp);
}

kth_binary_mut_t kth_core_binary_substring(kth_binary_const_t self, kth_size_t start, kth_size_t length) {
    KTH_PRECONDITION(self != nullptr);
    auto const start_cpp = kth::sz(start);
    auto const length_cpp = kth::sz(length);
    return kth::leak(kth::cpp_ref<cpp_t>(self).substring(start_cpp, length_cpp));
}


// Static utilities

kth_size_t kth_core_binary_blocks_size(kth_size_t bit_size) {
    auto const bit_size_cpp = kth::sz(bit_size);
    return cpp_t::blocks_size(bit_size_cpp);
}

} // extern "C"
