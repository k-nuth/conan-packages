# Copyright (c) 2016-present Knuth Project developers.
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

cmake_minimum_required(VERSION 3.21)

project(c-api VERSION 0 LANGUAGES CXX C)

set_property(GLOBAL PROPERTY USE_FOLDERS ON)

set(CMAKE_C_STANDARD 23)
set(CMAKE_C_STANDARD_REQUIRED ON)

set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

option(ENABLE_SHARED "" ON)
option(ENABLE_SHARED_CAPI "" ON)
option(ENABLE_POSITION_INDEPENDENT_CODE "Enable POSITION_INDEPENDENT_CODE property" ON)
option(WITH_CONSOLE "Compile console application." ON)
option(WITH_CONSOLE_CAPI "Compile console application." ON)
option(DB_READONLY_MODE "Readonly DB mode enabled." OFF)
option(KTH_CAPI_EXCEPTION_BARRIERS "Enable exception barriers in generated status-returning C-API wrappers." OFF)

option(GLOBAL_BUILD "" ON)

if (DB_READONLY_MODE)
  message(STATUS "Knuth: Readonly DB mode enabled")
  add_definitions(-DKTH_DB_READONLY)
endif()

if (ENABLE_SHARED_CAPI)
  set(ENABLE_SHARED ON)
endif()

set(MARCH_ID "" CACHE STRING "Specify the Microarchitecture ID (x86_64|...).")
message( STATUS "Knuth: Compiling for Microarchitecture ID ${MARCH_ID}")
add_definitions(-DKTH_MARCH_ID=${MARCH_ID})

message( STATUS "Knuth: CONAN_CXX_FLAGS ${CONAN_CXX_FLAGS}")
message( STATUS "Knuth: CONAN_C_FLAGS ${CONAN_C_FLAGS}")

set(CURRENCY "BCH" CACHE STRING "Specify the Cryptocurrency (BCH|BTC|LTC).")

if (${CURRENCY} STREQUAL "BCH")
  add_definitions(-DKTH_CURRENCY_BCH)
elseif (${CURRENCY} STREQUAL "BTC")
  add_definitions(-DKTH_CURRENCY_BTC)
elseif (${CURRENCY} STREQUAL "LTC")
  add_definitions(-DKTH_CURRENCY_LTC)
else()
  message(FATAL_ERROR "Invalid Cryptocurrency: ${CURRENCY}")
endif()

message(STATUS "Knuth: Cryptocurrency: ${CURRENCY}")

# --------------------------------------------------------------------------------
# `KTH_CAPI_BUILD_TIMESTAMP` gets baked into every C-API translation
# unit as a `-D` flag. Because the value is the UTC epoch at configure
# time, every fresh configure changes the flag and therefore
# invalidates the ccache entry for every c-api `.o` — a ~20-point
# hit-rate drop was traced to this in the Code Coverage workflow.
#
# Gated on `KTH_EMBED_BUILD_TIMESTAMP` (OFF by default) so the
# timestamp is stable at 0 for CI / developer builds and only the
# release pipeline opts in. Release builds pass
# `-DKTH_EMBED_BUILD_TIMESTAMP=ON` to restore the per-release stamp
# in published binaries.
option(KTH_EMBED_BUILD_TIMESTAMP
    "Embed the UTC configure-time epoch into the C-API binary. \
Turn ON for release builds; leave OFF for CI / dev to keep ccache \
hits stable." OFF)
if (KTH_EMBED_BUILD_TIMESTAMP)
    string(TIMESTAMP KTH_CAPI_BUILD_TIMESTAMP "%s" UTC)
else()
    set(KTH_CAPI_BUILD_TIMESTAMP "0")
endif()
message(STATUS "Knuth: KTH_CAPI_BUILD_TIMESTAMP: ${KTH_CAPI_BUILD_TIMESTAMP}")
add_definitions(-DKTH_CAPI_BUILD_TIMESTAMP=${KTH_CAPI_BUILD_TIMESTAMP})
# --------------------------------------------------------------------------------
# TODO: do something different, because the project is usually built in
# a Conan environment, where the git hash is not available.
# find_package(Git QUIET)
# if (GIT_FOUND)
#     execute_process(
#             COMMAND ${GIT_EXECUTABLE} rev-parse HEAD
#             WORKING_DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
#             OUTPUT_VARIABLE PROJECT_VERSION_BUILD
#             OUTPUT_STRIP_TRAILING_WHITESPACE
#     )
#     if (PROJECT_VERSION_BUILD)
#         set(PROJECT_VERSION_BUILD "${PROJECT_VERSION_BUILD}")
#         message(STATUS "Knuth: KTH_CAPI_BUILD_GIT_HASH: ${PROJECT_VERSION_BUILD}")
#         add_definitions(-DKTH_CAPI_BUILD_GIT_HASH=\"${PROJECT_VERSION_BUILD}\")
#     else()
#         message(STATUS "Knuth: KTH_CAPI_BUILD_GIT_HASH: not found")
#     endif()
# else()
#     message(STATUS "Knuth: KTH_CAPI_BUILD_GIT_HASH: not found")
#     # set(PROJECT_VERSION_BUILD "")
# endif()
# --------------------------------------------------------------------------------



if (NOT GLOBAL_BUILD)
  find_package(node REQUIRED)
  # if (CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  #   find_package(domain REQUIRED)
  # else()
  #   find_package(node REQUIRED)
  # endif()
endif()


include(CheckCXXCompilerFlag)
set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} ${CMAKE_CURRENT_SOURCE_DIR}/ci_utils/cmake)
include(KnuthTools)

if (NOT MSVC)
  _add_c_compile_flag(-Wall _has_all_warning_flag)
else()
  _add_c_compile_flag(-W4 _has_all_warning_flag)
  add_definitions(-D_SCL_SECURE_NO_WARNINGS)
  add_definitions(-D_CRT_SECURE_NO_WARNINGS)
endif()

if (NOT MSVC)
  _add_c_compile_flag(-Wextra _has_extra_warning_flag)
endif()

_add_c_compile_flag(-Wpedantic _has_pedantic_warning_flag)
if (_has_pedantic_warning_flag)
  _add_c_compile_flag(-pedantic _has_pedantic_flag)
endif()

if(CMAKE_SYSTEM_NAME STREQUAL "Emscripten" AND NOT KTH_BROWSER_NODE)
    message(STATUS "Knuth: OS is Emscripten")
    message(STATUS "Knuth: CMAKE_CXX_FLAGS ${CMAKE_CXX_FLAGS}")
    # set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -matomics -mbulk-memory")
    # _add_cxx_compile_flag(-matomics _has_matomics_flag)
    # _add_cxx_compile_flag(-mbulk-memory _has_mbulk_memory_flag)


    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -matomics" )
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -mbulk-memory" )
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -matomics" )
    set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -mbulk-memory" )
    # set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -matomics" )
    # set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -mbulk-memory" )
    # set(CMAKE_STATIC_LINKER_FLAGS "${CMAKE_STATIC_LINKER_FLAGS} -matomics" )
    # set(CMAKE_STATIC_LINKER_FLAGS "${CMAKE_STATIC_LINKER_FLAGS} -mbulk-memory" )

    message(STATUS "Knuth: CMAKE_CXX_FLAGS ${CMAKE_CXX_FLAGS}")
endif()


_add_cxx_compile_flag(-Wno-missing-braces _has_no_missing_braces_warning_flag)
_add_cxx_compile_flag(-Wno-mismatched-tags _has_no_mismatched_tags_warning_flag)
_add_c_compile_flag(-Wno-deprecated-declarations _has_no_deprecated_declarations_warning_flag)
_add_link_flag(-fstack-protector _has_stack_protector_flag)
_add_link_flag(-fstack-protector-all _has_stack_protector_all_flag)
_add_cxx_compile_flag(-fvisibility-hidden _has_visibility_hidden_flag)
_add_cxx_compile_flag(-fvisibility-inlines-hidden _has_visibility_inlines_hidden_flag)

if (MSVC)
  add_definitions(-D_WIN32_WINNT=0x0600)
endif()

if (ENABLE_SHARED)
    set(MODE SHARED)
else()
    set(MODE STATIC)
endif()

set(kth_sources

  src/node_info.cpp
  src/secure_memory.cpp
  src/string_list.cpp
  src/double_list.cpp
  src/u32_list.cpp
  src/u64_list.cpp
  src/bool_list.cpp


  src/chain/opcode.cpp
  src/domain/machine/operation.cpp
  src/domain/machine/operation_list.cpp
  src/domain/chain/script.cpp
  src/domain/chain/transaction.cpp
  src/domain/chain/transaction_list.cpp
  src/domain/chain/utxo.cpp
  src/domain/chain/utxo_list.cpp
  src/domain/chain/abla.cpp
  src/domain/chain/abla_config.cpp
  src/domain/chain/abla_state.cpp


  src/wallet/ec_private.cpp
  src/wallet/ec_public.cpp
  src/wallet/elliptic_curve.cpp
  src/wallet/hd_public.cpp
  src/wallet/hd_private.cpp

  src/wallet/bitcoin_uri.cpp
  src/wallet/cashaddr.cpp
  src/wallet/cashtoken_minting.cpp
  src/wallet/cashtoken_minting_generated.cpp
  src/wallet/coin_selection.cpp
  src/wallet/coin_selection_result.cpp
  src/wallet/encrypted_keys.cpp
  src/wallet/ek_private.cpp
  src/wallet/ek_public.cpp
  src/wallet/ek_token.cpp
  src/wallet/language.cpp
  src/wallet/message.cpp
  src/wallet/mnemonic.cpp
  src/wallet/payment_address.cpp
  src/wallet/payment_address_list.cpp
  src/wallet/stealth_address.cpp
  src/wallet/stealth_receiver.cpp
  src/wallet/stealth_sender.cpp
  src/wallet/wallet.cpp
  src/wallet/ec_compressed_list.cpp
  src/wallet/wallet_data.cpp
  src/wallet/wallet_manager_generated.cpp

  src/libconfig/libconfig.cpp

  src/node/settings.cpp

  src/vm/big_number.cpp
  src/vm/debug_snapshot.cpp
  src/vm/debug_snapshot_list.cpp
  src/vm/function_table.cpp
  src/vm/interpreter.cpp
  src/vm/metrics.cpp
  src/vm/number.cpp
  src/vm/program.cpp
  src/vm/script_execution_context.cpp

  src/data_stack.cpp


)

# if(NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  set(kth_sources
    ${kth_sources}
        src/primitives.cpp
        src/hash.cpp
        src/hash_list.cpp
        src/binary.cpp
        src/node.cpp
        src/node_generated.cpp
        src/platform.cpp

        src/domain/chain/block.cpp
        src/domain/chain/block_ticks.cpp
        src/domain/chain/block_list.cpp

        src/chain/chain_async.cpp
        src/chain/chain_other.cpp
        src/chain/chain_sync.cpp
        src/chain/chain_sync_generated.cpp
        src/chain/chain_submission.cpp
        src/chain/chain_mempool.cpp
        src/chain/chain_mining.cpp
        src/chain/chain_query.cpp

        src/domain/message/compact_block.cpp
        src/domain/message/double_spend_proof.cpp
        src/domain/message/double_spend_proof_spender.cpp
        src/domain/message/get_blocks.cpp
        src/domain/message/get_headers.cpp
        src/domain/chain/header.cpp
        src/domain/chain/history_compact.cpp
        src/domain/chain/history_compact_list.cpp
        src/domain/chain/stealth_compact.cpp
        src/domain/chain/stealth_compact_list.cpp
        src/domain/chain/input.cpp
        src/domain/chain/input_list.cpp
        src/domain/chain/input_point.cpp
        src/chain/mempool_transaction_list.cpp
        src/domain/message/merkle_block.cpp
        src/domain/chain/output.cpp
        src/domain/chain/output_list.cpp
        src/domain/chain/output_point.cpp
        src/domain/chain/point.cpp
        src/domain/chain/point_list.cpp
        src/domain/chain/output_point_list.cpp
        src/chain/mempool_transaction.cpp
        src/domain/message/prefilled_transaction.cpp
        src/domain/message/prefilled_transaction_list.cpp

        src/domain/chain/token_data.cpp

        src/config/authority.cpp
        src/config/blockchain_settings.cpp
        src/config/checkpoint.cpp
        src/config/database_settings.cpp
        src/config/endpoint.cpp

        src/config/node_settings.cpp
        src/config/settings.cpp

        src/node/settings.cpp

        src/vm/program.cpp

        src/wallet/ec_private.cpp
        src/wallet/ec_public.cpp
        src/wallet/elliptic_curve.cpp
        src/wallet/hd_public.cpp
        src/wallet/hd_private.cpp

        src/wallet/cashtoken_minting.cpp
        src/wallet/cashtoken_minting_generated.cpp
        src/wallet/payment_address.cpp
        src/wallet/payment_address_list.cpp
        src/wallet/wallet.cpp
        src/wallet/ec_compressed_list.cpp
        # src/config/network_settings.cpp
        # src/p2p/p2p.cpp
  )
# endif()

if(NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  set(kth_sources
    ${kth_sources}
    src/config/network_settings.cpp
    src/p2p/p2p.cpp
  )
endif()

set(kth_headers

  include/kth/capi/node_info.h
  include/kth/capi/string_list.h
  include/kth/capi/double_list.h
  include/kth/capi/u32_list.h
  include/kth/capi/u64_list.h

  include/kth/capi/chain/opcode.h
  include/kth/capi/domain/machine/operation_list.h
  include/kth/capi/domain/machine/operation.h
  include/kth/capi/domain/chain/script.h
  include/kth/capi/chain/script_version.h
  include/kth/capi/domain/message/get_headers.h
  include/kth/capi/domain/message/double_spend_proof.h
  include/kth/capi/domain/chain/transaction.h
  include/kth/capi/domain/chain/transaction_list.h

  include/kth/capi/vm/program.h

  include/kth/capi/vm/program.h

  include/kth/capi/wallet/bitcoin_uri.h
  include/kth/capi/wallet/cashaddr.h
  include/kth/capi/wallet/cashtoken_minting.h
  include/kth/capi/wallet/coin_selection.h
  include/kth/capi/wallet/coin_selection_algorithm.h
  include/kth/capi/wallet/coin_selection_result.h
  include/kth/capi/wallet/coin_selection_strategy.h
  include/kth/capi/wallet/ec_public.h
  include/kth/capi/wallet/encrypted_keys.h
  include/kth/capi/wallet/ek_private.h
  include/kth/capi/wallet/ek_public.h
  include/kth/capi/wallet/ek_token.h
  include/kth/capi/wallet/language.h
  include/kth/capi/wallet/message.h
  include/kth/capi/wallet/mnemonic.h
  include/kth/capi/wallet/payment_address.h
  include/kth/capi/wallet/payment_address_list.h
  include/kth/capi/wallet/stealth_address.h
  include/kth/capi/wallet/stealth_receiver.h
  include/kth/capi/wallet/stealth_sender.h
  include/kth/capi/wallet/wallet.h
  include/kth/capi/wallet/ec_compressed_list.h
  include/kth/capi/wallet/wallet_data.h
  include/kth/capi/wallet/wallet_manager.h

  include/kth/capi/primitives.h
  include/kth/capi/handles.h
  include/kth/capi/callbacks.h
  include/kth/capi/data_stack.h
  include/kth/capi/hash_list.h
  include/kth/capi/error.h
  include/kth/capi/hash.h
  include/kth/capi/version.h
  include/kth/capi/visibility.h
  include/kth/capi/binary.h
  include/kth/capi/capi.h
  include/kth/capi/conversions.hpp
  include/kth/capi/config/blockchain_settings.h
  include/kth/capi/config/endpoint.h
  include/kth/capi/config/database_helpers.hpp

  include/kth/capi/config/authority_helpers.hpp
  include/kth/capi/config/settings.h
  include/kth/capi/config/authority.h
  include/kth/capi/config/checkpoint.h
  include/kth/capi/config/helpers.hpp
  include/kth/capi/config/settings_helper.hpp
  include/kth/capi/config/endpoint_helpers.hpp
  include/kth/capi/config/checkpoint_helpers.hpp
  include/kth/capi/config/database_settings.h
  include/kth/capi/config/blockchain_helpers.hpp
  include/kth/capi/config/node_settings.h
  include/kth/capi/config/node_helpers.hpp

  include/kth/capi/node/settings.h

  include/kth/capi/libconfig/libconfig.h

  include/kth/capi/vm/big_number.h
  include/kth/capi/vm/interpreter.h
  include/kth/capi/vm/metrics.h
  include/kth/capi/vm/number.h
  include/kth/capi/vm/program.h
  include/kth/capi/vm/script_execution_context.h

  include/kth/capi.h

)

# if(NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  set(kth_headers
    ${kth_headers}

    include/kth/capi/domain/chain/block_list.h
    include/kth/capi/chain/mempool_transaction_list.h
    include/kth/capi/domain/message/compact_block.h
    include/kth/capi/chain/token_capability.h
    include/kth/capi/chain/token_kind.h
    include/kth/capi/domain/chain/token_data.h
    include/kth/capi/domain/chain/input.h
    include/kth/capi/domain/chain/input_point.h
    include/kth/capi/chain/chain.h
    include/kth/capi/chain/chain_sync.h
    include/kth/capi/chain/chain_other.h
    include/kth/capi/chain/chain_mempool.h
    include/kth/capi/chain/mempool_totals.h
    include/kth/capi/chain/mempool_entry_info.h
    include/kth/capi/domain/chain/stealth_compact.h
    include/kth/capi/domain/chain/history_compact_list.h
    include/kth/capi/domain/chain/stealth_compact_list.h
    include/kth/capi/domain/chain/output_point.h
    include/kth/capi/domain/chain/point_list.h
    include/kth/capi/domain/chain/header.h
    include/kth/capi/chain/chain_async.h
    include/kth/capi/domain/chain/history_compact.h
    include/kth/capi/domain/chain/output.h
    include/kth/capi/domain/chain/output_list.h
    include/kth/capi/domain/chain/output_point_list.h
    include/kth/capi/domain/message/get_blocks.h
    include/kth/capi/domain/message/double_spend_proof_spender.h
    include/kth/capi/domain/chain/point.h
    include/kth/capi/domain/message/merkle_block.h
    include/kth/capi/domain/chain/block.h
    include/kth/capi/domain/chain/block_ticks.h
    include/kth/capi/chain/block_progress.h
    include/kth/capi/chain/mempool_transaction.h
    include/kth/capi/domain/message/prefilled_transaction.h
    include/kth/capi/domain/message/prefilled_transaction_list.h
    include/kth/capi/chain/script_flags.h
    include/kth/capi/chain/script_version.h
    include/kth/capi/chain/script_pattern.h
    include/kth/capi/domain/message/get_headers.h
    include/kth/capi/domain/message/double_spend_proof.h
    include/kth/capi/domain/chain/input_list.h
    include/kth/capi/domain/chain/utxo.h
    include/kth/capi/domain/chain/utxo_list.h
    include/kth/capi/domain/chain/abla.h
    include/kth/capi/domain/chain/abla_config.h
    include/kth/capi/domain/chain/abla_state.h
    include/kth/capi/chain/abla_config_validity.h
    include/kth/capi/chain/abla_state_validity.h
    include/kth/capi/platform.h
    include/kth/capi/p2p/p2p.h
    include/kth/capi/node.h
    include/kth/capi/helpers.hpp
    include/kth/capi/detail/buffers.hpp
    include/kth/capi/detail/enum_cast.hpp
    include/kth/capi/detail/errors.hpp
    include/kth/capi/detail/async_exception.hpp
    include/kth/capi/detail/exception_barrier.hpp
    include/kth/capi/detail/handle_access.hpp
    include/kth/capi/detail/ownership.hpp
    include/kth/capi/detail/secure_scrub.hpp
    include/kth/capi/detail/value_conversions.hpp
    include/kth/capi/conversions/chain.hpp
    include/kth/capi/conversions/config.hpp
    include/kth/capi/conversions/infrastructure.hpp
    include/kth/capi/conversions/machine.hpp
    include/kth/capi/conversions/node.hpp
    include/kth/capi/conversions/wallet.hpp

    # include/kth/capi/config/network_settings.h
    # include/kth/capi/config/network_helpers.hpp

  )
# endif()


if(NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  set(kth_headers
    ${kth_headers}
    include/kth/capi/config/network_settings.h
    include/kth/capi/config/network_helpers.hpp

  )
endif()


if(KTH_BROWSER_NODE)
  list(APPEND kth_sources src/node/header_sync.cpp)
  list(APPEND kth_headers include/kth/capi/node/header_sync.h)
endif()

add_library(${PROJECT_NAME} ${MODE} ${kth_sources} ${kth_headers})
add_library(${PROJECT_NAME}::${PROJECT_NAME} ALIAS ${PROJECT_NAME})
set_target_properties(${PROJECT_NAME} PROPERTIES LINKER_LANGUAGE CXX CXX_STANDARD 23 CXX_STANDARD_REQUIRED TRUE)
# Export the C language requirement to CMake consumers of the C API.
target_compile_features(${PROJECT_NAME} PUBLIC c_std_23)


if (ENABLE_POSITION_INDEPENDENT_CODE)
  set_property(TARGET ${PROJECT_NAME} PROPERTY POSITION_INDEPENDENT_CODE ON)
endif(ENABLE_POSITION_INDEPENDENT_CODE)

target_compile_definitions(${PROJECT_NAME} PUBLIC -DKTH_EXPORTS)

if (KTH_CAPI_EXCEPTION_BARRIERS)
  target_compile_definitions(${PROJECT_NAME} PUBLIC -DKTH_CAPI_EXCEPTION_BARRIERS)
endif()

target_include_directories(${PROJECT_NAME} PUBLIC
        $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
        $<INSTALL_INTERFACE:include>)

if (NOT ENABLE_SHARED)
  target_compile_definitions(${PROJECT_NAME} PUBLIC -DKTH_LIB_STATIC)
endif()

#Note: Knuth modules are Static, C-API Shared
# Note: These should be inherited from node::node target via Conan
# target_compile_definitions(${PROJECT_NAME} PUBLIC -DKND_STATIC -DKB_STATIC -DKN_STATIC)

if (NOT MSVC)
  target_compile_definitions(${PROJECT_NAME} PUBLIC -DSYSCONFDIR=\"${SYSCONFDIR}\")
endif()

target_link_libraries(${PROJECT_NAME} PUBLIC node::node)
# if(CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
#   target_link_libraries(${PROJECT_NAME} PUBLIC domain::domain)
# else()
#   target_link_libraries(${PROJECT_NAME} PUBLIC node::node)
# endif()

if (MINGW)
  target_link_libraries(${PROJECT_NAME} PUBLIC ws2_32 wsock32)
endif()

_group_sources(${PROJECT_NAME} "${CMAKE_CURRENT_LIST_DIR}")


if (WITH_CONSOLE_CAPI)
    set(_test_console_sources
      # console/test_wallet.cpp
      # console/test_wallet.c
      # console/test_wallet2.c
      # console/test_wallet_manager.c
      console/test_2025_issue.cpp

      # console/test_header_hash.cpp
      # console/main.cpp
      # console/main.c
      # console/print_headers.cpp
      # console/error_test.cpp
      # console/test_deadlock.cpp
      # console/config_test.cpp
      # console/platform_test.cpp
      # console/test_libconfig.cpp
      # console/main_744727.cpp
      # console/main_payment_addr_cash_aware.cpp
      # console/node_info.c
      # console/get_block.c
    )

  add_executable(test_console ${_test_console_sources})

  target_link_libraries(test_console ${PROJECT_NAME})

  set_target_properties(
          test_console PROPERTIES
          FOLDER "node"
          OUTPUT_NAME test_console)
endif()

# Skip tests for WebAssembly (Catch2 incompatible with shared-memory/threads)
if (ENABLE_TEST AND NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
    enable_testing()
    find_package(Catch2 3 REQUIRED)

    # Compile as C (not C++) and verify the selected language standard.
    add_library(kth_capi_c23_compile_check OBJECT test/c23_compile_check.c)
    target_include_directories(kth_capi_c23_compile_check PRIVATE include)


    add_executable(kth_capi_test
        test/helpers.cpp
        test/noexcept_contracts.cpp
        test/domain_api_180.cpp
        test/conversions.cpp
        test/network_context.cpp
        test/binary.cpp
        test/chain/header.cpp
        test/chain/point.cpp
        test/chain/input_point.cpp
        test/chain/output_point.cpp
        test/chain/script.cpp
        test/chain/output.cpp
        test/chain/input.cpp
        test/chain/transaction.cpp
        test/chain/transaction_closure.cpp
        test/chain/block.cpp
        test/chain/compact_block.cpp
        test/chain/get_blocks.cpp
        test/chain/get_headers.cpp
        test/chain/merkle_block.cpp
        test/chain/prefilled_transaction.cpp
        test/chain/block_list.cpp
        test/chain/input_list.cpp
        test/chain/output_list.cpp
        test/chain/transaction_list.cpp
        test/chain/point_list.cpp
        test/chain/output_point_list.cpp
        test/chain/stealth_compact.cpp
        test/chain/history_compact.cpp
        test/chain/double_spend_proof.cpp
        test/chain/token_data.cpp
        test/chain/utxo.cpp
        test/chain/abla.cpp
        test/chain/progress.cpp
        test/wallet/bitcoin_uri.cpp
        test/wallet/cashaddr.cpp
        test/wallet/cashtoken_minting.cpp
        test/wallet/coin_selection.cpp
        test/wallet/encrypted_keys.cpp
        test/wallet/ek_private.cpp
        test/wallet/ek_public.cpp
        test/wallet/ek_token.cpp
        test/wallet/hd_public.cpp
        test/wallet/hd_private.cpp
        test/wallet/wasm_surface.cpp
        test/wallet/message.cpp
        test/wallet/mnemonic.cpp
        test/wallet/stealth_address.cpp
        test/wallet/stealth_receiver.cpp
        test/wallet/stealth_sender.cpp
        test/wallet/wallet_data.cpp
        test/vm/big_number.cpp
        test/vm/program.cpp
        test/vm/interpreter.cpp
        test/vm/debug_snapshot.cpp
        test/vm/function_table.cpp
        test/vm/metrics.cpp
        test/vm/number.cpp
        test/vm/script_execution_context.cpp
        test/data_stack.cpp
    )

    # Baseline comparison builds skip the consuming Transaction constructor,
    # which is available only in the regenerated C-API.
    option(KTH_CAPI_TEST_NO_CONSTRUCT_MOVE "Skip tests of C-API functions added by regeneration." OFF)
    if (KTH_CAPI_TEST_NO_CONSTRUCT_MOVE)
        set_source_files_properties(test/chain/transaction_closure.cpp
            PROPERTIES COMPILE_DEFINITIONS KTH_CAPI_TEST_NO_CONSTRUCT_MOVE)
    endif()

    set_source_files_properties(test/chain/progress.cpp PROPERTIES
        INCLUDE_DIRECTORIES "${CMAKE_CURRENT_SOURCE_DIR}/../node/test")

    target_link_libraries(kth_capi_test PUBLIC ${PROJECT_NAME})
    target_link_libraries(kth_capi_test PRIVATE Catch2::Catch2WithMain)

    include(CTest)
    include(Catch)
    kth_register_tests(kth_capi_test)

    # This test resolves its own Asio dependency, independently of the node's
    # transport selection and targets imported in sibling directories.
    add_subdirectory("${CMAKE_CURRENT_SOURCE_DIR}/../../test/c-api-mining-info"
                     "${CMAKE_CURRENT_BINARY_DIR}/mining-info-callback")
    add_subdirectory("${CMAKE_CURRENT_SOURCE_DIR}/../../test/c-api-async"
                     "${CMAKE_CURRENT_BINARY_DIR}/async-callbacks")

    if(CURRENCY STREQUAL "BCH")
        add_executable(kth_payment_address_errors_test test/wallet/payment_address_errors.c)
        set_target_properties(kth_payment_address_errors_test PROPERTIES LINKER_LANGUAGE CXX)
        target_link_libraries(kth_payment_address_errors_test PRIVATE ${PROJECT_NAME})
        add_test(NAME capi_payment_address_errors COMMAND kth_payment_address_errors_test)
    endif()


    # Real C++ exceptions through the generated wrappers. The executable
    # replaces the global allocation functions to inject failures, so it is
    # kept apart from kth_capi_test and built only with the barriers on.
    if (KTH_CAPI_EXCEPTION_BARRIERS)
        add_executable(kth_capi_exception_test test/exception_barriers.cpp)
        target_link_libraries(kth_capi_exception_test PUBLIC ${PROJECT_NAME})
        target_link_libraries(kth_capi_exception_test PRIVATE Catch2::Catch2WithMain)
        # Real malloc exhaustion needs link-time interposition (GNU ld / lld),
        # which only reaches the malloc calls linked into the executable. A
        # shared C-API keeps its own malloc references, so the malloc-fault
        # tests are enabled only when the C-API target is a static library.
        get_target_property(_kth_capi_type ${PROJECT_NAME} TYPE)
        if (CMAKE_SYSTEM_NAME STREQUAL "Linux" AND _kth_capi_type STREQUAL "STATIC_LIBRARY")
            target_compile_definitions(kth_capi_exception_test PRIVATE KTH_CAPI_TEST_MALLOC_WRAP)
            target_link_options(kth_capi_exception_test PRIVATE -Wl,--wrap=malloc)
        endif()
        kth_register_tests(kth_capi_exception_test)
    endif()

    # README C snippet — compile-only check. Verbatim copy of the
    # README's "Using the C API" snippet. Builds, but is not
    # registered as a runtime test: the snippet ends in
    # `kth_node_init_run_and_wait_for_signal`, which blocks until
    # SIGINT/SIGTERM. The compile is enough to fail the build if any
    # public symbol the snippet references drifts.
    add_executable(kth_readme_c_compile_check test/readme_c_compile_check.c)
    target_link_libraries(kth_readme_c_compile_check PRIVATE ${PROJECT_NAME})

    # Compile and link the component README itself, rather than a separate copy.
    set_property(DIRECTORY APPEND PROPERTY CMAKE_CONFIGURE_DEPENDS
        "${CMAKE_CURRENT_SOURCE_DIR}/README.md")
    file(READ "${CMAKE_CURRENT_SOURCE_DIR}/README.md" kth_capi_readme)
    string(REGEX MATCH "```c\n([^`]*)```" kth_capi_example "${kth_capi_readme}")
    if(NOT kth_capi_example)
        message(FATAL_ERROR "C API README has no C example")
    endif()
    file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/component_readme.c" "${CMAKE_MATCH_1}")
    add_executable(kth_component_readme_compile_check
        "${CMAKE_CURRENT_BINARY_DIR}/component_readme.c")
    set_target_properties(kth_component_readme_compile_check PROPERTIES
        C_STANDARD 23 C_STANDARD_REQUIRED YES)
    target_link_libraries(kth_component_readme_compile_check PRIVATE ${PROJECT_NAME})

    # Chain-interface mempool readers — compile + link signature check.
    add_executable(kth_chain_mempool_compile_check test/chain/chain_mempool_compile_check.c)
    target_link_libraries(kth_chain_mempool_compile_check PRIVATE ${PROJECT_NAME})

    add_executable(kth_chain_mining_compile_check test/chain/chain_mining_compile_check.c)
    target_link_libraries(kth_chain_mining_compile_check PRIVATE ${PROJECT_NAME})

    add_executable(kth_chain_query_compile_check test/chain/chain_query_compile_check.c)
    target_link_libraries(kth_chain_query_compile_check PRIVATE ${PROJECT_NAME})

    # README C snippet — runtime smoke. Same flow as the README but
    # adapted for CI: regtest network, fresh temp data dir, 16 MiB DB
    # cap, no network threads. A pthread issues the async height query
    # once the chain's dispatcher is up, and the result handler calls
    # `kth_node_signal_stop`, which unblocks
    # `kth_node_init_run_and_wait_for_signal` so the test can exit
    # without an external SIGINT. Asserts the freshly initialised
    # regtest reports height 0.
    find_package(Threads REQUIRED)
    add_executable(kth_readme_c_runtime test/readme_c_runtime.c)
    target_link_libraries(kth_readme_c_runtime PRIVATE ${PROJECT_NAME})
    target_link_libraries(kth_readme_c_runtime PRIVATE Threads::Threads)
    # Temporarily disabled — see issue #342. After `100% tests passed`
    # the docker exec the runner uses disappears ~19 min later and the
    # step ends with `Process completed with exit code 1`. The executable
    # still builds so any drift in public symbols still fails the build.
    # Re-enable once #342 isolates the root cause. Original rationale for
    # the test-properties below is preserved for when it goes back on:
    #
    # add_test(NAME kth_readme_c_runtime COMMAND kth_readme_c_runtime)
    # # Spins up a full `kth_node_*` instance with an LMDB chain database
    # # and a network thread pool — peak memory is large enough that
    # # ctest scheduling it concurrently with other tests on the GHA
    # # hosted runner (7 GB ceiling) tipped the post-merge master CI
    # # into runner-OOM kills since 2026-05-03. PROCESSORS 4 reserves
    # # the full CPU slot count, so ctest serialises this against every
    # # other test on a 4-core runner without forcing the rest of the
    # # suite to run serially.
    # set_tests_properties(kth_readme_c_runtime PROPERTIES
    #     TIMEOUT 60
    #     PROCESSORS 4
    #     RUN_SERIAL TRUE)
endif()




# Install
# ------------------------------------------------------------------------------

include(GNUInstallDirs)
install(TARGETS ${PROJECT_NAME}
    EXPORT ${PROJECT_NAME}-targets
    LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
    ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
    RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
    INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
install(DIRECTORY include/ DESTINATION ${CMAKE_INSTALL_INCLUDEDIR})

# Generate and install a CMake package configuration file
install(EXPORT ${PROJECT_NAME}-targets
    FILE ${PROJECT_NAME}-config.cmake
    NAMESPACE ${PROJECT_NAME}::
    DESTINATION ${CMAKE_INSTALL_LIBDIR}/cmake/${PROJECT_NAME}
)




# # Install
# #==============================================================================

# install(TARGETS kth-c-api
#         EXPORT kth-c-api
#         LIBRARY DESTINATION "lib"
#         ARCHIVE DESTINATION "lib"
#         RUNTIME DESTINATION "lib"
#         COMPONENT library
#         )




# foreach (_header ${kth_headers})
#   get_filename_component(_directory "${_header}" DIRECTORY)
#   install(FILES "include/${_header}" DESTINATION "include/${_directory}")
# endforeach()

# # Export
# #==============================================================================
# include(CMakePackageConfigHelpers)

# export(EXPORT kth-c-api
#         FILE "${CMAKE_CURRENT_BINARY_DIR}/kth-c-apiTargets.cmake")
# export(PACKAGE kth-c-api)

# if (UNIX)
#   set(_config_package_location "lib/cmake")
# elseif (WIN32)
#   set(_config_package_location "cmake")
# endif()

# install(EXPORT kth-c-api
#         FILE kth-c-apiTargets.cmake
#         DESTINATION ${_config_package_location})

# configure_file(kth-c-apiConfig.cmake.in
#         "${CMAKE_CURRENT_BINARY_DIR}/kth-c-apiConfig.cmake"
#         @ONLY)

# write_basic_package_version_file(
#         "${CMAKE_CURRENT_BINARY_DIR}/kth-c-apiConfigVersion.cmake"
#         VERSION ${PROJECT_VERSION}
#         COMPATIBILITY AnyNewerVersion)

# install(
#         FILES
#         "${CMAKE_CURRENT_BINARY_DIR}/kth-c-apiConfig.cmake"
#         "${CMAKE_CURRENT_BINARY_DIR}/kth-c-apiConfigVersion.cmake"
#         DESTINATION ${_config_package_location})

