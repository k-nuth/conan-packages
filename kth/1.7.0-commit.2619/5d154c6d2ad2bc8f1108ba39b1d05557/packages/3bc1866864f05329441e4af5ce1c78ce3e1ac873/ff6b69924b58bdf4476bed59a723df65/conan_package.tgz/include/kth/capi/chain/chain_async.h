// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_CHAIN_CHAIN_ASYNC_H_
#define KTH_CAPI_CHAIN_CHAIN_ASYNC_H_

#include <stdint.h>

#include <kth/capi/primitives.h>
#include <kth/capi/visibility.h>

#ifdef __cplusplus
extern "C" {
#endif

// Async boundary contract: chain and ctx must remain valid for the operation.
// Handlers must be non-null and must not throw. Startup failure may complete
// inline. Allocation and other C++ failures report out_of_memory and
// unhandled_exception with zero/null outputs, respectively.

KTH_EXPORT
void kth_chain_async_last_height(kth_chain_t chain, void* ctx, kth_last_height_fetch_handler_t handler);

// kth_chain_async_mining_info is generated (see chain_mining.h).

// Async counterpart of kth_chain_sync_mining_template: the handler receives the
// header POD and the owned transaction selection once fetch_mining_template()
// completes. The handler must release the list with
// kth_domain_chain_transaction_list_destruct.
KTH_EXPORT
void kth_chain_async_mining_template(kth_chain_t chain, uint64_t coinbase_reserve_size, void* ctx, kth_mining_template_fetch_handler_t handler);

// kth_chain_async_block_height is generated (see chain_query.h).

// Block Header ---------------------------------------------------------------------
KTH_EXPORT
void kth_chain_async_block_header_by_height(kth_chain_t chain, void* ctx, kth_size_t height, kth_block_header_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_block_header_by_hash(kth_chain_t chain, void* ctx, kth_hash_t hash, kth_block_header_fetch_handler_t handler);

// Block ---------------------------------------------------------------------
KTH_EXPORT
void kth_chain_async_block_by_height(kth_chain_t chain, void* ctx, kth_size_t height, kth_block_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_block_by_height_timestamp(kth_chain_t chain, void* ctx, kth_size_t height, kth_blockhash_timestamp_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_block_by_hash(kth_chain_t chain, void* ctx, kth_hash_t hash, kth_block_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_block_header_by_hash_txs_size(kth_chain_t chain, void* ctx, kth_hash_t hash, kth_block_header_txs_size_fetch_handler_t handler);

// Merkle Block ---------------------------------------------------------------------
KTH_EXPORT
void kth_chain_async_merkle_block_by_height(kth_chain_t chain, void* ctx, kth_size_t height, kth_merkle_block_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_merkle_block_by_hash(kth_chain_t chain, void* ctx, kth_hash_t hash, kth_merkle_block_fetch_handler_t handler);

// Compact Block ---------------------------------------------------------------------
KTH_EXPORT
void kth_chain_async_compact_block_by_height(kth_chain_t chain, void* ctx, kth_size_t height, kth_compact_block_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_compact_block_by_hash(kth_chain_t chain, void* ctx, kth_hash_t hash, kth_compact_block_fetch_handler_t handler);



// Transaction ---------------------------------------------------------------------
KTH_EXPORT
void kth_chain_async_transaction(kth_chain_t chain, void* ctx, kth_hash_t hash, int require_confirmed, kth_transaction_fetch_handler_t handler);

KTH_EXPORT
void kth_chain_async_transaction_position(kth_chain_t chain, void* ctx, kth_hash_t hash, int require_confirmed, kth_transaction_index_fetch_handler_t handler);


// Spend / History / Confirmed transactions (confirmed address index) were backed
// by the LMDB spend and history stores, which the v1 node no longer maintains.
// Removed until a v1 address index is reintroduced.

// KTH_EXPORT
// void kth_chain_async_stealth(kth_chain_t chain, void* ctx, kth_binary_t filter, uint64_t from_height, kth_stealth_fetch_handler_t handler);

// Organizers.
//-------------------------------------------------------------------------

// Copies the block before returning. The caller keeps the node, context and
// callback alive until the callback returns, as for the other C async entries.
KTH_EXPORT
void kth_chain_async_submit_block(kth_chain_t chain, void* ctx, kth_block_mut_t block, kth_result_handler_t handler);

KTH_EXPORT
void kth_chain_async_organize_transaction(kth_chain_t chain, void* ctx, kth_transaction_mut_t transaction, kth_result_handler_t handler);

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* KTH_CAPI_CHAIN_CHAIN_ASYNC_H_ */
