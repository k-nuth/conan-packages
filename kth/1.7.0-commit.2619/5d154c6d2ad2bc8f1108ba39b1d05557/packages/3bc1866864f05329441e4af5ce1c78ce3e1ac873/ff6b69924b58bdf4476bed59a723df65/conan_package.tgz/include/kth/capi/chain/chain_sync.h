// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_CHAIN_CHAIN_SYNC_H_
#define KTH_CAPI_CHAIN_CHAIN_SYNC_H_

#include <kth/capi/chain/chain_submission.h>
#include <stdint.h>

#include <kth/capi/primitives.h>
#include <kth/capi/visibility.h>
#include <kth/capi/chain/mining_template.h>

#ifdef __cplusplus
extern "C" {
#endif

KTH_EXPORT
kth_error_code_t kth_chain_sync_last_height(kth_chain_t chain, kth_size_t* out_height);

// kth_chain_sync_block_height is generated (see chain_query.h).


// Block Header ---------------------------------------------------------------------
KTH_EXPORT
kth_error_code_t kth_chain_sync_block_header_by_height(kth_chain_t chain, kth_size_t height, kth_header_mut_t* out_header, kth_size_t* out_height);

KTH_EXPORT
kth_error_code_t kth_chain_sync_block_header_by_hash(kth_chain_t chain, kth_hash_t hash, kth_header_mut_t* out_header, kth_size_t* out_height);

// Block ---------------------------------------------------------------------
KTH_EXPORT
kth_error_code_t kth_chain_sync_block_by_height(kth_chain_t chain, kth_size_t height, kth_block_mut_t* out_block, kth_size_t* out_height);

KTH_EXPORT
kth_error_code_t kth_chain_sync_block_by_height_timestamp(kth_chain_t chain, kth_size_t height, kth_hash_t* out_hash, uint32_t* out_timestamp);

KTH_EXPORT
kth_error_code_t kth_chain_sync_block_by_hash(kth_chain_t chain, kth_hash_t hash, kth_block_mut_t* out_block, kth_size_t* out_height);

KTH_EXPORT
kth_error_code_t kth_chain_sync_block_header_byhash_txs_size(kth_chain_t chain, kth_hash_t hash, kth_header_mut_t* out_header, uint64_t* out_block_height, kth_hash_list_mut_t* out_tx_hashes, uint64_t* out_serialized_size);

KTH_EXPORT
kth_error_code_t kth_chain_sync_block_hash(kth_chain_t chain, kth_size_t height, kth_hash_t* out_hash);

// Merkle Block ---------------------------------------------------------------------
KTH_EXPORT
kth_error_code_t kth_chain_sync_merkle_block_by_height(kth_chain_t chain, kth_size_t height, kth_merkle_block_mut_t* out_block, kth_size_t* out_height);

KTH_EXPORT
kth_error_code_t kth_chain_sync_merkle_block_by_hash(kth_chain_t chain, kth_hash_t hash, kth_merkle_block_mut_t* out_block, kth_size_t* out_height);

// Compact Block ---------------------------------------------------------------------
KTH_EXPORT
kth_error_code_t kth_chain_sync_compact_block_by_height(kth_chain_t chain, kth_size_t height, kth_compact_block_mut_t* out_block, kth_size_t* out_height);

KTH_EXPORT
kth_error_code_t kth_chain_sync_compact_block_by_hash(kth_chain_t chain, kth_hash_t hash, kth_compact_block_mut_t* out_block, kth_size_t* out_height);

// Transaction ---------------------------------------------------------------------
KTH_EXPORT
kth_error_code_t kth_chain_sync_transaction(kth_chain_t chain, kth_hash_t hash, int require_confirmed, kth_transaction_mut_t* out_transaction, kth_size_t* out_height, kth_size_t* out_index);

KTH_EXPORT
kth_error_code_t kth_chain_sync_transaction_position(kth_chain_t chain, kth_hash_t hash, int require_confirmed, kth_size_t* out_position, kth_size_t* out_height);


// Spend / History / Confirmed transactions (confirmed address index) were backed
// by the LMDB spend and history stores, which the v1 node no longer maintains.
// Removed until a v1 address index is reintroduced.

// // Stealth ---------------------------------------------------------------------
// KTH_EXPORT
// kth_error_code_t kth_chain_sync_stealth(kth_chain_t chain, kth_binary_t filter, uint64_t from_height, kth_stealth_compact_list_t* out_list);

// NOTE: output-side (credit) entries only. Resolving an input's debit requires the
// spent prevout's value, which came from the confirmed-transaction store; that store
// was removed (blocks live in flat files, the UTXO set in UTXO-Z). Until a v1 lookup
// is added (issue #491) this is NOT a complete input/output balance ledger — do not
// use it to compute balances.
KTH_EXPORT
kth_mempool_transaction_list_t kth_chain_sync_mempool_transactions(kth_chain_t chain, kth_payment_address_t address, kth_bool_t use_testnet_rules);

KTH_EXPORT
kth_transaction_list_mut_t kth_chain_sync_mempool_transactions_from_wallets(kth_chain_t chain, kth_payment_address_list_t addresses, kth_bool_t use_testnet_rules);

/**
 * Fetch the mining template. On success fills `out` with the header fields and
 * hands back the transaction selection as an owned `*out_txs`.
 * @return Owned `*out_txs` on success. Caller must release it with
 *   `kth_domain_chain_transaction_list_destruct`.
 */
KTH_EXPORT KTH_OWNED
kth_error_code_t kth_chain_sync_mining_template(kth_chain_t chain, uint64_t coinbase_reserve_size, kth_mining_template_t* out, kth_transaction_list_mut_t* out_txs);

KTH_EXPORT
int kth_chain_sync_organize_transaction(kth_chain_t chain, kth_transaction_mut_t transaction);

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* KTH_CAPI_CHAIN_CHAIN_SYNC_H_ */
