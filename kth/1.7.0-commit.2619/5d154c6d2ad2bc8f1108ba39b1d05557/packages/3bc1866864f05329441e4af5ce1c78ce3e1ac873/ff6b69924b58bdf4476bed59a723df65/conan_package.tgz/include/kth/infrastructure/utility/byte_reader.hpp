// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_INFRASTRUCTURE_BYTES_READER_HPP
#define KTH_INFRASTRUCTURE_BYTES_READER_HPP

#include <cstdint>
#include <cstring>
#include <expected>
#include <memory>
#include <span>
#include <string>
#include <type_traits>
#include <vector>

#include <kth/infrastructure/concepts.hpp>
#include <kth/infrastructure/constants.hpp>
#include <kth/infrastructure/expect.hpp>
#include <kth/infrastructure/error.hpp>
#include <kth/infrastructure/utility/data.hpp>

namespace kth {

using byte = byte_span::value_type;


struct byte_reader {
    constexpr explicit
    byte_reader(byte_span buffer) noexcept
        : buffer_(buffer)
        , position_(0)
    {}

    [[nodiscard]] constexpr
    size_t buffer_size() const noexcept { return buffer_.size(); }

    [[nodiscard]] constexpr
    byte_span buffer() const noexcept { return buffer_; }

    [[nodiscard]] constexpr
    size_t remaining_size() const noexcept { return buffer_.size() - position_; }

    [[nodiscard]] constexpr
    size_t position() const noexcept { return position_; }

    [[nodiscard]] constexpr
    expect<void> skip(size_t count) {
        // `position_ + count` would wrap modulo 2^64 and let a huge count pass.
        if (count > remaining_size()) {
            return std::unexpected(error::skip_past_end_of_buffer);
        }
        position_ += count;
        return {};
    }

    constexpr
    void unsafe_skip_byte() {
        ++position_;
    }

    [[nodiscard]] constexpr
    expect<void> skip_byte() {
        if (position_ >= buffer_.size()) {
            return std::unexpected(error::skip_past_end_of_buffer);
        }
        unsafe_skip_byte();
        return {};
    }

    constexpr
    byte unsafe_read_byte() noexcept {
        return buffer_[position_++];
    }

    [[nodiscard]] constexpr
    expect<byte> read_byte() noexcept {
        if (position_ >= buffer_.size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        return unsafe_read_byte();
    }

    [[nodiscard]] constexpr
    expect<byte> peek_byte() const {
        if (position_ >= buffer_.size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        return buffer_[position_];
    }

    [[nodiscard]] constexpr
    expect<byte_span> read_bytes(size_t size) noexcept {
        if (size > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        auto const start = position_;
        position_ += size;
        return buffer_.subspan(start, size);
    }

    // Read bytes directly into a destination buffer.
    // Size to read is determined by dest.size().
    [[nodiscard]]
    expect<void> read_bytes_to(std::span<uint8_t> dest) noexcept {
        if (dest.size() > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        // Nothing to read. An empty destination's data() may be null, and so
        // may an empty buffer's, and memcpy is undefined for a null pointer
        // even with a count of zero.
        if (dest.empty()) {
            return {};
        }
        std::memcpy(dest.data(), buffer_.data() + position_, dest.size());
        position_ += dest.size();
        return {};
    }

    // Read bytes directly into a fixed-size array.
    template <size_t N>
    [[nodiscard]]
    expect<std::array<uint8_t, N>> read_array() {
        if (N > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        std::array<uint8_t, N> result;
        // A zero-length std::array's data() may be null, and memcpy
        // requires valid pointers even for zero bytes.
        if constexpr (N > 0) {
            std::memcpy(result.data(), buffer_.data() + position_, N);
        }
        position_ += N;
        return result;
    }

    [[nodiscard]] constexpr
    expect<byte_span> read_remaining_bytes() {
        auto const start = position_;
        position_ = buffer_.size();
        return buffer_.subspan(start);
    }

    constexpr
    void skip_remaining() noexcept {
        position_ = buffer_.size();
    }

    template <std::integral I>
    [[nodiscard]]
    expect<I> read_little_endian() noexcept {
        if (sizeof(I) > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        I value = 0;
        std::memcpy(&value, buffer_.data() + position_, sizeof(I));
        position_ += sizeof(I);
        return value;
    }

    template <std::integral I>
    [[nodiscard]] constexpr
    expect<I> read_big_endian() {
        if (sizeof(I) > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        I value = 0;
        for (size_t i = 0; i < sizeof(I); ++i) {
            value = (value << 8) | buffer_[position_++];
        }
        return value;
    }

    template <trivially_copyable T>
    [[nodiscard]]
    expect<T> read_packed()
        noexcept(std::is_nothrow_default_constructible_v<T> &&
                 std::is_nothrow_move_constructible_v<T>)
    {
        if (sizeof(T) > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }
        T value;
        // `std::addressof`: a trivially copyable `T` may overload `operator&`.
        std::memcpy(std::addressof(value), buffer_.data() + position_, sizeof(T));
        position_ += sizeof(T);
        return value;
    }

    [[nodiscard]]
    expect<uint64_t> read_variable_little_endian() noexcept {
        auto const value_exp = read_byte();
        if ( ! value_exp) {
            return value_exp;
        }
        auto const value = *value_exp;

        // CompactSize uses the shortest width that represents its value.
        // Match BCHN ReadCompactSizeWithLimit before lengths reach any parser.
        auto const check_canonical = [](auto const& decoded, uint64_t minimum) -> expect<uint64_t> {
            if (!decoded) return std::unexpected(decoded.error());
            if (*decoded < minimum) return std::unexpected(error::invalid_size);
            return *decoded;
        };
        switch (value) {
            case varint_eight_bytes:
                return check_canonical(read_little_endian<uint64_t>(), 0x100000000ULL);
            case varint_four_bytes:
                return check_canonical(read_little_endian<uint32_t>(), 0x10000);
            case varint_two_bytes:
                return check_canonical(read_little_endian<uint16_t>(), 0xfd);
            default:
                return value;
        }
    }

    [[nodiscard]]
    expect<size_t> read_size_little_endian() {
        auto const size_exp = read_variable_little_endian();
        if ( ! size_exp) {
            return size_exp;
        }
        // Note: size_t may be smaller than uint64_t on some platforms.
        // but Knuth requires sizeof(size_t) >= sizeof(uint64_t).
        return size_t(*size_exp);
    }

    // Removes trailing zeros, required for bitcoin string comparisons.
    [[nodiscard]]
    expect<std::string> read_string(size_t size) {
        if (size > remaining_size()) {
            return std::unexpected(error::read_past_end_of_buffer);
        }

        std::string out;
        out.reserve(size);
        bool terminated = false;

        for (size_t i = 0; i < size; ++i) {
            auto const character = unsafe_read_byte();
            terminated |= (character == string_terminator);
            if ( ! terminated) {
                out.push_back(character);
            }
        }
        out.shrink_to_fit();
        return out;
    }

    [[nodiscard]]
    expect<std::string> read_string() {
        auto const size = read_size_little_endian();
        if ( ! size) {
            return std::unexpected(size.error());
        }
        return read_string(*size);
    }

    [[nodiscard]] constexpr
    bool is_exhausted() const noexcept {
        return position_ >= buffer_.size();
    }

    constexpr
    void reset() {
        position_ = 0;
    }

private:
    byte_span buffer_;
    size_t position_;
};

// Anything with a `static expect<T> from_data(byte_reader&, args...)` factory.
// Symmetric to `Serializable` in byte_writer.hpp.
template <typename T, typename... Args>
concept Deserializable = requires(byte_reader& r, Args... args) {
    { T::from_data(r, args...) } -> std::same_as<expect<T>>;
};

// Build a `byte_reader` over `data` and invoke `T::from_data(reader, args...)`.
// Replaces the boilerplate of constructing a reader at every call site that
// already holds a `data_chunk` (or any contiguous byte range).
template <typename T, typename Range, typename... Args>
    requires Deserializable<T, Args...>
[[nodiscard]] inline
expect<T> from_data_chunk(Range const& data, Args... args) {
    byte_reader reader(byte_span{data});
    return T::from_data(reader, args...);
}

} // namespace kth

#endif // KTH_INFRASTRUCTURE_BYTES_READER_HPP
