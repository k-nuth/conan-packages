// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

// This file is auto-generated. Do not edit manually.

#ifndef KTH_CAPI_CHAIN_SCRIPT_VERSION_H_
#define KTH_CAPI_CHAIN_SCRIPT_VERSION_H_

#ifdef __cplusplus
extern "C" {
#endif

#if ! defined(KTH_CURRENCY_BCH)
typedef enum {
    /// Defined by bip141.
    kth_script_version_zero,

    /// All reserved script versions (1..16).
    kth_script_version_reserved,

    /// All unversioned scripts.
    kth_script_version_unversioned,
} kth_script_version_t;

#endif // ! defined(KTH_CURRENCY_BCH)

#ifdef __cplusplus
} // extern "C"
#endif

#endif /* KTH_CAPI_CHAIN_SCRIPT_VERSION_H_ */
