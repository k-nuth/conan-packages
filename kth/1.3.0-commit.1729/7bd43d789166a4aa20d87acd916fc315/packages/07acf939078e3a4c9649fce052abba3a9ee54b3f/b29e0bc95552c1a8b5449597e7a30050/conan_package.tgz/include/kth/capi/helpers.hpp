// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_HELPERS_HPP_
#define KTH_CAPI_HELPERS_HPP_

#include <array>
#include <cstddef>
#include <cstring>
#include <memory>
#include <optional>
#include <concepts>
#include <type_traits>
#include <utility>
#include <vector>

#include <kth/capi/wallet/primitives.h>
#include <kth/domain/chain/history.hpp>
#include <kth/domain/chain/script.hpp>
#include <kth/domain/chain/token_data.hpp>
#include <kth/domain/config/network.hpp>
#include <kth/domain/machine/opcode.hpp>
#include <kth/domain/wallet/encrypted_keys.hpp>
#include <kth/domain/wallet/hd_public.hpp>
#include <kth/domain/wallet/message.hpp>
#include <kth/domain/wallet/wallet_manager.hpp>

#include <kth/infrastructure/math/hash.hpp>
#include <kth/infrastructure/error.hpp>
#include <kth/infrastructure/machine/script_version.hpp>
#include <kth/infrastructure/utility/assert.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>

#include <kth/capi/wallet/coin_selection_algorithm.h>
#include <kth/capi/wallet/coin_selection_strategy.h>
#include <kth/domain/wallet/coin_selection.hpp>
#include <kth/capi/chain/opcode.h>
#include <kth/capi/chain/script_flags.h>
#include <kth/capi/chain/script_pattern.h>
#include <kth/capi/chain/script_version.h>
#include <kth/capi/chain/token_capability.h>

// #ifndef __EMSCRIPTEN__
#include <kth/node/full_node.hpp>
// #endif

#include <kth/capi/secure_memory.h>


namespace kth {

// RAII scrub for stack-local `kth::hash_digest` / `kth::hd_key` /
// `kth::encrypted_seed` / WIF copies that the C-API impl materialises
// from a `kth_xxx_t const*` input via `hash_to_cpp` / `hd_key_to_cpp` /
// etc. The C-API leaves those copies on its own stack frame; a guard
// scoped for the lifetime of the local wipes them on every return path
// (including exceptions propagating past KTH_PRECONDITION / expected
// error-returns) so key material does not linger beyond the call.
//
// Declared non-copyable / non-movable so accidental copies can't
// duplicate the pointer in multiple guards that would double-scrub
// (harmless but confusing if later changed to do more).
struct secure_scrub {
    void* p;
    std::size_t n;

    secure_scrub(void* p_, std::size_t n_) noexcept : p(p_), n(n_) {}
    ~secure_scrub() noexcept { kth_core_secure_zero(p, n); }

    secure_scrub(secure_scrub const&) = delete;
    secure_scrub(secure_scrub&&) = delete;
    secure_scrub& operator=(secure_scrub const&) = delete;
    secure_scrub& operator=(secure_scrub&&) = delete;
};

namespace detail {

// template <typename T>
// using remove_cv_t = typename std::remove_cv<T>::type;

// template <typename T, std::size_t N, std::size_t... I>
// constexpr
// std::array<remove_cv_t<T>, N>
// to_array_impl(T (&x)[N], std::index_sequence<I...> /*unused*/) {
//     return { {x[I]...} };
// }

// template <typename R, typename T, std::size_t N, std::size_t... I>
// constexpr
// R to_c_array_impl(std::array<T, N> const& x, std::index_sequence<I...> /*unused*/) {
//     return { {x[I]...} };
// }

} /* namespace detail */

// template <typename T, std::size_t N>
// constexpr
// std::array<remove_cv_t<T>, N> to_array(T (&x)[N]) {
//     return detail::to_array_impl(x, std::make_index_sequence<N>{});
// }

// template <typename R, typename T, std::size_t N>
// constexpr
// R to_c_array(std::array<T, N> const& x) {
//     return detail::to_c_array_impl<R>(x, std::make_index_sequence<N>{});
// }

#if defined(_WIN32)
using kth_string_t = std::wstring;
#else
using kth_string_t = std::string;
#endif


template <typename T>
constexpr
std::array<std::remove_cv_t<T>, 32> to_array(T (&x)[32]) {
    // return detail::to_array_impl(x, std::make_index_sequence<N>{});
    // return std::array<std::remove_cv_t<T>, 32> {{

    return {{
        x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
        x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
        x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
        x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31]}};
}

template <typename T>
constexpr
std::array<std::remove_cv_t<T>, 96> to_array(T (&x)[96]) {
    // return detail::to_array_impl(x, std::make_index_sequence<N>{});
    // return std::array<std::remove_cv_t<T>, 32> {{

    return {{
        x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
        x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
        x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
        x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31],
        x[32], x[33], x[34], x[35], x[36], x[37], x[38], x[39],
        x[40], x[41], x[42], x[43], x[44], x[45], x[46], x[47],
        x[48], x[49], x[50], x[51], x[52], x[53], x[54], x[55],
        x[56], x[57], x[58], x[59], x[60], x[61], x[62], x[63],
        x[64], x[65], x[66], x[67], x[68], x[69], x[70], x[71],
        x[72], x[73], x[74], x[75], x[76], x[77], x[78], x[79],
        x[80], x[81], x[82], x[83], x[84], x[85], x[86], x[87],
        x[88], x[89], x[90], x[91], x[92], x[93], x[94], x[95]
    }};
}

inline
kth_hash_t to_hash_t(kth::hash_digest const& x) {
    // return to_c_array<kth_hash_t>(x);
    return { {x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
              x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
              x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
              x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31]} };
}

inline
kth_shorthash_t to_shorthash_t(kth::short_hash const& x) {
    // return to_c_array<kth_shorthash_t>(x);
    return { {x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
              x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
              x[16], x[17], x[18], x[19]} };
}

inline
kth_longhash_t to_longhash_t(kth::long_hash const& x) {
    // return to_c_array<kth_longhash_t>(x);

    return { {x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
              x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
              x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
              x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31],
              x[32], x[33], x[34], x[35], x[36], x[37], x[38], x[39],
              x[40], x[41], x[42], x[43], x[44], x[45], x[46], x[47],
              x[48], x[49], x[50], x[51], x[52], x[53], x[54], x[55],
              x[56], x[57], x[58], x[59], x[60], x[61], x[62], x[63]} };

}

inline
kth_encrypted_seed_t to_encrypted_seed_t(kth::domain::wallet::encrypted_seed_t const& x) {
    return { {x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
              x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
              x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
              x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31],
              x[32], x[33], x[34], x[35], x[36], x[37], x[38], x[39],
              x[40], x[41], x[42], x[43], x[44], x[45], x[46], x[47],
              x[48], x[49], x[50], x[51], x[52], x[53], x[54], x[55],
              x[56], x[57], x[58], x[59], x[60], x[61], x[62], x[63],
              x[64], x[65], x[66], x[67], x[68], x[69], x[70], x[71],
              x[72], x[73], x[74], x[75], x[76], x[77], x[78], x[79],
              x[80], x[81], x[82], x[83], x[84], x[85], x[86], x[87],
              x[88], x[89], x[90], x[91], x[92], x[93], x[94], x[95]} };
}

// inline
// kth_ec_secret_t to_ec_secret_t(kth::hash_digest const& x) {
//     return { {x[0],  x[1],  x[2],  x[3],  x[4],  x[5],  x[6], x[7],
//               x[8],  x[9],  x[10], x[11], x[12], x[13], x[14], x[15],
//               x[16], x[17], x[18], x[19], x[20], x[21], x[22], x[23],
//               x[24], x[25], x[26], x[27], x[28], x[29], x[30], x[31]} };
// }

// constexpr kth_ec_secret_t null_ec_secret = {
//     {0, 0, 0, 0, 0, 0, 0, 0,
//     0, 0, 0, 0, 0, 0, 0, 0,
//     0, 0, 0, 0, 0, 0, 0, 0,
//     0, 0, 0, 0, 0, 0, 0, 0}};

// Cast a C-side integral to a C++ strongly-typed enum.
// Underlying form is `static_cast<E>(x)`. Use this only on the
// to_c direction (a valid C++ enum value is always representable
// as the underlying integer) or for enums whose entire integer
// range is meaningful by design — opcodes (every byte 0..255 is
// a valid placeholder), bitfields (`script_flags`), or other
// uses where "out of range" is not a concept. Discrete enums
// take a dedicated `<name>_to_cpp` helper with an explicit
// switch + safe default; see below.
template <typename E, typename T>
inline constexpr E ecast(T x) {
    return static_cast<E>(x);
}

// Per-enum named conversions. The to_cpp direction validates the C
// integer against the enum's known cases and falls through to a
// sensible default for out-of-range values — `static_cast` on an
// out-of-range integer to an `enum class` produces an unspecified
// value (UB in practice), so callers that hand us a stale or
// fuzzed enum integer would silently land on garbage without these
// switches. The to_c direction stays as a plain cast: every C++
// enum value is by definition representable as the underlying
// integer.
inline constexpr kth::domain::chain::point_kind point_kind_to_cpp(kth_point_kind_t x) {
    switch (x) {
        case kth_point_kind_spend:
            return kth::domain::chain::point_kind::spend;
        default:
        case kth_point_kind_output:
            return kth::domain::chain::point_kind::output;
    }
}
inline constexpr kth_point_kind_t point_kind_to_c(kth::domain::chain::point_kind x) {
    return ecast<kth_point_kind_t>(x);
}

inline
kth::hash_digest hash_to_cpp(uint8_t const* x) {
    kth::hash_digest ret;
    std::copy_n(x, ret.size(), std::begin(ret));
    return ret;
}


inline
kth::short_hash short_hash_to_cpp(uint8_t const* x) {
    kth::short_hash ret;
    std::copy_n(x, ret.size(), std::begin(ret));
    return ret;
}

inline
kth::long_hash long_hash_to_cpp(uint8_t const* x) {
    kth::long_hash ret;
    std::copy_n(x, ret.size(), std::begin(ret));
    return ret;
}

inline
kth_payment_t to_payment_t(kth::domain::wallet::payment const& x) {
    kth_payment_t ret;
    std::copy_n(x.begin(), x.size(), ret.hash);
    return ret;
}

inline
kth::domain::wallet::payment payment_to_cpp(uint8_t const* x) {
    kth::domain::wallet::payment ret;
    std::copy_n(x, ret.size(), std::begin(ret));
    return ret;
}

// Generic helper for C-compatible POD struct conversions.
// Uses memcpy (standard-compliant, zero overhead — compilers optimize
// Validity check for owned opaque handles returned by constructors and
// factory methods. Prefers an explicit `T::valid()` when the type
// exposes one, falls back to `operator bool` for the wallet types that
// still expose it, and treats everything else as valid.
template<typename T>
inline bool check_valid(T* obj) {
    if constexpr (requires (T const& t) { { t.valid() } -> std::same_as<bool>; }) {
        return obj->valid();
    } else if constexpr (std::is_constructible_v<bool, T const&>) {
        return static_cast<bool>(static_cast<T const&>(*obj));
    } else {
        return true;
    }
}

// Short alias for the `*static_cast<T*>(handle)` pattern used everywhere
// an opaque C handle is crossed back into a C++ reference. The const
// overload kicks in automatically when the handle is a `void const*`.
template<typename T> inline T&       cpp_ref(void* h)       { return *static_cast<T*>(h); }
template<typename T> inline T const& cpp_ref(void const* h) { return *static_cast<T const*>(h); }

// Companion for `std::optional<T>` parameters: NULL on the C side is
// `std::nullopt`, any non-null handle is wrapped into an engaged
// optional carrying a value copy. Keeps the optional-param call site
// a single expression instead of the inline ternary spellout.
template<typename T>
inline std::optional<T> optional_cpp_ref(void const* h) {
    return h == nullptr ? std::nullopt : std::optional<T>(cpp_ref<T>(h));
}

// small struct memcpy to register moves). static_assert guards that the
// source and destination structs have the same size.
// Works both directions: C→C++ and C++→C.
// A type that has an explicit field-by-field conversion opts out of the byte
// copy here, on both sides of the crossing. Specialize it next to that
// conversion; the generic path below then refuses the type instead of silently
// reintroducing the coupling the explicit conversion exists to remove.
template<typename T>
struct forbids_struct_cast : std::false_type {};

template<typename To, typename From>
inline To struct_cast(From const& src) {
    static_assert( ! forbids_struct_cast<To>::value && ! forbids_struct_cast<From>::value,
                  "this type crosses field by field; the memcpy conversion would put its "
                  "layout, padding and declaration order back into the ABI");
    static_assert(sizeof(To) == sizeof(From),
                  "C and C++ struct sizes must match for memcpy conversion");
    static_assert(std::is_trivially_copyable_v<To> && std::is_trivially_copyable_v<From>,
                  "both types must be trivially copyable for memcpy conversion");
    static_assert(std::is_standard_layout_v<To> && std::is_standard_layout_v<From>,
                  "both types must be standard layout for layout-compatible conversion");
    To dst;
    std::memcpy(&dst, &src, sizeof(dst));
    return dst;
}

// Convenience aliases for readability in generated code.
template<typename CType, typename CppType>
inline CType to_c_struct(CppType const& cpp) { return struct_cast<CType>(cpp); }

template<typename CppType, typename CType>
inline CppType from_c_struct(CType const& c) { return struct_cast<CppType>(c); }

// Generic helpers for value_struct ↔ C++ array conversions.
// Covers ec_compressed (33), ec_uncompressed (65), wif_compressed (38),
// wif_uncompressed (37), and any future fixed-size byte arrays.
template<size_t N>
inline
std::array<uint8_t, N> to_array_cpp(uint8_t const* x) {
    std::array<uint8_t, N> ret;
    std::copy_n(x, N, ret.begin());
    return ret;
}

// ec_compressed (33 bytes)
inline kth_ec_compressed_t to_ec_compressed_t(kth::ec_compressed const& x) {
    kth_ec_compressed_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::ec_compressed ec_compressed_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::ec_compressed_size>(x);
}

// ec_uncompressed (65 bytes)
inline kth_ec_uncompressed_t to_ec_uncompressed_t(kth::ec_uncompressed const& x) {
    kth_ec_uncompressed_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::ec_uncompressed ec_uncompressed_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::ec_uncompressed_size>(x);
}

// message_signature (65 bytes: BIP137 magic byte + ECDSA r,s). Same
// underlying layout as `ec_uncompressed` (both are byte_array<65>),
// but exposed as a distinct helper so call sites carry the right
// intent — a signature, not a public key point.
inline kth_message_signature_t to_message_signature_t(
        kth::domain::wallet::message_signature const& x) {
    kth_message_signature_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::message_signature message_signature_to_cpp(
        uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::message_signature_size>(x);
}

// wif_compressed (38 bytes)
inline kth_wif_compressed_t to_wif_compressed_t(kth::domain::wallet::wif_compressed const& x) {
    kth_wif_compressed_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::wif_compressed wif_compressed_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::wif_compressed_size>(x);
}

// wif_uncompressed (37 bytes)
inline kth_wif_uncompressed_t to_wif_uncompressed_t(kth::domain::wallet::wif_uncompressed const& x) {
    kth_wif_uncompressed_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::wif_uncompressed wif_uncompressed_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::wif_uncompressed_size>(x);
}

// hd_key (82 bytes)
inline kth_hd_key_t to_hd_key_t(kth::domain::wallet::hd_key const& x) {
    kth_hd_key_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::hd_key hd_key_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::hd_key_size>(x);
}

// encrypted_seed (96 bytes)
inline kth::domain::wallet::encrypted_seed_t encrypted_seed_to_cpp(uint8_t const* x) {
    return to_array_cpp<std::tuple_size_v<kth::domain::wallet::encrypted_seed_t>>(x);
}

// BIP38 encrypted_private (43 bytes)
inline kth_encrypted_private_t to_encrypted_private_t(kth::domain::wallet::encrypted_private const& x) {
    kth_encrypted_private_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::encrypted_private encrypted_private_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::ek_private_decoded_size>(x);
}

// BIP38 encrypted_public (55 bytes)
inline kth_encrypted_public_t to_encrypted_public_t(kth::domain::wallet::encrypted_public const& x) {
    kth_encrypted_public_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::encrypted_public encrypted_public_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::encrypted_public_decoded_size>(x);
}

// BIP38 encrypted_token (53 bytes)
inline kth_encrypted_token_t to_encrypted_token_t(kth::domain::wallet::encrypted_token const& x) {
    kth_encrypted_token_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::encrypted_token encrypted_token_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::encrypted_token_decoded_size>(x);
}

// BIP38 ek_seed (24 bytes) — caller-provided key-pair randomness.
inline kth_ek_seed_t to_ek_seed_t(kth::domain::wallet::ek_seed const& x) {
    kth_ek_seed_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::ek_seed ek_seed_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::ek_seed_size>(x);
}

// BIP38 ek_salt (4 bytes) — lot+sequence-mode salt input.
inline kth_ek_salt_t to_ek_salt_t(kth::domain::wallet::ek_salt const& x) {
    kth_ek_salt_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::ek_salt ek_salt_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::ek_salt_size>(x);
}

// BIP38 ek_entropy (8 bytes) — passphrase-mode token randomness.
inline kth_ek_entropy_t to_ek_entropy_t(kth::domain::wallet::ek_entropy const& x) {
    kth_ek_entropy_t ret;
    std::copy_n(x.begin(), x.size(), ret.data);
    return ret;
}
inline kth::domain::wallet::ek_entropy ek_entropy_to_cpp(uint8_t const* x) {
    return to_array_cpp<kth::domain::wallet::ek_entropy_size>(x);
}

template <typename T>
inline
T* mnew(std::size_t n = 1) {
    return static_cast<T*>(malloc(sizeof(T) * n));
}

inline
std::size_t c_str_len(char const* str) {
    return std::strlen(str);
}

inline
std::size_t c_str_len(wchar_t const* str) {
    return std::wcslen(str);
}

inline
char* c_str_cpy(char* dest, char const* src) {
    return strcpy(dest, src);
}

inline
wchar_t* c_str_cpy(wchar_t* dest, wchar_t const* src) {
    return wcscpy(dest, src);
}

template <typename CharT>
inline
CharT* allocate_and_copy_c_str(CharT const* str) {
    auto size = c_str_len(str);
    auto* c_str = mnew<CharT>(size + 1);
    c_str_cpy(c_str, str);
    return c_str;
}

template <typename StrT>
inline
auto* create_c_str(StrT const& str) {
    using CharT = typename StrT::value_type;
    auto* c_str = mnew<CharT>(str.size() + 1);
    std::copy_n(str.data(), str.size(), c_str);
    c_str[str.size()] = CharT{};  // null-terminate (works for string_view too)
    return c_str;
}

template <typename CharT>
inline
std::basic_string<CharT> create_cpp_str(CharT const* str) {
    return std::basic_string<CharT>(str);
}

template <typename N>
inline
uint8_t* create_c_array(kth::data_chunk const& arr, N& out_size) {
    // Allocate at least 1 byte so the returned pointer is non-NULL
    // even when `arr.size() == 0`. `malloc(0)` is implementation-
    // defined: some platforms return NULL, which would make
    // present-but-empty buffers indistinguishable from an absent-key
    // signal at call sites that use NULL to mean "not found" (e.g.
    // map `at()` accessors). The caller still reads only
    // `out_size == arr.size()` bytes; `kth_core_destruct_array` frees
    // the buffer regardless of size.
    auto const n = arr.size();
    auto* ret = mnew<uint8_t>(n != 0 ? n : 1);
    out_size = n;
    std::copy_n(arr.begin(), n, ret);
    return ret;
}

// Fused variant of `to_data_chunk(obj, args...)` + `create_c_array(chunk, out_size)`.
// The naive pipeline is `data_chunk → uint8_t*` and does two heap allocations
// (the vector, then the C buffer) plus one byte-for-byte copy. Fold both
// into a single `malloc(serialized_size)` and serialize straight into the
// C-owned buffer; the C-API `to_data` wrappers hit this once per exported
// object so removing the intermediate vector matters.
template <typename N, typename T, typename... Args>
    requires kth::Serializable<T, Args...>
inline
uint8_t* to_c_array_from(T const& obj, N& out_size, Args... args) {
    auto const n = obj.serialized_size(args...);
    // Same non-NULL sentinel as `create_c_array` — see comment there.
    auto* ret = mnew<uint8_t>(n != 0 ? n : 1);
    out_size = n;
    kth::byte_writer writer(std::span<uint8_t>{ret, n});
    auto const r = obj.to_data(writer, args...);
    // Failure here would ship a partially-initialised buffer over the C
    // ABI (garbage past `writer.position()`). `KTH_CONTRACT` stays live
    // in Release so we abort instead of returning a broken payload.
    KTH_CONTRACT(r.has_value());
    KTH_CONTRACT(writer.position() == n);
    return ret;
}

inline
kth_error_code_t to_c_err(std::error_code const& ec) {
    return static_cast<kth_error_code_t>(ec.value());
}

// Fallback for bare enum error arms (e.g. `kth::error::error_code_t`)
// used by `std::expected<T, EnumT>`. The non-template overload above
// wins for `std::error_code`; this template catches every other shape
// that is convertible to `kth_error_code_t`.
template <typename E>
inline
kth_error_code_t to_c_err(E const& e) {
    return static_cast<kth_error_code_t>(e);
}

template <typename HashCpp, typename HashC>
inline
void copy_c_hash(HashCpp const& in, HashC* out) {
    //precondition: size of out->hash is greater or equal than in.size()
    std::copy_n(in.begin(), in.size(), static_cast<uint8_t*>(out->hash));
}

inline
int bool_to_int(bool x) {
    return x;
}

inline
bool int_to_bool(int x) {
    return x;
}

// Concept used by `leak(T&&)` to step aside when the argument is a
// `std::shared_ptr`. In that case the caller wants the pointed-to
// object heap-copied (see the `leak(std::shared_ptr<T> const&)`
// overload later in this file), not the shared_ptr itself.
namespace detail {
template <typename>                    constexpr bool is_shared_ptr = false;
template <typename T> constexpr bool is_shared_ptr<std::shared_ptr<T>> = true;
} // namespace detail

template <typename T>
concept not_shared_ptr = ! detail::is_shared_ptr<std::remove_cvref_t<T>>;

// Promote a value to the heap and surrender ownership to the caller —
// i.e. "leak" it, which from the C-API perspective is exactly the
// transfer the consumer is expected to release later via the matching
// `kth_*_destruct` function. Forwards into `new T(...)`, so an rvalue
// is moved and an lvalue is copied. The name is intentional: it
// documents the ownership transfer at every call site (instead of
// hiding it behind a generic factory name), making leaks greppable.
//
// The `not_shared_ptr` constraint keeps this forwarding-reference
// overload out of the picture for `std::shared_ptr` arguments — those
// flow to the dedicated overload below that unwraps the shared_ptr
// and leaks the pointed-to object.
template <not_shared_ptr T>
std::decay_t<T>* leak(T&& x) {
    return new std::decay_t<T>(std::forward<T>(x));
}

// In-place variant: constructs `T` from the forwarded argument pack
// instead of copy/moving an already-built object. `T` must be given
// explicitly. For single-argument calls the deducing overload above
// is more specialised and wins overload resolution, so it handles
// the copy/move case; this overload kicks in for 0 or 2+ arguments,
// and also for 1-argument calls where the match against the deducing
// overload fails (e.g. an `explicit` constructor blocks the implicit
// conversion that overload would need).
template <typename T, typename... Args>
T* leak(Args&&... args) {
    return new T(std::forward<Args>(args)...);
}

// Copy an opaque handle: deref it back into `T const&` via `cpp_ref`
// and heap-allocate a fresh copy via `leak`. Collapses the generated
// copy-ctor body to a one-liner.
template <typename T>
inline T* clone(void const* h) {
    return leak<T>(cpp_ref<T>(h));
}

// Convenience: `leak` for a `std::vector<T>` heap allocation.
// Saves spelling out the inner `std::vector<...>` at the call site.
// Forwards every argument straight into the vector constructor, so
// `leak_list<T>()`, `leak_list<T>(n)`, `leak_list<T>(n, value)`,
// `leak_list<T>({a, b, c})` and `leak_list<T>(begin, end)` all work.
template <typename T, typename... Args>
std::vector<T>* leak_list(Args&&... args) {
    return new std::vector<T>(std::forward<Args>(args)...);
}

// Inverse of `leak` / `leak_list`: hands an opaque C handle back to
// `delete`. Null-safe, so generated destructors can call this
// unconditionally without a separate guard — passing `nullptr` is a
// no-op. `del_list<T>(h)` is the matching shortcut for vector handles.
template <typename T>
inline void del(void* h) {
    if (h == nullptr) return;
    delete &cpp_ref<T>(h);
}
template <typename T>
inline void del_list(void* h) {
    if (h == nullptr) return;
    delete &cpp_ref<std::vector<T>>(h);
}

// Equality through two opaque handles of the same type. Saves the
// double `cpp_ref<T>(...)` spelling and the outer `bool_to_int` wrap
// at every `_equals` call site.
template <typename T>
inline kth_bool_t eq(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) == cpp_ref<T>(b));
}

// Inequality counterpart for `_not_equal` bindings. Uses the
// compiler-synthesized `!=` rewrite (C++20 rewrites `a != b` to
// `!(a == b)` when only `operator==` is defined), so any T that
// exposes `_equals` also picks this up automatically.
template <typename T>
inline kth_bool_t ne(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) != cpp_ref<T>(b));
}

// Strict-less-than through two opaque handles of the same type.
// Counterpart to `eq` for `_less` bindings generated from `operator<`.
template <typename T>
inline kth_bool_t lt(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) < cpp_ref<T>(b));
}

// Strict-greater-than counterpart for `_greater` bindings. Uses the
// compiler-synthesized `>` from `operator<=>` when only the spaceship
// is defined.
template <typename T>
inline kth_bool_t gt(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) > cpp_ref<T>(b));
}

// Less-or-equal counterpart for `_less_or_equal` bindings.
template <typename T>
inline kth_bool_t le(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) <= cpp_ref<T>(b));
}

// Greater-or-equal counterpart for `_greater_or_equal` bindings.
template <typename T>
inline kth_bool_t ge(void const* a, void const* b) {
    return bool_to_int(cpp_ref<T>(a) >= cpp_ref<T>(b));
}

// `cpp_ref<std::vector<T>>(h)` shorthand. Same overload resolution
// trick as `cpp_ref`: the const handle picks the const reference.
template <typename T> inline std::vector<T>&       list_ref(void* h)       { return cpp_ref<std::vector<T>>(h); }
template <typename T> inline std::vector<T> const& list_ref(void const* h) { return cpp_ref<std::vector<T>>(h); }

// Shorthand for `static_cast<size_t>(x)` when crossing the FFI
// boundary (where sizes come in as `kth_size_t` / signed integers).
template <typename T>
inline std::size_t sz(T x) { return static_cast<std::size_t>(x); }

// Same as `leak`, but gates the leak on `check_valid(&x)`. The
// validity of the heap copy mirrors the source's validity (the
// constructor doesn't change `operator bool`), so we test `x` BEFORE
// allocating — invalid input returns `nullptr` without ever touching
// the heap. Matches the documented "or NULL on failure" contract that
// generated factories advertise. Sentinel factories whose return is
// intentionally `operator bool == false` (e.g. `point::null()`)
// should opt out and use `leak` instead.
template <typename T>
std::decay_t<T>* leak_if_valid(T&& x) {
    if ( ! check_valid(&x)) return nullptr;
    return new std::decay_t<T>(std::forward<T>(x));
}


inline
bool witness(int x = 1) {
#if defined(KTH_CURRENCY_BCH)
    return false;
#else
    return kth::int_to_bool(x);
#endif
}

// template <typename E1, typename E2>
// E1 c_enum_to_cpp_enum(E2 e) {
//     return static_cast<E1>(e);
// }

// Plain `static_cast`: every byte 0..255 is a valid opcode value
// in the protocol — there's no concept of "out of range" the way
// a discrete enum like `point_kind` has.
inline
kth::domain::machine::opcode opcode_to_cpp(kth_opcode_t op) {
    return static_cast<kth::domain::machine::opcode>(op);
}

inline
kth_opcode_t opcode_to_c(kth::domain::machine::opcode op) {
    return static_cast<kth_opcode_t>(op);
}

// Script Flags --------------------------------------------------------

inline
kth_script_flags_t script_flags_to_c(kth::domain::machine::script_flags flags) {
    return static_cast<kth_script_flags_t>(flags);
}

// Plain `static_cast`: `script_flags` is a `uint64_t` bitfield —
// any bit pattern is a meaningful (if possibly unknown) value, the
// interpreter ignores bits it doesn't recognise. Validating against
// a fixed set of cases would be wrong here.
inline
kth::domain::machine::script_flags script_flags_to_cpp(kth_script_flags_t flags) {
    return static_cast<kth::domain::machine::script_flags>(flags);
}

// Script Pattern -----------------------------------------------------

inline
kth_script_pattern_t script_pattern_to_c(kth::domain::machine::script_pattern pattern) {
    return static_cast<kth_script_pattern_t>(pattern);
}

inline
kth::domain::machine::script_pattern script_pattern_to_cpp(kth_script_pattern_t pattern) {
    using kth::domain::machine::script_pattern;
    switch (pattern) {
        case kth_script_pattern_null_data:                return script_pattern::null_data;
        case kth_script_pattern_pay_to_multisig:          return script_pattern::pay_to_multisig;
        case kth_script_pattern_pay_to_public_key:        return script_pattern::pay_to_public_key;
        case kth_script_pattern_pay_to_public_key_hash:   return script_pattern::pay_to_public_key_hash;
        case kth_script_pattern_pay_to_script_hash:       return script_pattern::pay_to_script_hash;
        case kth_script_pattern_pay_to_script_hash_32:    return script_pattern::pay_to_script_hash_32;
        case kth_script_pattern_pay_to_script:            return script_pattern::pay_to_script;
        case kth_script_pattern_sign_multisig:            return script_pattern::sign_multisig;
        case kth_script_pattern_sign_public_key:          return script_pattern::sign_public_key;
        case kth_script_pattern_sign_public_key_hash:     return script_pattern::sign_public_key_hash;
        case kth_script_pattern_sign_script_hash:         return script_pattern::sign_script_hash;
        case kth_script_pattern_witness_reservation:      return script_pattern::witness_reservation;
        default:
        case kth_script_pattern_non_standard:             return script_pattern::non_standard;
    }
}

// Script Version -----------------------------------------------------

#if ! defined(KTH_CURRENCY_BCH)
inline
kth::infrastructure::machine::script_version script_version_to_cpp(kth_script_version_t version) {
    using kth::infrastructure::machine::script_version;
    switch (version) {
        case kth_script_version_zero:
            return script_version::zero;
        case kth_script_version_reserved:
            return script_version::reserved;
        default:
        case kth_script_version_unversioned:
            return script_version::unversioned;
    }
}

inline
kth_script_version_t script_version_to_c(kth::infrastructure::machine::script_version version) {
    return static_cast<kth_script_version_t>(version);
}
#endif // ! KTH_CURRENCY_BCH
// Coin Selection -----------------------------------------------------

inline
kth::domain::wallet::coin_selection_algorithm coin_selection_algorithm_to_cpp(kth_coin_selection_algorithm_t algo) {
    using kth::domain::wallet::coin_selection_algorithm;
    switch (algo) {
        case kth_coin_selection_algorithm_largest_first:
            return coin_selection_algorithm::largest_first;
        case kth_coin_selection_algorithm_manual:
            return coin_selection_algorithm::manual;
        case kth_coin_selection_algorithm_send_all:
            return coin_selection_algorithm::send_all;
        default:
        case kth_coin_selection_algorithm_smallest_first:
            return coin_selection_algorithm::smallest_first;
    }
}

inline
kth_coin_selection_algorithm_t coin_selection_algorithm_to_c(kth::domain::wallet::coin_selection_algorithm algo) {
    return static_cast<kth_coin_selection_algorithm_t>(algo);
}

inline
kth::domain::wallet::coin_selection_strategy coin_selection_strategy_to_cpp(kth_coin_selection_strategy_t strategy) {
    using kth::domain::wallet::coin_selection_strategy;
    switch (strategy) {
        case kth_coin_selection_strategy_mixed:
            return coin_selection_strategy::mixed;
        default:
        case kth_coin_selection_strategy_clean:
            return coin_selection_strategy::clean;
    }
}

inline
kth_coin_selection_strategy_t coin_selection_strategy_to_c(kth::domain::wallet::coin_selection_strategy strategy) {
    return static_cast<kth_coin_selection_strategy_t>(strategy);
}

// Cash Tokens -----------------------------------------------------

inline
kth::domain::chain::capability_t token_capability_to_cpp(kth_token_capability_t capability) {
    using kth::domain::chain::capability_t;
    switch (capability) {
        case kth_token_capability_mut:
            return capability_t::mut;
        case kth_token_capability_minting:
            return capability_t::minting;
        default:
        case kth_token_capability_none:
            return capability_t::none;
    }
}

inline
kth_token_capability_t token_capability_to_c(kth::domain::chain::capability_t capability) {
    return static_cast<kth_token_capability_t>(capability);
}


// Endorsement -------------------------------------------------------------

inline
kth::domain::chain::endorsement_type endorsement_type_to_cpp(kth_endorsement_type_t type) {
    using kth::domain::chain::endorsement_type;
    switch (type) {
        case kth_endorsement_type_schnorr:
            return endorsement_type::schnorr;
        default:
        case kth_endorsement_type_ecdsa:
            return endorsement_type::ecdsa;
    }
}

inline
kth_endorsement_type_t endorsement_type_to_c(kth::domain::chain::endorsement_type type) {
    return static_cast<kth_endorsement_type_t>(type);
}


// Other -------------------------------------------------------------

inline
kth::domain::config::network network_to_cpp(kth_network_t net) {
    switch (net) {
        case kth_network_testnet:
            return kth::domain::config::network::testnet;
        case kth_network_regtest:
            return kth::domain::config::network::regtest;
#if defined(KTH_CURRENCY_BCH)
        case kth_network_testnet4:
            return kth::domain::config::network::testnet4;
        case kth_network_scalenet:
            return kth::domain::config::network::scalenet;
        case kth_network_chipnet:
            return kth::domain::config::network::chipnet;
#endif
        default:
        case kth_network_mainnet:
            return kth::domain::config::network::mainnet;
    }
}

inline
kth_network_t network_to_c(kth::domain::config::network net) {
    switch (net) {
        case kth::domain::config::network::testnet:
            return kth_network_testnet;
        case kth::domain::config::network::regtest:
            return kth_network_regtest;
#if defined(KTH_CURRENCY_BCH)
        case kth::domain::config::network::testnet4:
            return kth_network_testnet4;
        case kth::domain::config::network::scalenet:
            return kth_network_scalenet;
        case kth::domain::config::network::chipnet:
            return kth_network_chipnet;
#endif
        default:
        case kth::domain::config::network::mainnet:
            return kth_network_mainnet;
    }
}

// #ifndef __EMSCRIPTEN__
inline
kth::node::start_modules start_modules_to_cpp(kth_start_modules_t mods) {
    switch (mods) {
        case kth_start_modules_all:
            return kth::node::start_modules::all;
        case kth_start_modules_just_chain:
            return kth::node::start_modules::just_chain;
        case kth_start_modules_just_p2p:
            return kth::node::start_modules::just_p2p;
    }

    return kth::node::start_modules::all;
}
// #endif

template <typename T>
inline
std::remove_const_t<T>* leak_if_success(std::shared_ptr<T> const& ptr, std::error_code ec) {
    if (ec != kth::error::success) return nullptr;
    return new std::remove_const_t<T>(*ptr);
}

// Rvalue overload: caller has signalled they are done with `ptr`
// (e.g. passed `std::move(...)`), so we can move the pointed-to value
// into the heap copy instead of copying it. If `ptr` still shared
// ownership at the call site, the caller has violated the move
// contract — same rule as `std::move` anywhere else.
template <typename T>
inline
std::remove_const_t<T>* leak_if_success(std::shared_ptr<T>&& ptr, std::error_code ec) {
    if (ec != kth::error::success) return nullptr;
    return new std::remove_const_t<T>(std::move(*ptr));
}

// Non-shared_ptr overload: forwarding-reference so rvalues move and
// lvalues copy, without spelling out two bodies. The `not_shared_ptr`
// constraint keeps this out of the picture when the caller hands over
// a shared_ptr (see the two overloads above).
template <not_shared_ptr T>
inline
std::decay_t<T>* leak_if_success(T&& val, std::error_code ec) {
    if (ec != kth::error::success) return nullptr;
    return new std::decay_t<T>(std::forward<T>(val));
}

template <typename T>
inline
std::remove_const_t<T>* leak(std::shared_ptr<T> const& ptr) {
    if (! ptr) return nullptr;
    return new std::remove_const_t<T>(*ptr);
}

// Rvalue overload: same move-from-`*ptr` rationale as the
// `leak_if_success` rvalue variant above.
template <typename T>
inline
std::remove_const_t<T>* leak(std::shared_ptr<T>&& ptr) {
    if (! ptr) return nullptr;
    return new std::remove_const_t<T>(std::move(*ptr));
}

template <typename T>
inline
T* ref_to_c(T& x) {
    return &x;
}

template <typename T>
inline
T const* ref_to_c(T const& x) {
    return &x;
}

} // namespace kth

#endif /* KTH_CAPI_HELPERS_HPP_ */
