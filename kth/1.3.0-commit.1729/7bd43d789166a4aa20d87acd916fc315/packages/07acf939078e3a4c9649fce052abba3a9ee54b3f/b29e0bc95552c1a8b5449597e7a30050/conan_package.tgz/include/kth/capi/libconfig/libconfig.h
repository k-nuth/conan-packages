// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_LIBCONFIG_LIBCONFIG_H_
#define KTH_CAPI_LIBCONFIG_LIBCONFIG_H_

#include <kth/capi/config/blockchain_settings.h>
#include <kth/capi/config/database_settings.h>
#include <kth/capi/config/network_settings.h>
#include <kth/capi/config/node_settings.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    uint8_t size_int;
    uint8_t size_long;
    uint8_t size_pointer;
} kth_libconfig_type_sizes_t;

typedef struct {
    char const* version;
    char const* microarchitecture_id;
    kth_currency_t currency;
    kth_bool_t mempool;
    kth_bool_t db_readonly;
    kth_bool_t debug_mode;

    char const* architecture;          // x86_64, ARM64
    char const* os_name;               // Linux, Windows, macOS
    char const* compiler_name;         // GCC, Clang, MSVC
    char const* compiler_version;      // ej. "12.2.0"
    char const* optimization_level;    // -O2, -O3
    uint32_t build_timestamp;          // Epoch time
    char const* build_git_hash;        // Git hash
    char const* endianness;            // little, big

    kth_libconfig_type_sizes_t type_sizes;

} kth_libconfig_t;

KTH_EXPORT
kth_libconfig_t kth_libconfig_get();

#ifdef __cplusplus
} // extern "C"
#endif


#endif // KTH_CAPI_LIBCONFIG_LIBCONFIG_H_
