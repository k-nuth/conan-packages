// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_BLOCKCHAIN_POPULATE_BASE_HPP
#define KTH_BLOCKCHAIN_POPULATE_BASE_HPP

#include <cstddef>
#include <cstdint>

#include <kth/blockchain/define.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/domain.hpp>

#include <asio/any_io_executor.hpp>

namespace kth::blockchain {

// Forward declaration
struct block_chain;

/// This class is NOT thread safe.
class KB_API populate_base {
protected:
    using executor_type = ::asio::any_io_executor;

    populate_base(executor_type executor, size_t threads, block_chain const& chain);

    void populate_duplicate(size_t maximum_height, domain::chain::transaction const& tx, bool require_confirmed) const;
    void populate_pooled(domain::chain::transaction const& tx, uint32_t height) const;
    // median_time_past (tip's MTP) is used only for a prevout resolved from the
    // mempool. Block validation (require_confirmed) never consults the mempool.
    /// Populate one input's prevout from the UTXO set, or from the mempool when
    /// unconfirmed parents are allowed.
    ///
    /// @return error::success when the prevout was populated AND when it is
    ///         genuinely absent — absence is a verdict about the transaction and
    ///         is decided later, by the prevout cache being invalid. Any other
    ///         result_code from the store is an operational failure of THIS node
    ///         and is returned, because "could not read" must never reach that
    ///         verdict wearing the same face as "does not exist".
    [[nodiscard]]
    code populate_prevout(size_t maximum_height, domain::chain::output_point const& outpoint, bool require_confirmed, uint32_t median_time_past) const;

    // Thread pool executor for parallel operations
    executor_type executor_;
    size_t threads_;

    // The store is protected by caller not invoking populate concurrently.
    block_chain const& chain_;
};

} // namespace kth::blockchain

#endif
