// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_CAPI_VERSION_H_
#define KTH_CAPI_VERSION_H_

#define KTH_CAPI_VERSION "1.6.1-commit.2547";

#endif //KTH_CAPI_VERSION_H_
