// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_BLOCKCHAIN_HEADER_ORGANIZER_HPP
#define KTH_BLOCKCHAIN_HEADER_ORGANIZER_HPP

#include <atomic>
#include <cstddef>
#include <mutex>
#include <memory>

#include <kth/blockchain/define.hpp>
#include <kth/blockchain/finalization.hpp>
#include <kth/blockchain/header_index.hpp>
#include <kth/blockchain/settings.hpp>
#include <kth/blockchain/validate/validate_header.hpp>
#include <kth/domain.hpp>
#include <kth/domain/message/header.hpp>

namespace kth::blockchain {

/// Result of adding headers to the organizer
struct header_organize_result {
    code error;
    size_t headers_added{0};
    size_t index_size{0};
    size_t index_memory_bytes{0};

    // Fork detection (headers-first): set when a stored side branch that descends
    // from the finalized block reaches strictly greater cumulative chain work than
    // the active header tip — a reorganization candidate. The active tip is NOT
    // switched here; executing the switch is a separate layer.
    bool reorg_candidate{false};
    int32_t reorg_fork_height{-1};   // height of the common ancestor, or -1
    header_index::index_t reorg_branch_head{header_index::null_index};   // tip of the heavier branch
};

/// Header organizer for headers-first sync.
/// Validates headers and stores them in the header_index.
///
/// ARCHITECTURE:
/// -------------
/// The organizer validates headers as they arrive and stores them
/// in the header_index (SoA structure with O(1) hash lookup and
/// O(log n) ancestor lookup via skip pointers).
///
/// The header_index is owned by block_chain and passed by reference.
///
/// THREAD SAFETY:
/// --------------
/// Thread-safe through header_index's concurrent_flat_map.
struct KB_API header_organizer {
    using ptr = std::shared_ptr<header_organizer>;
    using index_t = header_index::index_t;

    /// Construct a header organizer.
    /// @param[in] index     Reference to the header index (owned by block_chain).
    /// @param[in] settings  Blockchain settings.
    /// @param[in] network   The network type.
    header_organizer(header_index& index, settings const& settings,
                     domain::config::network network);

    ~header_organizer() = default;

    // Non-copyable
    header_organizer(header_organizer const&) = delete;
    header_organizer& operator=(header_organizer const&) = delete;

    bool start();
    bool stop();

    /// Sync tip state from the header index.
    /// Call after header_index has been initialized (e.g., with genesis).
    void sync_tip();

    /// Adopt `tip_idx` as the header tip, after the execution layer switched the
    /// active chain onto it. The organizer decides whether an incoming batch
    /// extends the chain or forks it by comparing against the tip it remembers;
    /// left pointing at the abandoned branch it would read every subsequent
    /// batch as another fork and ask for a switch that cannot be executed.
    ///
    /// Publishes both halves of the tip — the index the organizer remembers and
    /// the height mapping the rest of the node reads — under one lock. The switch
    /// leaves the mapping to this call for exactly that reason: a header batch
    /// that validated against the old tip decides whether to publish under the
    /// same lock, so the two can no longer interleave into a state where the tip
    /// names one branch and the heights name another.
    void adopt_tip(index_t tip_idx);

    /// Notify the organizer that blocks are validated up to `block_valid_height`,
    /// advancing the finalized block per BCHN's depth + header-age rules. Called
    /// by the block-download/validation path as it advances the validated tip.
    void note_block_validated(int32_t block_valid_height);

    /// Height of the finalized block, or -1 if nothing is finalized yet.
    [[nodiscard]]
    int32_t finalized_height() const { return finalizer_.finalized_height(); }

    /// Read-only view of the finalization state (for header/reorg admission).
    [[nodiscard]]
    finalization const& finalized_state() const { return finalizer_; }

    /// Add a batch of headers to the organizer.
    /// Validates all headers and adds valid ones to the index.
    /// @param[in] headers  The headers to add.
    /// @return Result with error code and statistics.
    [[nodiscard]]
    header_organize_result add_headers(domain::message::header::list const& headers);

    // =========================================================================
    // Index Access
    // =========================================================================

    /// Get the header index.
    [[nodiscard]]
    header_index& index() { return index_; }

    [[nodiscard]]
    header_index const& index() const { return index_; }

    /// Find a header by hash.
    [[nodiscard]]
    index_t find(hash_digest const& hash) const { return index_.find(hash); }

    /// Check if a header exists.
    [[nodiscard]]
    bool contains(hash_digest const& hash) const { return index_.contains(hash); }

    // =========================================================================
    // State queries
    // =========================================================================

    /// Get the current tip index.
    [[nodiscard]]
    index_t tip_index() const { return tip_index_.load(std::memory_order_acquire); }

    /// Get the current header tip height.
    [[nodiscard]]
    int32_t header_height() const;

    /// Get the hash of the header tip. Read from the index rather than cached:
    /// the tip moves from two places (header organization and reorg execution),
    /// and a second copy of it would be a second thing to keep in step.
    [[nodiscard]]
    hash_digest header_tip_hash() const { return index_.get_hash(tip_index()); }

    /// Get the timestamp of the header tip.
    /// Used for BCHN-style progress calculation.
    [[nodiscard]]
    uint32_t tip_timestamp() const;

    /// Get the number of headers in the index.
    [[nodiscard]]
    size_t size() const { return index_.size(); }

    /// Get estimated memory usage.
    [[nodiscard]]
    size_t memory_usage() const { return index_.memory_usage(); }

protected:
    [[nodiscard]]
    bool stopped() const { return stopped_; }

private:
    // Validate a single header with full chain-state validation
    // Includes: PoW check, difficulty, checkpoint, version, MTP
    [[nodiscard]]
    code validate_full(domain::chain::header const& header,
                       hash_digest const& hash,
                       int32_t height,
                       header_index::index_t parent_idx) const;

    // Members
    header_index& index_;
    std::atomic<bool> stopped_{false};
    validate_header validator_;

    // Tracks the finalized block (BCHN parity). Advanced by note_block_validated;
    // read via finalized_state() for header/reorg admission.
    finalization finalizer_;

    // Current tip. Two writers now: header organization, and reorg execution
    // through adopt_tip. Atomic so a reader never sees a torn value, and guarded
    // by tip_mutex_ where it is published, because the hazard is not only tearing
    // — a batch that validated against the old tip must not put it back after a
    // switch replaced it.
    std::atomic<index_t> tip_index_{header_index::null_index};
    mutable std::mutex tip_mutex_;
};

} // namespace kth::blockchain

#endif // KTH_BLOCKCHAIN_HEADER_ORGANIZER_HPP
