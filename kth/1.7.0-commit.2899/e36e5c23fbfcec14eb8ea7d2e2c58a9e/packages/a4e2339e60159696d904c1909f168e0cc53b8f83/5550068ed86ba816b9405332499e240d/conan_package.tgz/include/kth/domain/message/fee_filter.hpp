// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_MESSAGE_FEE_FILTER_HPP
#define KTH_DOMAIN_MESSAGE_FEE_FILTER_HPP

#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

#include <kth/domain/message/version.hpp>
#include <kth/domain/define.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>
#include <kth/domain/concepts.hpp>

namespace kth::domain::message {

struct KD_API fee_filter {
    using ptr = std::shared_ptr<fee_filter>;
    using const_ptr = std::shared_ptr<const fee_filter>;

    static constexpr
    size_t satoshi_fixed_size(uint32_t /*version*/) {
        return sizeof(minimum_fee_);
    }

    fee_filter() = default;
    constexpr
    fee_filter(uint64_t minimum) noexcept
        : minimum_fee_(minimum)
    {}

    [[nodiscard]]
    friend bool operator==(fee_filter const&, fee_filter const&) = default;

    [[nodiscard]]
    constexpr
    uint64_t minimum_fee() const {
        return minimum_fee_;
    }

    static
    expect<fee_filter> from_data(byte_reader& reader, uint32_t version) noexcept;

    [[nodiscard]]
    expect<void> to_data(byte_writer& writer, uint32_t version) const noexcept;

    [[nodiscard]]
    constexpr
    size_t serialized_size(uint32_t version) const {
        return satoshi_fixed_size(version);
    }

    static constexpr std::string_view command = "feefilter";
    static constexpr uint32_t version_minimum = version::level::bip133;
    static constexpr uint32_t version_maximum = version::level::bip133;

private:
    uint64_t minimum_fee_{0};
};

} // namespace kth::domain::message

#endif
