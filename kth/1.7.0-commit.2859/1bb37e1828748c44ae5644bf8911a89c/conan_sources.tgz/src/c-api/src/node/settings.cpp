// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#include <kth/capi/node/settings.h>
#include <kth/capi/conversions/config.hpp>

#include <algorithm>
#include <cstdlib>
#include <string>

#include <kth/capi/node.h>
#include <kth/capi/helpers.hpp>

#include <kth/domain/multi_crypto_support.hpp>

#if ! defined(__EMSCRIPTEN__)
#include <kth/node/p2p_node.hpp>
#endif

// ---------------------------------------------------------------------------
extern "C" {

kth_currency_t kth_node_settings_get_currency() {
    return static_cast<kth_currency_t>(int(kth::get_currency()));
}

#if ! defined(__EMSCRIPTEN__)
kth_network_t kth_node_settings_get_network(kth_node_t exec) {

    kth_p2p_t p2p_node = kth_node_get_p2p(exec);
    auto const& node = *static_cast<kth::node::p2p_node*>(p2p_node);

    auto const& sett = node.network_settings();
    return kth::network_to_c(sett.context);
}
#endif


} // extern "C"
