# Copyright (c) 2016-present Knuth Project developers.
# Distributed under the MIT software license, see the accompanying
# file COPYING or http://www.opensource.org/licenses/mit-license.php.

cmake_minimum_required(VERSION 3.20)

project(blockchain VERSION 0 LANGUAGES CXX C)

set_property(GLOBAL PROPERTY USE_FOLDERS ON)

set(CMAKE_CXX_STANDARD 23)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

option(ENABLE_SHARED "" OFF)
option(ENABLE_POSITION_INDEPENDENT_CODE "Enable POSITION_INDEPENDENT_CODE property" ON)
option(WITH_TOOLS "Compile with tools." OFF)
option(DB_READONLY_MODE "Readonly DB mode enabled." OFF)
option(JUST_KTH_SOURCES "Just Knuth source code to be linted." OFF)

option(GLOBAL_BUILD "" ON)
option(ENABLE_TSAN_TESTS "Build TSAN tests" ON)


if (DB_READONLY_MODE)
  message(STATUS "Knuth: Readonly DB mode enabled")
  add_definitions(-DKTH_DB_READONLY)
endif()

if (JUST_KTH_SOURCES)
  message(STATUS "Knuth: Just Knuth source code to be linted: enabled")
endif()

set(MARCH_ID "" CACHE STRING "Specify the Microarchitecture ID (x86_64|...).")
message( STATUS "Knuth: Compiling for Microarchitecture ID ${MARCH_ID}")

message( STATUS "Knuth: CONAN_CXX_FLAGS ${CONAN_CXX_FLAGS}")
message( STATUS "Knuth: CONAN_C_FLAGS ${CONAN_C_FLAGS}")

set(CURRENCY "BCH" CACHE STRING "Specify the Cryptocurrency (BCH|BTC|LTC).")

if (${CURRENCY} STREQUAL "BCH")
  add_definitions(-DKTH_CURRENCY_BCH)
elseif (${CURRENCY} STREQUAL "BTC")
  add_definitions(-DKTH_CURRENCY_BTC)
elseif (${CURRENCY} STREQUAL "LTC")
  add_definitions(-DKTH_CURRENCY_LTC)
else()
  message(FATAL_ERROR "Invalid Cryptocurrency: ${CURRENCY}")
endif()

message(STATUS "Knuth: Cryptocurrency: ${CURRENCY}")

include(${CMAKE_CURRENT_LIST_DIR}/../../cmake/KthParlayHash.cmake)

# Header index capacity (number of headers for static array allocation)
# Default: one-minute tempnet through 2030, with its 600-second history (aligned to 2^16)
if(NOT DEFINED KTH_HEADER_INDEX_CAPACITY)
  if(CURRENCY STREQUAL "BCH")
    set(KTH_HEADER_INDEX_CAPACITY 3211264)
  else()
    set(KTH_HEADER_INDEX_CAPACITY 1179648)
  endif()
endif()
message(STATUS "Knuth: Header index capacity: ${KTH_HEADER_INDEX_CAPACITY}")
add_definitions(-DKTH_HEADER_INDEX_CAPACITY=${KTH_HEADER_INDEX_CAPACITY})

# UTXO-Z reference storage mode (8-byte refs instead of full output data).
# The real default comes from Conan (conanfile.py: utxoz_reference=False); this
# option only applies to standalone builds. It MUST agree with the value used by
# the other modules — the write path (utxo_builder) and the storage layer
# (utxoz_database) branch on this same macro, so a mismatch makes them disagree
# on the stored value layout.
option(KTH_UTXOZ_REFERENCE_MODE "Use UTXO-Z reference storage mode" OFF)

# Embedded UTXO bloom filter — .incbin via assembly
option(KTH_EMBED_UTXO_BLOOM "Embed UTXO bloom filter in the executable for faster IBD" ON)
set(UTXO_BLOOM_DAT_PATH "${CMAKE_SOURCE_DIR}/data/utxo_bloom.dat")
set(KTH_HAS_EMBEDDED_BLOOM OFF)

# Emscripten / WebAssembly: the .S template uses ELF directives
# (.section .rodata,"a",@progbits) that wasm-ld doesn't understand.
# Force-off here; runtime can load the bloom file from a regular path.
if(CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
    set(KTH_EMBED_UTXO_BLOOM OFF)
endif()

if(NOT KTH_EMBED_UTXO_BLOOM)
    message(STATUS "Knuth: UTXO bloom filter embedding disabled by option")
elseif(EXISTS "${UTXO_BLOOM_DAT_PATH}")
    enable_language(ASM)
    file(SIZE "${UTXO_BLOOM_DAT_PATH}" _bloom_file_size)
    math(EXPR _bloom_file_size_mb "${_bloom_file_size} / 1048576")
    message(STATUS "Knuth: UTXO bloom filter found: ${UTXO_BLOOM_DAT_PATH} (${_bloom_file_size_mb} MB)")

    configure_file(
        ${CMAKE_CURRENT_SOURCE_DIR}/src/utxo_bloom_embed.S.in
        ${CMAKE_CURRENT_BINARY_DIR}/utxo_bloom_embed.S
        @ONLY
    )
    set(KTH_HAS_EMBEDDED_BLOOM ON)
else()
    message(WARNING "Knuth: UTXO bloom filter NOT found at ${UTXO_BLOOM_DAT_PATH} — IBD will run without bloom optimization (slower)")
endif()

if (NOT GLOBAL_BUILD)
  find_package(database REQUIRED)
endif()


if (WITH_CONSENSUS)
  if (NOT GLOBAL_BUILD)
    find_package(consensus REQUIRED)
  endif()
endif()


include(CheckCXXCompilerFlag)

set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} ${CMAKE_CURRENT_SOURCE_DIR}/ci_utils/cmake)
include(KnuthTools)


if (NOT MSVC)
  _add_c_compile_flag(-Wall _has_all_warning_flag)
else()
  _add_c_compile_flag(-W4 _has_all_warning_flag)
  add_definitions(-D_SCL_SECURE_NO_WARNINGS)
  add_definitions(-D_CRT_SECURE_NO_WARNINGS)
endif()

if (NOT MSVC)
  _add_c_compile_flag(-Wextra _has_extra_warning_flag)
endif()

_add_c_compile_flag(-Wpedantic _has_pedantic_warning_flag)
if (_has_pedantic_warning_flag)
  _add_c_compile_flag(-pedantic _has_pedantic_flag)
endif()


if(CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
    # set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -matomics -mbulk-memory")
    _add_cxx_compile_flag(-matomics _has_matomics_flag)
    _add_cxx_compile_flag(-mbulk-memory _has_mbulk_memory_flag)
endif()

_add_cxx_compile_flag(-Wno-missing-braces _has_no_missing_braces_warning_flag)
_add_cxx_compile_flag(-Wno-mismatched-tags _has_no_mismatched_tags_warning_flag)
_add_c_compile_flag(-Wno-deprecated-declarations _has_no_deprecated_declarations_warning_flag)
_add_link_flag(-fstack-protector _has_stack_protector_flag)
_add_link_flag(-fstack-protector-all _has_stack_protector_all_flag)
_add_cxx_compile_flag(-fvisibility-hidden _has_visibility_hidden_flag)
_add_cxx_compile_flag(-fvisibility-inlines-hidden _has_visibility_inlines_hidden_flag)

if (MSVC)
  add_definitions(-D_WIN32_WINNT=0x0600)
endif()

# Build
# ------------------------------------------------------------------------------

set(MODE STATIC)
if (ENABLE_SHARED)
  set(MODE SHARED)
endif()

set(kth_sources_just_legacy
  src/interface/block_chain.cpp
  # src/interface/block_chain_old_db.cpp
  src/pools/block_entry.cpp
  src/pools/block_organizer.cpp
  src/pools/block_pool.cpp
  src/pools/branch.cpp
  src/pools/header_organizer.cpp
  src/pools/transaction_organizer.cpp
  src/pools/mempool.cpp
  src/pools/mempool_admissions.cpp
  src/pools/mempool_limit.cpp
  src/pools/block_template.cpp
  src/pools/template_prevouts.cpp
  src/pools/capture_gate.cpp
  src/pools/mempool_transaction_summary.cpp
  src/populate/populate_base.cpp
  src/abla_pipeline.cpp
  src/populate/populate_chain_state.cpp
  src/populate/populate_transaction.cpp
  src/validate/batch_validate.cpp
  src/validate/validate_header.cpp
  src/validate/validate_input.cpp
  src/validate/validate_transaction.cpp
  src/settings.cpp
  src/finalization.cpp
  src/parking.cpp
  src/utxo_builder.cpp
        src/utxo_deletion_sweep.cpp
)

if(KTH_HAS_EMBEDDED_BLOOM)
    list(APPEND kth_sources_just_legacy ${CMAKE_CURRENT_BINARY_DIR}/utxo_bloom_embed.S)
endif()

if (NOT JUST_KTH_SOURCES)
  set(kth_sources
    ${kth_sources_just_legacy}
  )
endif()

set(kth_sources
  ${kth_sources}
  ${kth_sources_just_kth}
)

set(kth_headers
  include/kth/blockchain.hpp
  include/kth/blockchain/interface
  include/kth/blockchain/interface/block_chain.hpp
  include/kth/blockchain/define.hpp
  include/kth/blockchain/header_index.hpp
  include/kth/blockchain/abla_pipeline.hpp
  include/kth/blockchain/chain_progress.hpp
  include/kth/blockchain/tick_schedule.hpp
  include/kth/blockchain/populate/populate_transaction.hpp
  include/kth/blockchain/populate/populate_chain_state.hpp
  include/kth/blockchain/populate/populate_base.hpp
  include/kth/blockchain/validate/validate_header.hpp
  include/kth/blockchain/validate/validate_input.hpp
  include/kth/blockchain/validate/validate_transaction.hpp
  include/kth/blockchain/pools/block_entry.hpp
  include/kth/blockchain/pools/block_template.hpp
  include/kth/blockchain/pools/template_prevouts.hpp
  include/kth/blockchain/pools/capture_gate.hpp
  include/kth/blockchain/pools/mempool.hpp
  include/kth/blockchain/pools/mempool_config.hpp
  include/kth/blockchain/pools/mempool_hashers.hpp
  include/kth/blockchain/pools/mempool_admissions.hpp
  include/kth/blockchain/pools/mempool_limit.hpp
  include/kth/blockchain/pools/mempool_map.hpp
  include/kth/blockchain/pools/mempool_stats.hpp
  include/kth/blockchain/pools/mempool_transaction_summary.hpp
  include/kth/blockchain/pools/block_organizer.hpp
  include/kth/blockchain/pools/branch.hpp
  include/kth/blockchain/pools/block_pool.hpp
  include/kth/blockchain/pools/header_organizer.hpp
  include/kth/blockchain/pools/transaction_organizer.hpp
  include/kth/blockchain/finalization.hpp
  include/kth/blockchain/parking.hpp
  include/kth/blockchain/settings.hpp
)

add_library(${PROJECT_NAME} ${MODE} ${kth_sources} ${kth_headers})
add_library(${PROJECT_NAME}::${PROJECT_NAME} ALIAS ${PROJECT_NAME})
set_target_properties(${PROJECT_NAME} PROPERTIES LINKER_LANGUAGE CXX CXX_STANDARD 23 CXX_STANDARD_REQUIRED TRUE)

if(KTH_HAS_EMBEDDED_BLOOM)
    target_compile_definitions(${PROJECT_NAME} PRIVATE KTH_HAS_EMBEDDED_BLOOM)
    message(STATUS "Knuth: Bloom filter will be embedded in the executable")
endif()

if(KTH_UTXOZ_REFERENCE_MODE)
    target_compile_definitions(${PROJECT_NAME} PUBLIC KTH_UTXOZ_REFERENCE_MODE)
    message(STATUS "Knuth: UTXO-Z reference storage mode enabled")
endif()

if (ENABLE_POSITION_INDEPENDENT_CODE)
    set_property(TARGET ${PROJECT_NAME} PROPERTY POSITION_INDEPENDENT_CODE ON)
endif(ENABLE_POSITION_INDEPENDENT_CODE)

target_include_directories(${PROJECT_NAME} PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include>)

if (NOT ENABLE_SHARED)
  target_compile_definitions(${PROJECT_NAME} PUBLIC -DKB_STATIC)
endif()

# Note: Conan should propagate KC_STATIC from consensus component
# if (WITH_CONSENSUS)
#   target_compile_definitions(${PROJECT_NAME} PUBLIC -DKC_STATIC)
# endif(WITH_CONSENSUS)

target_link_libraries(${PROJECT_NAME} PUBLIC database::database)
if(KTH_MEMPOOL_BACKEND STREQUAL "parlay")
  target_link_libraries(${PROJECT_NAME} PUBLIC ParlayHash::parlay)
endif()

if (WITH_CONSENSUS)
  target_compile_definitions(${PROJECT_NAME} PUBLIC -DWITH_CONSENSUS)
  target_link_libraries(${PROJECT_NAME} PUBLIC consensus::consensus)
endif(WITH_CONSENSUS)

if (MINGW)
  target_link_libraries(${PROJECT_NAME} PUBLIC ws2_32 wsock32)
endif()

_group_sources(${PROJECT_NAME} "${CMAKE_CURRENT_LIST_DIR}")

# Tests
# ------------------------------------------------------------------------------
if (ENABLE_TEST)
    enable_testing()
    find_package(Catch2 3 REQUIRED)

    set(kth_blockchain_test_sources
        test/utxo_block_parse.cpp
        test/parse_block_batch.cpp
        test/header_abla_persistence.cpp
        test/header_index.cpp
        test/header_organizer.cpp
        test/header_organizer_failed.cpp
        test/block_entry.cpp
        test/block_pool.cpp
        test/branch.cpp
        test/validate_transaction.cpp
        test/mempool_block_connect.cpp
        test/capture_gate.cpp
        test/mempool_lease_bench.cpp
        test/mempool_test.cpp
        test/mempool_admissions.cpp
        test/mempool_persistence_test.cpp
        test/block_template_test.cpp
        test/utxoz_roundtrip.cpp
        test/utxo_gate.cpp
          test/utxo_gate_bench.cpp
          test/utxoz_contract.cpp
        test/undo_cursor_restart.cpp
        test/result_code_translation.cpp
        test/utxo_gate_poison.cpp
        test/verify_script_context.cpp
        test/batch_sigchecks.cpp
        test/batch_sigchecks_activation.cpp
        test/batch_activation_boundary.cpp
        test/batch_structure.cpp
        test/batch_rejection_attribution.cpp
        test/batch_contextual_consensus.cpp
        test/local_block_submission.cpp
        test/faster_blocks_batch.cpp
        test/faster_blocks_abla.cpp
        test/abla_candidate_restore.cpp
        test/finalization.cpp
        test/mainnet_checkpoints.cpp
        test/parking.cpp
        test/block_undo.cpp
        test/reorg_undo_roundtrip.cpp
        test/undo_scan.cpp
        test/block_store_read_within.cpp
        test/utxo_transition_record.cpp
        test/undo_barriers.cpp
        test/bip30_duplicate_coinbase.cpp
        test/connected_tip.cpp
  test/transition_lifecycle.cpp
        test/reorg_e2e.cpp
    )

    # Disabled until ported to v1.0 APIs:
    #   - block_chain.cpp / utxo.cpp: use `kd::entity_from_data` (renamed/moved),
    #     `block_chain::get_utxo` (signature changed) and `block_chain::start()`
    #     (now an awaitable).
    # test/block_chain.cpp
    # test/utxo.cpp

    add_executable(kth_blockchain_test
        ${kth_blockchain_test_sources}
    )

    target_include_directories(kth_blockchain_test PUBLIC $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test>)
    target_link_libraries(kth_blockchain_test PUBLIC ${PROJECT_NAME})
    target_link_libraries(kth_blockchain_test PRIVATE Catch2::Catch2WithMain)

    _group_sources(kth_blockchain_test "${CMAKE_CURRENT_LIST_DIR}/test")

    include(CTest)
    kth_register_tests(kth_blockchain_test)
endif()

# VM-Limits tests
# Native VM tests always run; consensus comparison tests require WITH_CONSENSUS.
# ------------------------------------------------------------------------------
if (ENABLE_TEST)
    enable_testing()
    find_package(Catch2 3 REQUIRED)

    set(kth_blockchain_vmlimits_test_sources
        test/vmlimits_tests.cpp
        test/vmlimits_tests_generated.cpp
    )

    add_executable(kth_blockchain_vmlimits_test
        ${kth_blockchain_vmlimits_test_sources}
    )

    target_include_directories(kth_blockchain_vmlimits_test PUBLIC $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test>)
    target_link_libraries(kth_blockchain_vmlimits_test PUBLIC ${PROJECT_NAME})
    target_link_libraries(kth_blockchain_vmlimits_test PRIVATE Catch2::Catch2WithMain)

    if (WITH_CONSENSUS)
        target_compile_definitions(kth_blockchain_vmlimits_test PRIVATE -DWITH_CONSENSUS)
        target_link_libraries(kth_blockchain_vmlimits_test PUBLIC consensus::consensus)
    endif()

    _group_sources(kth_blockchain_vmlimits_test "${CMAKE_CURRENT_LIST_DIR}/test")

    include(CTest)
    include(Catch)
    kth_register_tests(kth_blockchain_vmlimits_test)
endif()

# Tools
# ------------------------------------------------------------------------------
if (WITH_TOOLS)
  add_executable(tools.initchain tools/initchain/initchain.cpp)

  target_link_libraries(tools.initchain ${PROJECT_NAME})
  _group_sources(tools.initchain "${CMAKE_CURRENT_LIST_DIR}/tools/initchain")
endif()

# Benchmarks
# ------------------------------------------------------------------------------
if (ENABLE_TEST AND NOT CMAKE_SYSTEM_NAME STREQUAL "Emscripten")
  find_package(nanobench REQUIRED)
  find_package(fmt REQUIRED)
  find_package(Boost REQUIRED)

  add_executable(kth_blockchain_bench_chain_tips bench/chain_tips/benchmarks.cpp)
  target_link_libraries(kth_blockchain_bench_chain_tips PRIVATE ${PROJECT_NAME})

  # ==========================================================================
  # 0. block_pool store: bimap + mutex vs concurrent_flat_map
  # ==========================================================================
  add_executable(kth_blockchain_bench_block_pool bench/block_pool/benchmarks.cpp)
  target_link_libraries(kth_blockchain_bench_block_pool PRIVATE nanobench::nanobench)
  target_link_libraries(kth_blockchain_bench_block_pool PRIVATE Boost::boost)

  # ==========================================================================
  # 1. Thread-safety tests with TSan (debug, -O1)
  # ==========================================================================
  # ASan and TSan can't share a process: the target's hardcoded
  # `-fsanitize=thread` would compose with a global `-fsanitize=address`
  # and gcc rejects the combination at the cc1plus level. Skip the TSan
  # target whenever the parent build is already instrumented with ASan.
  string(FIND "${CMAKE_CXX_FLAGS}" "-fsanitize=address" _kth_asan_in_cxxflags)
  if(ENABLE_TSAN_TESTS AND _kth_asan_in_cxxflags EQUAL -1)
    add_executable(kth_blockchain_tsan_tests test/block_index_bench/benchmarks.cpp)
    target_include_directories(kth_blockchain_tsan_tests PUBLIC
      $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test>
      $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test/block_index_bench>
    )
    target_link_libraries(kth_blockchain_tsan_tests PRIVATE nanobench::nanobench)
    target_link_libraries(kth_blockchain_tsan_tests PRIVATE fmt::fmt-header-only)
    target_link_libraries(kth_blockchain_tsan_tests PRIVATE Boost::boost)
    target_link_libraries(kth_blockchain_tsan_tests PRIVATE ${PROJECT_NAME})
    target_compile_options(kth_blockchain_tsan_tests PRIVATE -fsanitize=thread -g -O1)
    target_link_options(kth_blockchain_tsan_tests PRIVATE -fsanitize=thread)
    target_compile_definitions(kth_blockchain_tsan_tests PRIVATE TSAN_BUILD=1)
    _group_sources(kth_blockchain_tsan_tests "${CMAKE_CURRENT_LIST_DIR}/test")
  endif()

  # ==========================================================================
  # 2. Performance benchmarks (release, full optimization)
  # ==========================================================================
  add_executable(kth_blockchain_benchmarks test/block_index_bench/benchmarks.cpp)
  target_include_directories(kth_blockchain_benchmarks PUBLIC
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test>
    $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/test/block_index_bench>
  )
  target_link_libraries(kth_blockchain_benchmarks PRIVATE nanobench::nanobench)
  target_link_libraries(kth_blockchain_benchmarks PRIVATE fmt::fmt-header-only)
  target_link_libraries(kth_blockchain_benchmarks PRIVATE Boost::boost)
  target_link_libraries(kth_blockchain_benchmarks PRIVATE ${PROJECT_NAME})
  # Full optimization flags for accurate benchmarking
  target_compile_options(kth_blockchain_benchmarks PRIVATE
    -O3
    -DNDEBUG
    -march=native           # Use all CPU features available
    -mtune=native           # Tune for current CPU
    -ffast-math             # Aggressive floating-point optimizations
    -funroll-loops          # Unroll loops
    -fomit-frame-pointer    # Free up a register
    -flto                   # Link-time optimization
  )
  # GCC's bare -flto serializes the LTRANS partitions. Let GCC choose its
  # worker count; other compilers retain their existing LTO option.
  target_link_options(kth_blockchain_benchmarks PRIVATE
    "$<IF:$<CXX_COMPILER_ID:GNU>,-flto=auto,-flto>")
  target_compile_definitions(kth_blockchain_benchmarks PRIVATE BENCHMARK_BUILD=1)
  _group_sources(kth_blockchain_benchmarks "${CMAKE_CURRENT_LIST_DIR}/test/block_index_bench")

  # ==========================================================================
  # 3. Minimal profiling executable (for Instruments/perf analysis)
  # Uses modular headers from block_index_bench/
  # ==========================================================================
  add_executable(kth_blockchain_bench_profile test/block_index_bench/profile.cpp)
  target_include_directories(kth_blockchain_bench_profile PRIVATE
    ${CMAKE_CURRENT_SOURCE_DIR}/test/block_index_bench
  )
  target_link_libraries(kth_blockchain_bench_profile PRIVATE fmt::fmt-header-only)
  target_link_libraries(kth_blockchain_bench_profile PRIVATE Boost::boost)
  # Optimized but with debug symbols for profiling
  target_compile_options(kth_blockchain_bench_profile PRIVATE
    -O3
    -DNDEBUG
    -g                        # Debug symbols for profiler
    -fno-omit-frame-pointer   # Keep frame pointers for stack traces
    -march=native
    -mtune=native
  )
  _group_sources(kth_blockchain_bench_profile "${CMAKE_CURRENT_LIST_DIR}/test/block_index_bench")
endif()

# Install
# ------------------------------------------------------------------------------

include(GNUInstallDirs)
install(TARGETS ${PROJECT_NAME}
    EXPORT ${PROJECT_NAME}-targets
    LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
    ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
    RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
    INCLUDES DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
)
install(DIRECTORY include/ DESTINATION ${CMAKE_INSTALL_INCLUDEDIR}
        PATTERN "detail" EXCLUDE)

# Generate and install a CMake package configuration file
install(EXPORT ${PROJECT_NAME}-targets
    FILE ${PROJECT_NAME}-config.cmake
    NAMESPACE ${PROJECT_NAME}::
    DESTINATION ${CMAKE_INSTALL_LIBDIR}/cmake/${PROJECT_NAME}
)
