// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef KTH_DOMAIN_MESSAGE_ALERT_FORMATTED_PAYLOAD_HPP
#define KTH_DOMAIN_MESSAGE_ALERT_FORMATTED_PAYLOAD_HPP

#include <istream>
#include <string>

#include <kth/domain/define.hpp>
#include <kth/infrastructure/math/elliptic_curve.hpp>
#include <kth/infrastructure/utility/byte_reader.hpp>
#include <kth/infrastructure/utility/data.hpp>
#include <kth/infrastructure/utility/byte_writer.hpp>
#include <kth/domain/concepts.hpp>

namespace kth::domain::message {

struct KD_API alert_payload {
    alert_payload() = default;
    alert_payload(uint32_t version, uint64_t relay_until, uint64_t expiration, uint32_t id, uint32_t cancel, std::vector<uint32_t> const& set_cancel, uint32_t min_version, uint32_t max_version, std::vector<std::string> const& set_sub_version, uint32_t priority, std::string const& comment, std::string const& status_bar, std::string const& reserved);
    alert_payload(uint32_t version, uint64_t relay_until, uint64_t expiration, uint32_t id, uint32_t cancel, std::vector<uint32_t>&& set_cancel, uint32_t min_version, uint32_t max_version, std::vector<std::string>&& set_sub_version, uint32_t priority, std::string&& comment, std::string&& status_bar, std::string&& reserved);

    [[nodiscard]]
    friend bool operator==(alert_payload const&, alert_payload const&) = default;

    [[nodiscard]]
    uint32_t version() const;

    void set_version(uint32_t value);

    [[nodiscard]]
    uint64_t relay_until() const;

    void set_relay_until(uint64_t value);

    [[nodiscard]]
    uint64_t expiration() const;

    void set_expiration(uint64_t value);

    [[nodiscard]]
    uint32_t id() const;

    void set_id(uint32_t value);

    [[nodiscard]]
    uint32_t cancel() const;

    void set_cancel(uint32_t value);

    std::vector<uint32_t>& set_cancel();

    [[nodiscard]]
    std::vector<uint32_t> const& set_cancel() const;

    void set_set_cancel(std::vector<uint32_t> const& value);
    void set_set_cancel(std::vector<uint32_t>&& value);

    [[nodiscard]]
    uint32_t min_version() const;

    void set_min_version(uint32_t value);

    [[nodiscard]]
    uint32_t max_version() const;

    void set_max_version(uint32_t value);

    std::vector<std::string>& set_sub_version();

    [[nodiscard]]
    std::vector<std::string> const& set_sub_version() const;

    void set_set_sub_version(std::vector<std::string> const& value);
    void set_set_sub_version(std::vector<std::string>&& value);

    [[nodiscard]]
    uint32_t priority() const;

    void set_priority(uint32_t value);

    std::string& comment();

    [[nodiscard]]
    std::string const& comment() const;

    void set_comment(std::string const& value);
    void set_comment(std::string&& value);

    std::string& status_bar();

    [[nodiscard]]
    std::string const& status_bar() const;

    void set_status_bar(std::string const& value);
    void set_status_bar(std::string&& value);

    std::string& reserved();

    [[nodiscard]]
    std::string const& reserved() const;

    void set_reserved(std::string const& value);
    void set_reserved(std::string&& value);

    static
    expect<alert_payload> from_data(byte_reader& reader, uint32_t /*version*/) {
        auto version = reader.read_little_endian<uint32_t>();
        if (!version) return std::unexpected(version.error());

        auto relay_until = reader.read_little_endian<uint64_t>();
        if (!relay_until) return std::unexpected(relay_until.error());

        auto expiration = reader.read_little_endian<uint64_t>();
        if (!expiration) return std::unexpected(expiration.error());

        auto id = reader.read_little_endian<uint32_t>();
        if (!id) return std::unexpected(id.error());

        auto cancel = reader.read_little_endian<uint32_t>();
        if (!cancel) return std::unexpected(cancel.error());

        auto set_cancel_size = reader.read_size_little_endian();
        if (!set_cancel_size) return std::unexpected(set_cancel_size.error());

        std::vector<uint32_t> set_cancel;
        set_cancel.reserve(*set_cancel_size);
        for (size_t i = 0; i < *set_cancel_size; ++i) {
            auto value = reader.read_little_endian<uint32_t>();
            if (!value) return std::unexpected(value.error());
            set_cancel.push_back(*value);
        }

        auto const min_version = reader.read_little_endian<uint32_t>();
        if (!min_version) return std::unexpected(min_version.error());

        auto const max_version = reader.read_little_endian<uint32_t>();
        if (!max_version) return std::unexpected(max_version.error());

        auto const set_sub_version_size = reader.read_size_little_endian();
        if (!set_sub_version_size) return std::unexpected(set_sub_version_size.error());

        std::vector<std::string> set_sub_version;
        set_sub_version.reserve(*set_sub_version_size);
        for (size_t i = 0; i < *set_sub_version_size; ++i) {
            auto value = reader.read_string();
            if (!value) return std::unexpected(value.error());
            set_sub_version.emplace_back(std::move(*value));
        }

        auto const priority = reader.read_little_endian<uint32_t>();
        if (!priority) return std::unexpected(priority.error());

        auto const comment = reader.read_string();
        if (!comment) return std::unexpected(comment.error());

        auto const status_bar = reader.read_string();
        if (!status_bar) return std::unexpected(status_bar.error());

        auto const reserved = reader.read_string();
        if (!reserved) return std::unexpected(reserved.error());

        return alert_payload{
            *version,
            *relay_until,
            *expiration,
            *id,
            *cancel,
            std::move(set_cancel),
            *min_version,
            *max_version,
            std::move(set_sub_version),
            *priority,
            std::move(*comment),
            std::move(*status_bar),
            std::move(*reserved)
        };
    }

    [[nodiscard]]
    expect<void> to_data(byte_writer& writer, uint32_t version) const noexcept;

    [[nodiscard]]
    size_t serialized_size(uint32_t version) const;


    static
    ec_uncompressed const satoshi_public_key;

private:
    uint32_t version_{0};
    uint64_t relay_until_{0};
    uint64_t expiration_{0};
    uint32_t id_{0};
    uint32_t cancel_{0};
    std::vector<uint32_t> set_cancel_;
    uint32_t min_version_{0};
    uint32_t max_version_{0};
    std::vector<std::string> set_sub_version_;
    uint32_t priority_{0};
    std::string comment_;
    std::string status_bar_;
    std::string reserved_;
};

} // namespace kth::domain::message

#endif
