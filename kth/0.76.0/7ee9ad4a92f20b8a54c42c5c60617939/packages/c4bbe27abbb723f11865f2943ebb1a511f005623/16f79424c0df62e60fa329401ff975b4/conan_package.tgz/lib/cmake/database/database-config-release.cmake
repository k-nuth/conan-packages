#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "database::database" for configuration "Release"
set_property(TARGET database::database APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(database::database PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libdatabase.a"
  )

list(APPEND _cmake_import_check_targets database::database )
list(APPEND _cmake_import_check_files_for_database::database "${_IMPORT_PREFIX}/lib/libdatabase.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
