#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "infrastructure::infrastructure" for configuration "Release"
set_property(TARGET infrastructure::infrastructure APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(infrastructure::infrastructure PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libinfrastructure.a"
  )

list(APPEND _cmake_import_check_targets infrastructure::infrastructure )
list(APPEND _cmake_import_check_files_for_infrastructure::infrastructure "${_IMPORT_PREFIX}/lib/libinfrastructure.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
