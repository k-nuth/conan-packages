#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "c-api::c-api" for configuration "Release"
set_property(TARGET c-api::c-api APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(c-api::c-api PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libc-api.a"
  )

list(APPEND _cmake_import_check_targets c-api::c-api )
list(APPEND _cmake_import_check_files_for_c-api::c-api "${_IMPORT_PREFIX}/lib/libc-api.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
