#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "blockchain::blockchain" for configuration "Release"
set_property(TARGET blockchain::blockchain APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(blockchain::blockchain PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libblockchain.a"
  )

list(APPEND _cmake_import_check_targets blockchain::blockchain )
list(APPEND _cmake_import_check_files_for_blockchain::blockchain "${_IMPORT_PREFIX}/lib/libblockchain.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
