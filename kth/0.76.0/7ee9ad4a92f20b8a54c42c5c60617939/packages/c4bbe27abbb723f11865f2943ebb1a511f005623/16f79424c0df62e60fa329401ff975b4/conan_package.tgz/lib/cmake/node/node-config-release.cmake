#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "node::node" for configuration "Release"
set_property(TARGET node::node APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(node::node PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libnode.a"
  )

list(APPEND _cmake_import_check_targets node::node )
list(APPEND _cmake_import_check_files_for_node::node "${_IMPORT_PREFIX}/lib/libnode.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
