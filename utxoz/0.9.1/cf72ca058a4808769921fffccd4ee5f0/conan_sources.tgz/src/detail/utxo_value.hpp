// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

/**
 * @file utxo_value.hpp
 * @brief UTXO value storage types for memory-mapped containers
 * @internal
 */

#pragma once

#include <algorithm>
#include <array>
#include <ranges>
#include <span>
#include <type_traits>

#include <boost/interprocess/allocators/allocator.hpp>
#include <boost/interprocess/managed_mapped_file.hpp>
#include <boost/unordered/unordered_flat_map.hpp>

#include <utxoz/types.hpp>

namespace utxoz::detail {

namespace bip = boost::interprocess;

// =============================================================================
// Type aliases
// =============================================================================

using segment_manager_t = bip::managed_mapped_file::segment_manager;

struct outpoint_hash {
    size_t operator()(raw_outpoint const& k) const noexcept {
        return hash_outpoint(k);
    }
};

using outpoint_equal = std::equal_to<raw_outpoint>;

// =============================================================================
// UTXO value storage
// =============================================================================

template<size_t Size>
using size_type = std::conditional_t<Size <= 255, uint8_t, uint16_t>;

template<size_t Size>
struct utxo_value {
    uint32_t block_height;
    size_type<Size> actual_size;
    std::array<uint8_t, Size - sizeof(uint32_t) - sizeof(size_type<Size>)> data;

    void set_data(std::span<uint8_t const> output_data) {
        actual_size = static_cast<size_type<Size>>(
            std::min(output_data.size(), data.size())
        );
        std::ranges::copy(output_data.first(actual_size), data.begin());
    }

    std::span<uint8_t const> get_data() const {
        return {data.data(), actual_size};
    }
};

/// The name the entry map is stored under inside a segment.
///
/// One spelling, because every reader has to use the one the writer used, and a
/// literal repeated at fifteen call sites is one typo away from a file whose
/// map nothing can find — which reads as an empty version rather than as an
/// error.
inline constexpr char const* map_object_name = "db_map";

template<size_t Size>
using utxo_map = boost::unordered_flat_map<
    raw_outpoint,
    utxo_value<Size>,
    outpoint_hash,
    outpoint_equal,
    bip::allocator<std::pair<raw_outpoint const, utxo_value<Size>>, segment_manager_t>
>;

// =============================================================================
// Reference mode value storage
// =============================================================================

struct reference_value {
    uint32_t height;
    uint32_t file_number;
    uint32_t offset;
};

using reference_map_t = boost::unordered_flat_map<
    raw_outpoint,
    reference_value,
    outpoint_hash,
    outpoint_equal,
    bip::allocator<std::pair<raw_outpoint const, reference_value>, segment_manager_t>
>;

} // namespace utxoz::detail
