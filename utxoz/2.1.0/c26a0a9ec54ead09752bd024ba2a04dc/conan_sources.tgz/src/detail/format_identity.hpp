// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

/**
 * @file format_identity.hpp
 * @brief What this build can read, expressed as four numbers it compares.
 * @internal
 *
 * The store keeps its maps inside memory-mapped files, so the internal layout of
 * `boost::unordered_flat_map` *is* the file format. Boost promises nothing about
 * that layout, and Boost.Interprocess resolves a named object by name alone —
 * `priv_generic_find<T>` checks nothing about the type in a release build and
 * hands back a `static_cast<T*>`. A build whose idea of the layout differs from
 * the one that wrote the file would therefore reinterpret it rather than refuse
 * it, and every symptom of that would appear somewhere else.
 *
 * These four identities are what stands in the way. They are separate because
 * they fail for different reasons and send an operator to different places:
 *
 * - geometry_id      — our own sizing decisions changed.
 * - map_layout_epoch — the Boost implementation we certified changed.
 * - hash_epoch       — the effective hash changed, so every key moved.
 * - platform_abi_id  — this file was written on an incompatible platform.
 *
 * None of them is derived from a type name, a mangled symbol or `std::hash`:
 * all three vary between compilers and versions without meaning anything about
 * compatibility. They are constants, bumped deliberately, each pinned by an
 * assertion that fails to compile if the thing it stands for moves underneath
 * it.
 *
 * `BOOST_VERSION` is deliberately absent from all of this. Several Boost
 * versions can share one `map_layout_epoch`, and treating a version bump as an
 * incompatibility would invalidate every database for no reason. It is recorded
 * in the config for diagnosis and never compared.
 */

#pragma once

#include <array>
#include <bit>
#include <cstdint>
#include <initializer_list>

#include <boost/container_hash/hash.hpp>

#include <utxoz/types.hpp>

#include "capacity_policy.hpp"
#include "utxo_value.hpp"

namespace utxoz::detail {

/**
 * @brief The platform facts that decide whether these bytes mean the same thing.
 *
 * Composed from properties that are measurable and stable, not from a compiler
 * name or a mangled type. Each occupies one byte, which every one of them fits
 * in comfortably, and the packing is fixed so the number is reproducible.
 *
 * Compiler and standard library are deliberately **not** here. Nothing shows
 * they change what gets written, and folding them in would invalidate every
 * database on a toolchain upgrade for no demonstrated reason. If a compiler ever
 * does change the layout, it changes one of the sizes below or it is caught by
 * the compatibility fixtures — which is exactly the job the fixtures exist for.
 */
inline constexpr uint32_t data_abi_id = []() constexpr {
    uint32_t const endian = std::endian::native == std::endian::little ? 1u : 2u;
    return (endian << 24)
         | (uint32_t(sizeof(size_t)) << 16)
         | (uint32_t(sizeof(void*)) << 8)
         | uint32_t(sizeof(offset_ptr<void>));
}();

static_assert(sizeof(size_t) <= 255 && sizeof(void*) <= 255
              && sizeof(offset_ptr<void>) <= 255,
              "data_abi_id packs each of these into one byte");

/// Which platform and C runtime this is.
///
/// The sizes in `data_abi_id` are not enough on their own: two targets can agree
/// on all of them and still lay a stored value out differently, and only the
/// layout matters to a file.
///
/// There is deliberately no catch-all. A shared fallback would make two
/// unrecognised platforms compatible *with each other*, which is the same defect
/// as before wearing a different number: they would agree on a tag neither of
/// them earned, and on every other ingredient, and the barrier would let one open
/// the other's files. Grouping "Linux with some libc that is not glibc" had the
/// same problem one level down, since musl and bionic are exactly what the tag
/// exists to tell apart.
///
/// So an unrecognised target does not compile. A build that knows what it is can
/// say so with `UTXOZ_PLATFORM_TAG`, and is then responsible for the claim that
/// the number is unique to that platform and runtime — which is why explicit tags
/// live above every value this header will ever assign itself.
inline constexpr uint32_t explicit_platform_tag_floor = 1000;

#if defined(UTXOZ_PLATFORM_TAG)
inline constexpr uint32_t platform_tag = UTXOZ_PLATFORM_TAG;
static_assert(platform_tag >= explicit_platform_tag_floor,
              "UTXOZ_PLATFORM_TAG must be at least 1000: below that is reserved for the "
              "platforms this header recognises, and a collision with one of them would "
              "certify a compatibility nobody established");
#elif defined(_WIN32)
inline constexpr uint32_t platform_tag = 1;
#elif defined(__EMSCRIPTEN__)
inline constexpr uint32_t platform_tag = 2;
#elif defined(__APPLE__)
inline constexpr uint32_t platform_tag = 3;
#elif defined(__ANDROID__)
inline constexpr uint32_t platform_tag = 5;   // bionic, checked before glibc: it defines neither
#elif defined(__linux__) && defined(__GLIBC__)
inline constexpr uint32_t platform_tag = 4;
#elif defined(__FreeBSD__)
inline constexpr uint32_t platform_tag = 6;
#else
#error "utxoz: this platform and C runtime are not recognised, so nothing is known about \
the layout of the mutex a segment persists. Define UTXOZ_PLATFORM_TAG to a value of 1000 or \
more that is unique to this platform and runtime, or add it to format_identity.hpp. A shared \
fallback would make two unrecognised targets compatible with each other, which is the defect \
this identity exists to prevent."
#endif

/// Zero is not a tag. It cannot be reached through the branches above — an
/// unrecognised target does not compile at all — but an explicit tag arrives from
/// outside this file, and "unset" is the value a mistake there most often takes.
static_assert(platform_tag != 0,
              "platform_tag must identify something; zero is what an unset build "
              "definition looks like");


/// FNV-1a over a list of 32-bit ingredients. A fold rather than a packing,
/// because what has to go into the identity below does not fit a byte each.
inline constexpr uint32_t mix_identity(std::initializer_list<uint32_t> parts) {
    uint32_t h = 0x811c9dc5u;
    for (uint32_t const part : parts) {
        for (int byte = 0; byte < 4; ++byte) {
            h ^= (part >> (byte * 8)) & 0xFFu;
            h *= 0x01000193u;
        }
    }
    return h;
}

/// Bumped if the ingredient list changes, so an old id and a new one cannot
/// collide into looking compatible.
inline constexpr uint32_t platform_abi_encoding = 2;

/**
 * @brief The whole persisted ABI: the data, and the segment's own header.
 *
 * A version file begins with a header this library defines (mapped_segment.hpp):
 * fixed-width integers, no lock, nothing a platform chooses. Its format number
 * and its measured shape go in, so that a build with a different header refuses
 * the file instead of reading one header as another.
 *
 * Earlier formats kept Boost.Interprocess's segment manager and its mutex in the
 * file, and the mutex was a different type on every platform. Linux x86_64 and
 * macOS arm64 agreed on every number in `data_abi_id`, a file from one mapped
 * cleanly on the other, and the first lookup never returned: a lock taken on
 * another platform's bytes. The platform and C runtime stay in the identity for
 * what remains platform-shaped, which is the layout of the stored values.
 *
 * Parameterised so there is exactly one ingredient list. A test asking what a
 * differently-built target's identity would be, and the constant this build uses,
 * are then the same arithmetic rather than two copies of it that can drift.
 */
inline constexpr uint32_t compute_platform_abi_id(uint32_t header_format, uint32_t tag) {
    return mix_identity({
        platform_abi_encoding,
        data_abi_id,
        header_format,
        uint32_t(sizeof(segment_header)),
        uint32_t(alignof(segment_header)),
        tag,
    });
}

inline constexpr uint32_t platform_abi_id =
    compute_platform_abi_id(segment_header::current_format, platform_tag);

static_assert(compute_platform_abi_id(1, platform_tag) != compute_platform_abi_id(2, platform_tag),
              "the header format has to change the identity, or the barrier cannot tell "
              "a file with one header from a file with another");
static_assert(compute_platform_abi_id(segment_header::current_format, 1)
                  != compute_platform_abi_id(segment_header::current_format, 2),
              "so does the platform: two targets can agree on every size here and still "
              "disagree about what the stored values look like");

/**
 * @brief The container sizing this build writes.
 *
 * Bumped whenever `container_sizes` changes, whenever a container is added or
 * removed, or whenever a value moves from one container to another. The
 * assertion below is what makes forgetting impossible: change the geometry
 * without changing this number and the build stops.
 */
/// What `geometry_id` identifies, from 3 onwards: the **whole storage geometry**,
/// not only the size classes. Both `container_sizes` and `production_capacity`
/// move it — the assertions below make either one impossible to change quietly. That is the classes themselves, which payload goes
/// to which of them, the capacity a new segment's map is built with, and the size
/// of the segment. They are one decision — a capacity without the file size it
/// needs is a rehash waiting for the entries — so they are identified together.
///
/// 1: classes {48, 94, 128, 256, 10240}.
/// 2: the second class became 96. The object already occupied 96 — 94 rounds up —
///    so the two bytes it gained were padding nobody could use. Naming the class
///    96 turned them into payload at no cost, but it moved where a value lives: a
///    90- or 91-byte output went to container 2 and now fits in container 1.
/// 3: the capacity policy. Container 0 holds 15 728 639 buckets in a segment of
///    1340 MiB, chosen by measurement rather than by a bisection that read
///    `bad_alloc` as an answer, and sized so that a growth cannot fit.
///
/// There is no migrator, and there will not be one: a database's container
/// assignment and its capacity are decided when it is written.
///
/// 4: 1.0. The 48-byte class split into eight shards, each a container of its own
///    with one eighth of the class's capacity (1 966 079 buckets) in one eighth
///    of its file (167.5 MiB). The other classes are those of geometry 3,
///    unchanged. Fixed: eight is the production shard count, not an option.
///
/// Everything before 4 is refused with `geometry_mismatch` and has to be rebuilt.
/// Geometry 3 never shipped in a release; it is what a master build between
/// 0.10.0 and 1.0 wrote. A database from 0.10.0 or earlier carries no identity
/// at all and is refused before this check, as `migration_required`.
///
/// Sharding is part of the geometry, not a tuning knob laid over it. Splitting a
/// class into N shards divides that class's per-container capacity by N and
/// changes how many containers exist, so a store written at one shard count
/// cannot be read at another: the same key resolves to a different container.
///
/// Builds with UTXOZ_EXPERIMENTAL_SHARD_COUNT write ids in the 0x80000000
/// namespace, reserved for geometries that are being measured and are not
/// promised to anybody - one per shard count, and none equal to a production id.
/// N=1 included: an experimental unsharded build does not write geometry 3, so it
/// cannot produce a database that looks like one from before 1.0.
inline constexpr uint32_t production_geometry_id = 4;

[[nodiscard]] inline constexpr uint32_t experimental_geometry_id_for_shards(uint32_t shards) noexcept {
    switch (shards) {
        case 1:  return 0x8000000F;
        case 2:  return 0x80000010;
        case 4:  return 0x80000011;
        case 16: return 0x80000013;
        case 32: return 0x80000014;
        default: return 0;   // 8 is production; anything else valid_shard_count() refused
    }
}

inline constexpr uint32_t geometry_id = experimental_build
    ? experimental_geometry_id_for_shards(shard_count)
    : production_geometry_id;

static_assert(geometry_id != 0,
              "every shard count this build accepts must name a geometry id; a count that "
              "reaches here without one would stamp 0 and let two incompatible layouts open "
              "each other");
static_assert(experimental_build == ((geometry_id & 0x80000000u) != 0),
              "a production build writes a production id and an experimental build an "
              "experimental one; never the other way round");
static_assert(experimental_build || shard_count == production_shard_count,
              "a production build has the production shard count");

/// Geometry 4, written down whole: eight shards of the 48-byte class, then the
/// other four classes. Compared entry for entry with what the build derives, so
/// any change to the classes, the capacities, the file sizes or the shard count
/// stops the build until it gets a new id.
inline constexpr std::array<capacity_entry, 12> geometry_4_slot_capacity = {{
    {1340_mib / 8, 1966079, 1966079, true}, {1340_mib / 8, 1966079, 1966079, true},
    {1340_mib / 8, 1966079, 1966079, true}, {1340_mib / 8, 1966079, 1966079, true},
    {1340_mib / 8, 1966079, 1966079, true}, {1340_mib / 8, 1966079, 1966079, true},
    {1340_mib / 8, 1966079, 1966079, true}, {1340_mib / 8, 1966079, 1966079, true},
    { 500_mib,  3932159,  3932159, false},
    {   1_gib,  3932159,  3932159, false},
    {  50_mib,   122879,   122879, false},
    {  10_mib,      959,      959, false},
}};

[[nodiscard]] inline constexpr bool production_slots_are_geometry_4() noexcept {
    if constexpr (shard_count != production_shard_count) {
        return false;
    } else {
        for (size_t i = 0; i != geometry_4_slot_capacity.size(); ++i) {
            if ( ! (production_slot_capacity[i] == geometry_4_slot_capacity[i])) return false;
        }
        return production_capacity == geometry_3_capacity
            && production_reference == geometry_3_reference;
    }
}

static_assert(experimental_build || production_slots_are_geometry_4(),
              "geometry 4 is eight shards of geometry 3's 48-byte class and geometry 3's "
              "other classes, entry for entry. A segment size, a capacity, a bucket count or "
              "a shard count that moves is a different geometry and needs a new id");

static_assert(container_sizes == std::array<size_t, 5>{48, 96, 128, 256, 10240},
              "the container geometry changed; bump geometry_id and update this assertion, "
              "because existing databases were written under the old one");

/**
 * @brief The `boost::unordered_flat_map` layout this build is certified against.
 *
 * Epoch 1 is the implementation shipped in Boost 1.91: `group15<plain_integral>`
 * groups of fifteen, `plain_size_control`, `pow2_size_policy`, elements inline in
 * one array reached through `offset_ptr`.
 *
 * A new Boost release does **not** bump this on its own. It is bumped when the
 * compatibility fixtures show that what the new implementation writes or reads
 * is not what epoch 1 wrote — which is why the fixtures exist, and why this
 * number is ours rather than Boost's.
 *
 * The sizes below are not the certification; the fixtures are. They are a cheap
 * tripwire for the most obvious kind of change, and they cost nothing.
 */
inline constexpr uint32_t map_layout_epoch = 1;

/// The ABI epoch 1's sizes were measured on: little-endian, 64-bit `size_t`,
/// 64-bit pointers, 64-bit `offset_ptr`. Spelled out rather than derived so the
/// tripwire below cannot silently start describing a different platform.
///
/// A *data* ABI, deliberately: what a key hashes to and how wide a stored field
/// is do not depend on which mutex the segment carries, so the vectors pinned
/// against this stay pinned on every platform that shares these four numbers.
inline constexpr uint32_t lp64_le_abi = 0x01080808u;

/// The other ABI this project builds for: wasm32, little-endian, 32-bit
/// `size_t`, pointers and `offset_ptr`. Named because the hash vectors are
/// pinned per ABI and a number in a test is not a reason.
inline constexpr uint32_t wasm32_le_abi = 0x01040404u;

static_assert(data_abi_id != lp64_le_abi
                  || (sizeof(utxo_map<48>) == 56 && alignof(utxo_map<48>) == 8),
              "on the ABI epoch 1 was measured on, the map object changed size or "
              "alignment; check the compatibility fixtures before deciding whether to "
              "bump map_layout_epoch");

/**
 * @brief The effective hash whose output is baked into every stored file.
 *
 * Epoch 1 is `mulx_mix(hash_outpoint(key))`.
 *
 * The mixing is not ours and is not optional: Boost 1.91 picks it in
 * `table_core` with
 *
 *     using mix_policy = conditional_t<hash_is_avalanching<Hash>::value,
 *                                      no_mix, mulx_mix>;
 *
 * and `outpoint_hash` does not declare the trait, so `mulx_mix` applies. Marking
 * it avalanching would look like an optimisation — the hash does come from a
 * SHA-256, so it *is* well distributed — and would relocate every key in every
 * existing database while leaving `sizeof`, `alignof`, the bucket ladder and the
 * load factor all exactly as they were. Nothing structural would notice.
 *
 * So the trait is pinned here. Changing it means bumping `hash_epoch`, and every
 * database written under the old one has to be rebuilt.
 */
inline constexpr uint32_t hash_epoch = 1;

static_assert( ! boost::hash_is_avalanching<outpoint_hash>::value,
              "outpoint_hash must not declare is_avalanching: Boost would stop applying "
              "mulx_mix and every key in every existing database would move. If this is "
              "deliberate, bump hash_epoch and require a rebuild");

/// A database's identity: sixteen random bytes, made once when it is created and
/// written into its config and into every segment it owns. Two databases never
/// share one, so a version file that wandered in from somewhere else is caught
/// before anything reads it.
using database_id_t = std::array<uint8_t, 16>;

/// The container a segment belongs to. Full mode uses the container index;
/// reference mode has one container and uses this instead. Fixed width, because
/// it is written to disk — `reference_sentinel_index` is `SIZE_MAX`, which is
/// not the same number on every platform.
inline constexpr uint32_t reference_container_kind = 0xFFFFFFFFu;

} // namespace utxoz::detail
