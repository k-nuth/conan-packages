// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

/**
 * @file types.hpp
 * @brief Core type definitions for the UTXO database
 */

#pragma once

#include <array>
#include <cstdint>
#include <cstring>
#include <expected>
#include <span>
#include <vector>
#include <optional>
#include <chrono>

#include <utxoz/literals.hpp>

namespace utxoz {

using namespace literals;

/**
 * @brief Size of outpoint in bytes (32 bytes txid + 4 bytes output index)
 */
inline constexpr size_t outpoint_size = 36;

/**
 * @brief Raw outpoint - 36-byte array representing a Bitcoin outpoint
 *
 * Layout: [txid: 32 bytes][output_index: 4 bytes]
 *
 * Typical encoding:
 * - txid: Internal byte order (as stored in Bitcoin's internal representation)
 * - output_index: Little-endian uint32_t
 *
 * However, the database is agnostic to the specific encoding used.
 * Users may encode the outpoint in any format, as long as the same
 * encoding is used consistently across all operations.
 *
 * @see make_outpoint() for constructing outpoints
 * @see get_txid(), get_output_index() for extracting components
 */
using raw_outpoint = std::array<uint8_t, outpoint_size>;

/**
 * @brief Fast hash for raw_outpoint.
 *
 * Since the first 32 bytes are a SHA256 txid (uniformly distributed),
 * we just grab the first 8 bytes as size_t and mix in the 4-byte output index.
 * This is O(1) instead of the O(36) byte-by-byte hash_combine approach.
 */
inline size_t hash_outpoint(raw_outpoint const& k) noexcept {
    size_t seed;
    std::memcpy(&seed, k.data(), sizeof(seed));
    uint32_t idx;
    std::memcpy(&idx, k.data() + 32, sizeof(idx));
    seed ^= size_t(idx) * 0x9e3779b97f4a7c15ULL;
    return seed;
}

/**
 * @brief Span of bytes representing UTXO output data
 *
 * Typically contains the serialized transaction output:
 * - Amount in satoshis (8 bytes, little-endian)
 * - scriptPubKey (variable length)
 *
 * The database stores this data as-is without interpreting its contents.
 */
using output_data_span = std::span<uint8_t const>;

/**
 * @brief Container sizes for different UTXO value sizes
 */
inline constexpr std::array<size_t, 5> container_sizes = {48, 96, 128, 256, 10240};

/**
 * @brief Effective data capacity for a given container size
 *
 * Each utxo_value<Size> stores: block_height (4 bytes) + actual_size field + data.
 * The actual_size field is uint8_t for Size <= 255, uint16_t otherwise.
 */
inline constexpr size_t data_capacity(size_t container_size) {
    size_t size_field = container_size <= 255 ? 1 : 2;
    return container_size - sizeof(uint32_t) - size_field;
}

/**
 * @brief Pre-computed data capacities for each container
 */
inline constexpr auto container_capacities = [] {
    std::array<size_t, container_sizes.size()> caps{};
    for (size_t i = 0; i < container_sizes.size(); ++i) {
        caps[i] = data_capacity(container_sizes[i]);
    }
    return caps;
}();

/**
 * @brief File sizes for each container type (production)
 *
 * Container 0 is 1340 MiB because that is what its capacity was measured to need
 * plus five per cent, rounded up to a whole mebibyte — not because it is a round
 * number. The rest are what they have always been. `capacity_policy.hpp` holds
 * the capacity each of these was chosen for and asserts that the two lists agree,
 * so neither can move without the other.
 */
inline constexpr std::array<size_t, 5> file_sizes = {1340_mib, 500_mib, 1_gib, 50_mib, 10_mib};

/**
 * @brief File sizes for each container type (testing - much smaller)
 */
inline constexpr std::array<size_t, 5> test_file_sizes = {10_mib, 10_mib, 10_mib, 10_mib, 10_mib};

/**
 * @brief Number of container types
 */
inline constexpr size_t container_count = container_sizes.size();

/**
 * @brief How many shards the 48-byte class is split into.
 *
 * PART OF THE PERSISTED FORMAT, not a tuning knob: a key's shard decides which
 * file holds it, so changing this relocates every entry of that class and
 * requires a new geometry identity and a rebuilt database.
 *
 * **Eight, fixed, in every production build.** It is not configurable: a
 * consumer that compiled against another value would compute other slots than
 * the library it calls into, and a database written under one value cannot be
 * read under another. The value is a product decision for 1.0; the measurements
 * it was taken on, and what they do not show, are in doc/roadmap-1.0.md.
 *
 * Other shard counts exist only for tests and experiments, and only through the
 * build option UTXOZ_EXPERIMENTAL_SHARD_COUNT. Such a build is marked
 * experimental (`experimental_build`), writes an experimental geometry id that
 * no production build accepts, and is not installable or packageable. It is
 * never a silent alternative to eight.
 */
inline constexpr uint32_t production_shard_count = 8;

#if defined(UTXOZ_SHARD_COUNT)
#error "UTXOZ_SHARD_COUNT was removed in 1.0: production uses 8 shards, fixed. For a test or experiment with another count, build with UTXOZ_EXPERIMENTAL_SHARD_COUNT (never installable)."
#endif

#if defined(UTXOZ_EXPERIMENTAL_SHARD_COUNT)
static_assert(UTXOZ_EXPERIMENTAL_SHARD_COUNT != 8,
              "8 is the production shard count; an experimental build must use another one");
inline constexpr uint32_t shard_count = UTXOZ_EXPERIMENTAL_SHARD_COUNT;
inline constexpr bool experimental_build = true;
#else
inline constexpr uint32_t shard_count = production_shard_count;
inline constexpr bool experimental_build = false;
#endif

/**
 * @brief Storage mode selection
 *
 * - full: Stores complete UTXO output data (scriptPubKey + amount) across 5 size-tiered containers
 * - reference: Stores only a small fixed-size reference (e.g. block file position) in a single container
 */
enum class storage_mode : uint8_t { full = 0, reference = 1 };

/**
 * @brief Error codes for database operations
 */
enum class error_code : uint8_t {
    not_found,              ///< Key is not in the database
    /// The active versions do not hold this key, and nothing else was consulted.
    ///
    /// Not absence, and deliberately not spelled `not_found`: the key may be in
    /// any older version. find() searches the active versions only, so this is
    /// the whole of what it can say. Collect the request and hand it to
    /// resolve(), which is what reaches the older versions and what can return
    /// a proven absence.
    not_resolved,
    closed,                 ///< Operation on a closed or moved-from database
    storage_mode_mismatch,  ///< Existing database has a different storage mode
    config_file_corrupt,    ///< Config file is invalid, truncated, or has bad magic
    value_too_large,        ///< Value exceeds maximum container capacity
    duplicate_key,          ///< Two stored entries share a key: the database is locally inconsistent
    catalog_unreadable,     ///< The set of version files could not be read; absence cannot be assumed
    /// A version file that had to be consulted could not be read, so the sweep
    /// did not cover everything it needed to. The keys still unresolved are not
    /// known to be absent — any of them could be in the file that would not
    /// open. Distinct from catalog_unreadable, which is not knowing *which*
    /// files exist; this is knowing and failing to read one of them.
    version_unreadable,
    /// A drained version file, or its metadata, could not be removed. Two
    /// states reach here: the data file is still present and still catalogued,
    /// or the data file went and a stale metadata record was left behind.
    removal_failed,
    sync_unsupported,       ///< This platform has no such durability barrier; nothing was promised
    sync_failed,            ///< A durability barrier was attempted and failed
    rename_failed,          ///< A file could not be moved onto its final name
    /// Another instance holds this database. Reserved for exactly that: the
    /// lock was attempted and someone else has it.
    database_in_use,
    /// The claim could not be attempted at all — no permission, a filesystem
    /// without locking, a lock file that is not a regular file. Distinct from
    /// database_in_use because they send an operator looking in different
    /// places.
    database_lock_unavailable,
    entropy_unavailable,    ///< The system's cryptographic generator would not produce bytes
    file_open_failed,       ///< A version file could not be created or opened
    identity_collision,     ///< A version identity about to be published is already taken
    insufficient_space,     ///< Not enough room for the file an operation must build
    /// The instance published a merge and could not finish retiring what it
    /// superseded. Several canonical files hold the same keys, so it refuses
    /// every further operation: close it and reopen, which runs recovery.
    recovery_required,
    /// Recovery found evidence of an interrupted operation that it cannot act
    /// on. The database does not open; nothing is guessed at or repaired.
    recovery_failed,
    metadata_write_failed,  ///< A derived metadata record could not be published

    // -- The persisted-format barrier ----------------------------------------
    //
    // Kept apart from one another on purpose. Every one of these refuses the
    // same operation, but they send whoever reads the log somewhere different,
    // and collapsing them would make the difference between "your toolchain
    // moved" and "this file is from another database" invisible.

    /// The config is well formed and describes a format this build does not
    /// know. Not corruption: the file is exactly what it says it is.
    format_unsupported,
    /// A database written before the format carried its own identity — anything
    /// created up to v0.10.0. Its layout cannot be established after the fact,
    /// so it is refused rather than assumed, and nothing about it is touched.
    /// It has to be rebuilt from the chain.
    migration_required,
    /// The container sizing this build writes is not the one the file was
    /// written under.
    geometry_mismatch,
    /// The map implementation this build is certified against is not the one
    /// that wrote the file.
    layout_mismatch,
    /// The effective hash differs, so every key in the file is somewhere this
    /// build would not look for it.
    hash_mismatch,
    /// Written on a platform whose word size, endianness or pointer
    /// representation this build does not share.
    abi_mismatch,
    /// The file belongs to a different database. A version file that wandered in
    /// from somewhere else, or a config beside data that is not its own.
    database_identity_mismatch,
    /// A segment carries no format stamp. It was not written by a build that
    /// stamps, and what its bytes mean cannot be established.
    segment_stamp_missing,
    /// A segment's stamp is present and unusable: wrong marker, unknown format,
    /// bad checksum, or describing a different file than the one holding it.
    segment_stamp_corrupt,
    /// A segment's stamp is intact and describes a different container or
    /// generation than the one being opened — a version file moved or renamed
    /// into a name that is not its own. Apart from segment_stamp_corrupt because
    /// that one sends an operator looking for damage and this one for a file
    /// that was put somewhere it does not belong.
    segment_misplaced,
    /// The database was opened for inspection, and this operation is not part of
    /// inspecting it. An inspection open creates nothing — including the active
    /// container of a class that has none — so there is no map for most
    /// operations to work on, and refusing is the honest answer rather than
    /// creating one on their behalf.
    inspection_only,
    /// There is no database here, and the caller asked to open one that already
    /// exists. Distinct from every error about a database that *is* here and is
    /// wrong: this one says nothing was read, nothing was written, and nothing
    /// was created.
    database_not_found,
    /// A figure read out of a file cannot be true — an entry whose recorded
    /// payload length is longer than the class it lives in can hold, a map
    /// holding more entries than it has buckets, or counts that cannot be
    /// combined without overflowing sixty-four bits.
    ///
    /// Apart from every stamp error above, and not by accident. Those say the
    /// file is not one of ours, or is not where it claims to be; the config and
    /// the stamp certify identity and layout, and they say nothing about whether
    /// each entry is internally consistent. This one says the file passed all of
    /// that and an entry inside it still cannot be true.
    entry_corrupt,
    /// The directory holds files this store writes — generations, metadata,
    /// merge records — and no config. A database writes its config before any
    /// of them, so they belong to a database whose config is gone, and creating
    /// a new one here would give the directory a second identity that refuses
    /// the first one's files. Nothing was written. Restore the config, or open
    /// with `remove_existing` to discard what is there.
    config_missing,
    /// Memory could not be allocated. This does not diagnose a damaged or
    /// unreadable file. Operations returning progress may already have applied
    /// part of a batch; use their reported done/owed partition rather than
    /// assuming this error means nothing changed. Other operations can return
    /// it before any mutation; see each operation's contract.
    out_of_memory,
};

/**
 * @brief What sync() can promise on this platform.
 *
 * A caller that needs the difference has to be able to ask for it. `sync()`
 * returning success under `contents_only` means the entries are on the disk and
 * the directory entries that name them are not — the ordering between a
 * rotation and the data it publishes is then weaker than POSIX gives, and a
 * caller recording a checkpoint on the strength of it should know that.
 */
enum class durability_level : uint8_t {
    full,           ///< File contents and directory entries can both be made durable.
    contents_only,  ///< Contents can; directory entries have no exposed barrier.
    none,           ///< A virtual filesystem: there is no stable storage to reach.
};

/// What this build's platform can promise. Constant, and safe to branch on.
[[nodiscard]]
durability_level platform_durability() noexcept;

/**
 * @brief Result type for operations that can fail
 */
template<typename T = void>
using result = std::expected<T, error_code>;

/// Result of full_db::find(): data bytes + block height at which the UTXO was inserted.
struct full_find_result {
    std::vector<uint8_t> data;
    uint32_t block_height;
};

/// Result of reference_db::find(): typed reference fields + block height.
struct reference_find_result {
    uint32_t block_height;
    uint32_t file_number;
    uint32_t offset;
};

/// Backward-compatible alias.
using find_result = full_find_result;

/**
 * @brief File size for reference mode (production)
 */
inline constexpr size_t reference_file_size = 4_gib;

/**
 * @brief File size for reference mode (testing)
 */
inline constexpr size_t reference_test_file_size = 10_mib;

/**
 * @brief Deferred deletion entry
 */
struct deferred_deletion_entry {
    raw_outpoint key;         ///< UTXO key to delete
    uint32_t height;   ///< Block height when deletion was requested

    deferred_deletion_entry(raw_outpoint const& k, uint32_t h)
        : key(k), height(h) {}

    bool operator==(deferred_deletion_entry const& other) const {
        return key == other.key;
    }

    friend std::size_t hash_value(deferred_deletion_entry const& entry) {
        return hash_outpoint(entry.key);
    }
};

/**
 * @brief One lookup a caller wants resolved against the older versions.
 *
 * Owned by the caller, start to finish. This database stores none of these: a
 * request exists in the caller's batch, is passed to resolve() by reference,
 * and is still the caller's afterwards. That is the whole point of the type —
 * the queue it replaces was database-wide, so a resolution handed results to
 * whoever swept next rather than to whoever asked (#116).
 *
 * Equality and hashing are on the key alone, so a batch holding the same
 * outpoint at two heights is one request: it is one question about one entry.
 */
struct lookup_request {
    raw_outpoint key;  ///< UTXO key to look up
    uint32_t height;   ///< Block height the lookup is being made at

    lookup_request(raw_outpoint const& k, uint32_t h)
        : key(k), height(h) {}

    bool operator==(lookup_request const& other) const {
        return key == other.key;
    }

    friend std::size_t hash_value(lookup_request const& entry) {
        return hash_outpoint(entry.key);
    }
};

} // namespace utxoz

/**
 * @brief Hash function for UTXO key
 */
template<>
struct std::hash<utxoz::raw_outpoint> {
    std::size_t operator()(utxoz::raw_outpoint const& key) const noexcept {
        return utxoz::hash_outpoint(key);
    }
};

/**
 * @brief Hash function for deferred_deletion_entry
 */
template<>
struct std::hash<utxoz::deferred_deletion_entry> {
    std::size_t operator()(utxoz::deferred_deletion_entry const& entry) const noexcept {
        return utxoz::hash_outpoint(entry.key);
    }
};

/**
 * @brief Hash function for lookup_request
 */
template<>
struct std::hash<utxoz::lookup_request> {
    std::size_t operator()(utxoz::lookup_request const& entry) const noexcept {
        return utxoz::hash_outpoint(entry.key);
    }
};
