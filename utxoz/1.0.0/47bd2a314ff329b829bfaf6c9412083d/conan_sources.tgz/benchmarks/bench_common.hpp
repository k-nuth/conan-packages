// Copyright (c) 2016-present Knuth Project developers.
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#pragma once

#include <atomic>
#include <chrono>
#include <cstring>
#include <filesystem>
#include <numeric>
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

#ifdef _WIN32
#include <process.h>
#define getpid _getpid
#else
#include <unistd.h>
#endif

#include <fmt/format.h>
#include <nanobench.h>

#include <utxoz/database.hpp>

#include "detail/durability.hpp"
#include <utxoz/types.hpp>
#include <utxoz/utils.hpp>

namespace bench {

inline std::atomic<uint64_t> bench_counter{0};

inline
utxoz::raw_outpoint make_test_key(uint32_t tx_id, uint32_t output_index) {
    utxoz::raw_outpoint key{};
    for (size_t i = 0; i < 32; ++i) {
        key[i] = static_cast<uint8_t>((tx_id >> (i % 4 * 8)) & 0xFF);
    }
    std::memcpy(key.data() + 32, &output_index, 4);
    return key;
}

inline
std::vector<uint8_t> make_test_value(size_t size) {
    std::vector<uint8_t> value(size);
    std::iota(value.begin(), value.end(), 0);
    return value;
}

// BCH chain value size distribution (from full sync at block 930K).
//   43B: 82.0% (P2PKH)
//   41B: 13.3% (P2SH)
//  123B:  3.4%
//   89B:  0.9%
//  other: 0.4%
//
// r should be in [0, 100). Returns a value size.
inline
size_t chain_value_size(uint32_t r) {
    if (r < 82) return 43;   // P2PKH
    if (r < 95) return 41;   // P2SH
    if (r < 99) return 123;
    return 89;
}

struct BenchFixture {
    BenchFixture() {
        auto ts = std::chrono::high_resolution_clock::now().time_since_epoch().count();
        auto unique_id = bench_counter.fetch_add(1);
        path = fmt::format("./bench_utxo_db_{}_{}_{}", getpid(), ts, unique_id);

        if (std::filesystem::exists(path)) {
            std::filesystem::remove_all(path);
        }
        auto r = utxoz::db::open_for_testing(path, true);
        if (!r) throw std::runtime_error("Failed to open test database");
        db.emplace(std::move(*r));
    }

    ~BenchFixture() {
        db.reset();
        if (std::filesystem::exists(path)) {
            std::filesystem::remove_all(path);
        }
    }

    BenchFixture(BenchFixture const&) = delete;
    BenchFixture& operator=(BenchFixture const&) = delete;

    void populate(size_t n, size_t value_size = 43) {
        auto value = make_test_value(value_size);
        for (size_t i = 0; i < n; ++i) {
            auto key = make_test_key(static_cast<uint32_t>(i), 0);
            (void)db->insert(key, value, 100);
        }
    }

    // Populate with chain-realistic distribution
    void populate_chain_mix(size_t n) {
        auto val_43  = make_test_value(43);
        auto val_41  = make_test_value(41);
        auto val_123 = make_test_value(123);
        auto val_89  = make_test_value(89);
        for (size_t i = 0; i < n; ++i) {
            auto key = make_test_key(static_cast<uint32_t>(i), 0);
            auto sz = chain_value_size(static_cast<uint32_t>(i % 100));
            utxoz::output_data_span value;
            switch (sz) {
                case 43:  value = val_43;  break;
                case 41:  value = val_41;  break;
                case 123: value = val_123; break;
                default:  value = val_89;  break;
            }
            (void)db->insert(key, value, static_cast<uint32_t>(i / 100));
        }
    }

    std::optional<utxoz::db> db;
    std::string path;
};

// Benchmark registration functions (defined in each bench_*.cpp)
/// Reads and validates UTXOZ_BENCH_SYNTHETIC_LOOKUPS. Throws on a malformed
/// value rather than falling back to the default. See bench_synthetic_control.cpp.
uint32_t synthetic_lookups_from_environment();

/// A deliberate, configurable difference the harness must find. Registered last,
/// so the benchmarks that must *not* move have already run.
void register_synthetic_control(ankerl::nanobench::Bench& bench, uint32_t lookups);

void register_insert_benchmarks(ankerl::nanobench::Bench& bench);
void register_find_benchmarks(ankerl::nanobench::Bench& bench);
void register_erase_benchmarks(ankerl::nanobench::Bench& bench);
void register_mixed_workload_benchmarks(ankerl::nanobench::Bench& bench);
void register_storage_benchmarks(ankerl::nanobench::Bench& bench);
/// The read-path counters. Run from a build with statistics and from one
/// without; the difference between the two runs is what they cost.
void register_lookup_telemetry_benchmarks(ankerl::nanobench::Bench& bench);
void run_storage_overhead_report();

} // namespace bench
